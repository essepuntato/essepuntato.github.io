package slam;

import java.net.URISyntaxException;

/**
 * This is an Interface defined for the application of any kind of Semantic Lens, by using an Applier (SemLensApplier) to annotate the document 
 * with several Lens Annotations, built within the Applier and stored within its Lens Annotation Collection. 
 * The concept of applying a Semantic Lens is represented by this Interface, 
 * which is then followed in the hierarchy through the abstract class "BasicLensApp". 
 * Said abstract class is then to be extended by any specific LensApplication that the author may want to create on a specific document.
 * 
 * @author Jacopo Zingoni
 */
public interface SemLensApplication {
	
	/**
	 * This is the public method that contains all the instructions to annotate a Lens, using an Applier contained by the concrete class.
	 */
	public void annotate() throws URISyntaxException;	
	
	
	// Getters and Setters
	/**
	 * @return the applier
	 */
	public SemLensApplier getApplier();
	
	/**
	 * @param applier set the applier
	 */
	public void setApplier(SemLensApplier applier);

}
