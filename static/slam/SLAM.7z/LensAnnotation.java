package slam;

import it.essepuntato.earmark.core.MarkupItem;

import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;


/**
 * This is a basic class to group together the objects used to create Assertions on an EARMARK document. 
 * This class represents a Semantic Lens Annotation (which is, in practice, a generalized RDF statement WITHOUT the subject), 
 * used within a Semantic Lens Application. Every annotation represents a couple made of a predicate, or  "property", together with an "object", 
 * which could be either a generic Jena RDFNode or an Earmark MarkupItem (not both!). 
 * This couple is then to be used in building an assertion on a document or on any of its components. 
 * 
 * These Annotations are identified by a String name key and stored in a repository (within the LensAnnotationCollection class) inside the Applier 
 * of each Application. For Example "la:expresses doco:TextChunk" is a Lens Application, and could just be named “Doco TextChunk”. 
 * To each LensAnnotation is also assigned an appropriate LensType.
 * 
 * @author Jacopo Zingoni
 *
 */
public class LensAnnotation {
	
	/**
	 * This the Jena Property object which is expressed with this annotation. 
	 */
	private Property jenaproperty;
	
	/**
	 * This is the object of this Property. In this case, the object is a JENA RDFNode. This field is mutually exclusive with emobject
	 */
	private RDFNode jenaobject;
	/**
	 * This is the object of this Property. In this case, the object is an EARMARK MarkupItem. This field is mutually exclusive with jenaobject
	 */
	private MarkupItem emobject;

	/**
	 * This string identifies the Type of the Lens using this annotation. It must be one of the Strings allowed by the static class LensesTypes
	 */
	private String lenstype;
	
	/**
	 * This is the name and Id Key of the Annotation. It's important, as it is used to fetch it for further re-use from the LensAnnotationCollection
	 * This parameter is always required for a Lens Annotation to exist.
	 */
	private String name;
	
	/**
	 * Basic Constructor Method
	 * 
	 * @param n is the name of the Lens Annotation.
	 */
	public LensAnnotation(String n) {
		this.name = n;
	}
	// Il più importante e completo
	/**
	 * This is the most important and complete constructor method, and the one whose use is raccomended 
	 * 
	 * @param n is the name of the Lens Annotation
	 * @param prop is the Jena property of the Lens Annotation
	 * @param obj is the Jena RDFNode target of the Lens Annotation
	 * @param t is the type of this Lens Annotation
	 */
	public LensAnnotation(String n, Property prop, RDFNode obj, String t) {
		this.jenaproperty = prop;
		this.jenaobject = obj;
		this.emobject = null;
		this.name = n;
		this.lenstype = t;
	}
	/**
	 * This is the most important and complete constructor method, and the one whose use is raccomended. 
	 * 
	 * @param n is the name of the Lens Annotation
	 * @param prop is the Jena property of the Lens Annotation
	 * @param em is the EARMARK MarkupItem target of the Lens Annotation
	 * @param t is the type of this Lens Annotation
	 */
	// Uno per il caso con un Markupitem EM anzichè un RDFNode Jena
	public LensAnnotation(String n, Property prop, MarkupItem em, String t) {
		this.name = n;
		this.jenaproperty = prop;
		this.jenaobject = null;
		this.emobject = em;
		this.lenstype = t;
	}
	// Altri 3 per completezza
	/**
	 * Additional Constructor Method
	 * 
	 * @param n is the name of the Lens Annotation
	 * @param prop is the Jena property of the Lens Annotation
	 */
	public LensAnnotation(Property prop, RDFNode obj) {
		this.jenaproperty = prop;
		this.jenaobject = obj;
		this.emobject = null;
	}
	/**
	 * Additional Constructor Method
	 * 
	 * @param n is the name of the Lens Annotation
	 * @param prop is the Jena Property of the Lens Annotation
	 * @param obj is the Jena RDFNode target of the Lens Annotation
	 */
	public LensAnnotation(String n, Property prop, RDFNode obj) {
		this.name = n;
		this.jenaproperty = prop;
		this.jenaobject = obj;
		this.emobject = null;
	}
	/**
	 * Additional Constructor Method
	 * 
	 * @param n is the name of the Lens Annotation
	 * @param prop is the Jena Property of the Lens Annotation
	 * @param em is the EARMARK MarkupItem target of the Lens Annotation
	 */
	public LensAnnotation(String n, Property prop, MarkupItem em) {
		this.name = n;
		this.jenaproperty = prop;
		this.jenaobject = null;
		this.emobject = em;
	}

	
	
	/**
	 * A quick method to set both property and object of an Annotation
	 * 
	 * @param prop is the desired Jena Property of the Lens Annotation
	 * @param obj is the desired Jena RDFNode target of the Lens Annotation
	 */
	public void setAnnotation(Property prop, RDFNode obj) {
		this.jenaproperty = prop;
		this.jenaobject = obj;
		this.emobject = null;
	}
	/**
	 * A quick method to set both property and object of an Annotation
	 * 
	 * @param prop is the desired Jena Property of the Lens Annotation
	 * @param emobj is the desired Earmark MarkupItem target of the Lens Annotation
	 */
	public void setAnnotation(Property prop, MarkupItem emobj) {
		this.jenaproperty = prop;
		this.emobject = emobj;
		this.jenaobject = null;
	}
	
	/**
	 * A basic method to discover if the Annotation has an object of the Jena RDFNode Type or not
	 * 
	 * @return true if the annotation allows a Jena RDFNode as its object (if it the emobject field is not set)
	 */
	public boolean askIfJena() {
		if (emobject == null) return true;
		return false;
	}
	/**
	 * A basic method to discover if the Annotation has an object of the EARMARK MarkupItem Type or not
	 * 
	 * @return true if the annotation allows an Earmark MarkupItem as its object (if it the jenaobject field is not set)
	 */
	public boolean askIfEM() {
		if (jenaobject == null) return true;
		return false;
	}

	// Getters and Setters
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return the lenstype
	 */
	public String getLenstype() {
		return lenstype;
	}

	/**
	 * @param name the lenstype to set
	 */
	public void setLenstype(String lenstype) {
		this.lenstype = lenstype;
	}

	/**
	 * @return the jenaproperty
	 */
	public Property getJenaproperty() {
		return jenaproperty;
	}

	/**
	 * @param jenaproperty the jenaproperty to set
	 */
	public void setJenaproperty(Property jenaproperty) {
		this.jenaproperty = jenaproperty;
	}

	/**
	 * @return the object
	 */
	public RDFNode getJenaobject() {
		return jenaobject;
	}

	/**
	 * @param object the object to set
	 */
	public void setJenaobject(RDFNode object) {
		this.jenaobject = object;
		this.emobject = null;
	}

	/**
	 * @return the Earmark object
	 */
	public MarkupItem getEmobject() {
		return emobject;
	}

	/**
	 * @param object the Earmark object to set
	 */
	public void setEMobject(MarkupItem object) {
		this.emobject = object;
		this.jenaobject = null;
	}

}
