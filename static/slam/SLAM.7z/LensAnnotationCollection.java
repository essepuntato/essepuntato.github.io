package slam;


import java.util.HashMap;

import slam.utilities.LensesTypes;

/**
 * This class is a just a data structure to store a collection that groups all the Lens Annotations related to a single Applier (within a single Lens Application).
 * This collection is implemented by a Java HashMap, where the names of the LensAnnotation(s) are the keys to the map, 
 * and the annotation itself is the value stored. 
 * To each Collection is associated a LensType, and a warning will be had if an annotation of the wrong type is put in the Map.
 * 
 * @author Jacopo Zingoni
 *
 */
public class LensAnnotationCollection {
	
	/**
	 *  An HashMap where a number of LensAnnotation are stored associated with a string Key equal to their name 
	*/
	private HashMap <String, LensAnnotation> collection = new HashMap <String, LensAnnotation>();
	
	/**
	 *  All these annotations inside a collection must have the same type. The types allowed are described inside LensesTypes 
	 */
	private String lenstype;
	
	/**
	 *  A freeform description of this collection, for further reference 
	 */
	private String description;
	
	/**
	 * The Constructor for a LensAnnotation Collection
	 * 
	 * @param type one of the types of Semantic Lens allowed by the static LensesTypes constants, such as LensesTypes.STRUCTURE
	 * @param desc a freeform description of this collection
	 */
	public LensAnnotationCollection(String type, String desc){
		
		// Checking if the type is correct
		if (LensesTypes.acceptedTypes.contains(type))
		{
			this.lenstype = type;
			this.description = desc;
		}
		else {
			System.err.println("Error: unrecognized Lens Type");
		}
	}

	/**
	 * A simple method to get an Annotation from the collection storage.
	 * 
	 * @param name the String with the name of the Lens Annotation to be fetched from the storage
	 */
	public LensAnnotation getAnnotation(String name){
		return collection.get(name);
	}
	
	/**
	 * This method adds an Annotation to the collection, keying it with its own internal name
	 * 
	 * @param ann the LensAnnotation to be added
	 */
	public LensAnnotation putAnnotation(LensAnnotation ann){
		if (ann.getLenstype().equals(lenstype)){
			return collection.put(ann.getName(), ann);
		}
		else
			System.err.println("Error: lens types do not match between LensAnnotation and LensAnnotationCollection");
			System.err.println("Type conflict: "+ann.getLenstype() + "when it should have been " +this.lenstype);
			return null;
	}

	// GETTERS AND SETTERS
	/**
	 * @return the lenstype
	 */
	public String getLenstype() {
		return lenstype;
	}

	/**
	 * @param lenstype the lenstype to set
	 */
	public void setLenstype(String lenstype) {
		this.lenstype = lenstype;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the collection
	 */
	public HashMap<String, LensAnnotation> getCollection() {
		return collection;
	}

	/**
	 * @param collection the collection to set
	 */
	public void setCollection(HashMap<String, LensAnnotation> collection) {
		this.collection = collection;
	}
	
}
