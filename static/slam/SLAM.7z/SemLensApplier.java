package slam;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Iterator;
import java.util.Set;

import slam.utilities.LensesNames;

import it.essepuntato.earmark.core.Collection;
import it.essepuntato.earmark.core.Docuverse;
import it.essepuntato.earmark.core.EARMARKDocument;
import it.essepuntato.earmark.core.EARMARKItem;
import it.essepuntato.earmark.core.MarkupItem;
import it.essepuntato.earmark.core.exception.ExistingIdException;
import it.essepuntato.earmark.core.io.EARMARKWriter;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.RDFNode;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.ResourceFactory;

/**
 * This is the main class of the lensesnotes package, and it is an extension of the EarmarkFinder class.
 * The Semantic Lens Applier is the class with the implementation of all the methods used as instructions by the concrete Semantic Lens Application class.
 * Using the Applier methods, the Semantic Lens Application is thus built to annotate specific Semantic Lens Annotations on a Document.
 * 
 * A Semantic Lens Applier is included inside each Semantic Lens, to allow for a closer relationship and an improved customization of its own operativity. 
 * Each Applier includes two objects, a SemLensApplierPreferences, used to customize the output and the behaviour of a specific Applier,
 * and a AppMetaInfo, which includes a stats record for the Applier's activities and other meta-informations on it.
 * An applier is specific to one and only one type of Lens, as defined in LensesTypes, and as such it's a class ready to be extended if the needs arises.
 * 
 * The applier itself is a large collection of public methods and shortcut-methods, ready to be used to select elements on a EARMARK document or Jena Model,
 * to create or re-use Annotations, and to apply specific annotations to single elements or to set of them.  
 * Thus this class aims to cover all the basic needs of the authorial process of creating a Semantic Lens for a specific document.
 * 
 * @author Jacopo Zingoni
 *
 */
public class SemLensApplier extends EarmarkFinder {
	
	/**
	 * A String name which acts as an identifier for the Applier
	 */
	private String name;
	/**
	 *  Black box for additional Meta-Informations and stats module 
	 *  */
	private AppMetaInfo info;
	/**
	 * This element contains all the options for the behaviour and the output of the Applier, and it's ready to be customized by the user
	 */
	private SemLensApplierPreferences options;
	
	/**
	 * The type of the applier, as defined in the LensesTypes class
	 */
	private String lenstype;
	
	/**
	 * This is the LensAnnotationCollection which acts as a storage for all the Lens Annotations created and used by the applier.
	 * It allows to reuse and recover annotations, thus simplifying the author's work
	 */
	private LensAnnotationCollection storage;
	
	/**
	 * This is the handler to the EARMARKDocument where I will apply the Lens 
	 */
	private EARMARKDocument document; 
	

	/** This field contains the last MarkupItem object found or created by the applier */
	private MarkupItem currentitem;
	/** This field contains the last EARMARKItem object found or created by the applier */
	private EARMARKItem currententity;
	/** This field contains the last RDFNode object found or created by the applier */
	private RDFNode currentnode;
	/** This field contains the last Jena Property object found or created by the applier */
	private Property currentproperty;
	/** This field contains the last LensAnnotation object found or created by the applier */
	private LensAnnotation lastannotation;

	/**
	 * Constructor for the class. It requires a name, the type of the lens, and the handler to the EARMARKDocument on which the applier is going to operate.
	 * 
	 * @param name the identifier of the Applier
	 * @param lenstype the type of the Lens for which this applier is created. Should be the same as the concrete SemLensApplication using the applier.
	 * @param document the EARMARKDocument which will be the target of the Application and on which the Applier is going to work. 
	 */
	public SemLensApplier (String name, String lenstype, EARMARKDocument document){
		super(name,document);
		this.name = name;
		this.lenstype = lenstype;
		this.document = document;
		// rfInit();
		optionsInit();
		infoInit();
	}
	/**
	 * Suggested Constructor for the class.
	 * It requires a name, the type of the lens, the handler to the EARMARKDocument on which the applier is going to operate and a description for the storage
	 * 
	 * @param name the identifier of the Applier
	 * @param lenstype the type of the Lens for which this applier is created. Should be the same as the concrete SemLensApplication using the applier.
	 * @param document the EARMARKDocument which will be the target of the Application and on which the Applier is going to work.
	 * @param storagedesc a freeform, optional description of the LensAnnotationCollection used by the Applier as a storage for the Lens Annotations it creates
	 */
	public SemLensApplier (String name, String lenstype, EARMARKDocument document, String storagedesc){
		super(name,document);
		this.name = name;
		this.lenstype = lenstype;
		this.document = document;
		storageInit(storagedesc);
		optionsInit();
		infoInit();
	}
	
	/**
	 * This creates and initialize the LensAnnotationCollection used as storage by the Applier, with the correct description.
	 * 
	 * @param desc a freeform, optional description of the LensAnnotationCollection used by the Applier as a storage for the Lens Annotations it creates
	 */
	public void storageInit(String desc){
		this.storage = new LensAnnotationCollection(lenstype, desc);
	}
	/**
	 * This initializes the preferences relative to this Applier
	 */
	@Override
	public void optionsInit () {
		setOptions(new SemLensApplierPreferences());
	}
	/**
	 * This initializes the meta informations relative to this Applier
	 */
	public void infoInit () {
		this.info = new AppMetaInfo();
	}
	
	
	/**
	 * This is a method used to create a new Jena Property, which is then returned and stored in the currentproperty field
	 * The property will be created with the Jena Resource Factory
	 * This will typically be used to build a new LensAnnotation
	 * 
	 * @param pred a String with the desired predicate, that is to say, with the desired contents of the property
	 * @return the Jena Property just created
	 */
	public Property createProperty(String pred){
		currentproperty = ResourceFactory.createProperty(pred);
			if ((options.getVerbosity_overall() >= 3) && (options.isLog_createProperty())) // Output Log
			{
				System.out.println("Applier Verbose: Created property: "+ currentproperty);	
			}
		return currentproperty;
	}
	/**
	 * This is a method used to create a new Jena Property, which is then returned and stored in the currentproperty field
	 * The property will be created with the Jena Resource Factory
	 * This will typically be used to build a new LensAnnotation
	 * 
	 * @param ns a String with the namespace associated to the property
	 * @param pred a String with the desired predicate, that is to say, with the desired contents of the property
	 * @return the Jena Property just created
	 */
	public Property createProperty(String ns, String pred){
		currentproperty = ResourceFactory.createProperty(ns, pred);
			if ((options.getVerbosity_overall() >= 3) && (options.isLog_createProperty())) // Output Log
			{
				System.out.println("Applier Verbose: Created property: "+ currentproperty);	
			}
		return currentproperty;
	}
	/**
	 * This is a method used to create a new Jena RDFNode which will act as the resource object of a Lens Annotation. 
	 * The results will be saved in the currentnode field.
	 * 
	 * @param uriref a String with the id of the desired RDFNode which will be the object of an assertion
	 * @return the RDFNode just created
	 */
	public RDFNode createJenaResObject(String uriref){
		currentnode = ResourceFactory.createResource(uriref);
			if ((options.getVerbosity_overall() >= 3) && (options.isLog_createJenaResObject())) // Output Log
			{
				System.out.println("Applier Verbose: Created resource object: "+ currentnode);				
			}
		return currentnode;
	}
	
	/**
	 * Polymorphic method for the creation of a new LensAnnotation, which will be put into storage, saved in the lastannotation field, and outputed
	 * It creates a Jena Property, a Jena RDFNode as object of the annotation, and creates a new Lens Annotation based on that couple 
	 * This is the most complete version, including all the possible parameters
	 * 
	 * @param name the String which will identify the Annotation. It will be used as key in the storage, and used to fetch it back again.
	 * @param propns the namespace for the predicate
	 * @param pred the predicate of the Property of the LensAnnotation
	 * @param objuri the id of the RDFNode which will be the object of the LensAnnotation
	 * @param type the lens type of the LensAnnotation created, it must be one of those defined by LensesTypes
	 * @return the LensAnnotation just created.
	 */
	public LensAnnotation buildAnnotation(String name, String propns, String pred, String objuri, String type) {
		// Creo al volo una proprietà ed un oggetto dell'annotazione, in questo caso come Jena RDFNode, tramite la resource factory di questa classe 
		LensAnnotation newlens = new LensAnnotation(name, createProperty(propns, pred), createJenaResObject(objuri), type);
		storage.putAnnotation(newlens);	// La LensAnnotation viene aggiunta alla hashmap di storage
				if ((options.getVerbosity_overall() >= 4) && (options.isLog_buildAnnotation())) // Output Log
				{
					System.out.println("Applier Debug: New Lens Annotation with name " + name + " of type " + type + " with property " 
						+ pred + " targeting object " + objuri + " has been created and put into a storage, now sized "	+ storage.getCollection().size());
				}
		lastannotation = newlens;
		return newlens;
	}

	
	/**
	 * Polymorphic method for the creation of a new LensAnnotation, which will be put into storage, saved in the lastannotation field, and outputed
	 * It creates a Jena Property, a Jena RDFNode as object of the annotation, and creates a new Lens Annotation based on that couple
	 * This is the suggested version, which infers the type from the type of the SemLensApplier.
	 * 
	 * @param name the String which will identify the Annotation. It will be used as key in the storage, and used to fetch it back again.
	 * @param propns the namespace for the predicate
	 * @param pred the predicate of the Property of the LensAnnotation
	 * @param objuri the id of the RDFNode which will be the object of the LensAnnotation
	 * @return the LensAnnotation just created.
	 */
	public LensAnnotation buildAnnotation(String name, String propns, String pred, String objuri) {
		// Creo al volo una proprietà ed un oggetto dell'annotazione, in questo caso come Jena RDFNode, tramite la resource factory di questa classe 
		LensAnnotation newlens = new LensAnnotation(name, createProperty(propns, pred), createJenaResObject(objuri), lenstype);
		storage.putAnnotation(newlens);	// La LensAnnotation viene aggiunta alla hashmap di storage
			if ((options.getVerbosity_overall() >= 4) && (options.isLog_buildAnnotation())) // Output Log
			{
				System.out.println("Applier Debug: New Lens Annotation with name " + name + " with property " + pred + " targeting object " + objuri 
					+ " has been created and put into a storage, now sized " + storage.getCollection().size());
			}
		lastannotation = newlens;
		return newlens;
	}

	
	/**
	 * Polymorphic method for the creation of a new LensAnnotation, which will be put into storage, saved in the lastannotation field, and outputed
	 * It creates a Jena Property, a Jena RDFNode as object of the annotation, and creates a new Lens Annotation based on that couple
	 * This is a short version, which does not use a separate namespace for the Property predicate, but includes it in the parameters 
	 *  
	 * @param name the String which will identify the Annotation. It will be used as key in the storage, and used to fetch it back again.
	 * @param pred the predicate of the Property of the LensAnnotation, including the namespace
	 * @param objuri the id of the RDFNode which will be the object of the LensAnnotation
	 * @return the LensAnnotation just created.
	 */
	public LensAnnotation buildAnnotation(String name, String pred, String objuri) {
		// Creo al volo una proprietà ed un oggetto dell'annotazione, in questo caso come Jena RDFNode, tramite la resource factory di questa classe 
		LensAnnotation newlens = new LensAnnotation(name, createProperty(pred), createJenaResObject(objuri), lenstype);
		storage.putAnnotation(newlens);	// La LensAnnotation viene aggiunta alla hashmap di storage
			if ((options.getVerbosity_overall() >= 4) && (options.isLog_buildAnnotation())) // Output Log
			{
				System.out.println("Applier Debug: New Lens Annotation with name " + name + " with property " + pred + " targeting object " + objuri 
					+ " has been created and put into a storage, now sized " + storage.getCollection().size());
			}
		lastannotation = newlens;
		return newlens;
	}

	/**
	 * Polymorphic method for the creation of a new LensAnnotation targeting an Earmark MarkupItem as object
	 * The annotation will be put into storage, saved in the lastannotation field, and outputed
	 * It creates a Jena Property, and asks for the ID of the MarkupItem object of the annotation, and then creates a new Lens Annotation based on that couple
	 * This is the suggested version, which infers the type from the type of the SemLensApplier.
	 * 
	 * @param name the String which will identify the Annotation. It will be used as key in the storage, and used to fetch it back again.
	 * @param propns the namespace for the predicate
	 * @param pred the predicate of the Property of the LensAnnotation
	 * @param objid the id of the EARMARK MarkupItem which will be the object of the LensAnnotation
	 * @return the LensAnnotation just created.
	 * @throws URISyntaxException if the id of the EARMARK MarkupItem object will not be parsed correctly as a valid URI
	 */
	public LensAnnotation buildEMAnnotation(String name, String propns, String pred, String objid) throws URISyntaxException {
		LensAnnotation newlens = new LensAnnotation(name); // Uso il costruttore solo per nome
		newlens.setLenstype(lenstype); // Setto il tipo
		newlens.setAnnotation(createProperty(propns, pred), findSingleMarkupItem(objid)); // Setto i parametri principali dell'annotazione
		storage.putAnnotation(newlens); // La LensAnnotation viene aggiunta alla hashmap di storage
			if ((options.getVerbosity_overall() >= 4) && (options.isLog_buildAnnotation())) // Output Log
			{
				System.out.println("Applier Debug: New EM Lens Annotation with name " + name + " with property " + pred + " targeting object " + objid 
						+ " has been created and put into a storage, now sized " + storage.getCollection().size());
			}
		lastannotation = newlens;
		return newlens;
	}

	
	/**
	 * Polymorphic method for the creation of a new LensAnnotation targeting an Earmark MarkupItem as object
	 * The annotation will be put into storage, saved in the lastannotation field, and outputed
	 * It creates a Jena Property, and asks for the ID of the MarkupItem object of the annotation, and then creates a new Lens Annotation based on that couple
	 * This is the most complete version, including all the possible parameters
	 * 
	 * @param name the String which will identify the Annotation. It will be used as key in the storage, and used to fetch it back again.
	 * @param propns the namespace for the predicate
	 * @param pred the predicate of the Property of the LensAnnotation
	 * @param objid the id of the EARMARK MarkupItem which will be the object of the LensAnnotation
	 * @param type the lens type of the LensAnnotation created, it must be one of those defined by LensesTypes
	 * @return the LensAnnotation just created.
	 * @throws URISyntaxException if the id of the EARMARK MarkupItem object will not be parsed correctly as a valid URI
	 */
	public LensAnnotation buildEMAnnotation(String name, String propns, String pred, String objid, String type) throws URISyntaxException {
		LensAnnotation newlens = new LensAnnotation(name); // Uso il costruttore solo per nome
		newlens.setLenstype(type); // Setto il tipo
		newlens.setAnnotation(createProperty(propns, pred), findSingleMarkupItem(objid)); // Setto i parametri principali dell'annotazione
		storage.putAnnotation(newlens); // La LensAnnotation viene aggiunta alla hashmap di storage
			if ((options.getVerbosity_overall() >= 4) && (options.isLog_buildAnnotation())) // Output Log
			{
				System.out.println("Applier Debug: New EM Lens Annotation with name " + name + " of type " + type + " with property " + pred + 
					" targeting object " + objid + " has been created and put into a storage, now sized " + storage.getCollection().size());
			}
		lastannotation = newlens;
		return newlens;
	}
	

	/**
	 * This is a private method that the applier uses to interact with the statistics section of the AppMetaInfo object info included in the Applier.
	 * This method is called by all other methods asserting LensesAnnotations on a documents, and records which lens is used.
	 * Either storing it in the correct HashMap of the AppMetaInfo or increasing the appropriate use counters by updating said maps
	 * 
	 * @param name The name field of the LensAnnotation being asserted 
	 * @param property the property of the LensAnnotation being asserted
	 */
	private void recordStats(String name, String property) {
		// Increasing the toal counter
		info.increaseTotal();
		
		// Assertion Section
		if (info.getAssertions().containsKey(name))
		{
			int k = info.getAssertions().get(name);
			info.getAssertions().put(name, k + 1);
			if ((options.getVerbosity_overall() >= 4) && (options.isLog_privatestatsmethods())) // Output Log
			{
				System.out.println("Applier Stat Module: Updated information on assertion keyed " + name + " - it has been stored");
				System.out.println("Applier Stat Module: So far it has been recorded " + info.getAssertions().get(name) + " times during this Application");
			}
		}
		else 
		{
			info.getAssertions().put(name, 1);
			if ((options.getVerbosity_overall() >= 4) && (options.isLog_privatestatsmethods())) // Output Log
			{
				System.out.println("Applier Stat Module: Recorded for the first time information on assertion keyed " + name + " - it has been stored");
			}
		}
		
		// Properties Section
		if (info.getProperties().containsKey(property)) 
		{
			int h = info.getProperties().get(property);
			info.getProperties().put(property, h + 1);
			if ((options.getVerbosity_overall() >= 4) && (options.isLog_privatestatsmethods())) // Output Log
			{
				System.out.println("Applier Stat Module: Updated information on assertion keyed " + name + " - it has been stored");
				System.out.println("Applier Stat Module: So far it has been recorded " + info.getProperties().get(name) + " times during this Application");
			}
		}
		else 
		{
			info.getProperties().put(property, 1);
			if ((options.getVerbosity_overall() >= 4) && (options.isLog_privatestatsmethods())) // Output Log
			{
				System.out.println("Applier Stat Module: Recorded for the first time information on assertion keyed " + name + " - it has been stored");
			}
		}
	}
	
	/* ASSERT ON NODES: Methods to implement the assertions on the document. */
	/**
	 * This method is used to implement the assertion of a Lens Annotation on a EARMARK MarkupItem part of the EARMARKDocument on which the Applier is working
	 * This is the basic method to assert a Lens Annotation. An EARMARK MarkupItem is chosen as the subject of the assertion,
	 * Then the contents of the lens (Property and Object) are used to complete the RDF triple which will become a new statement on the document 
	 * This is the most common use case, where the object is a LensAnnotation having a Jena RDFNode as object
	 * 
	 * @param item is the handler for the EARMARK MarkupItem which will be the subject of the assertion
	 * @param lens is the LensAnnotation to be asserted on the document
	 */
	public void assertOnNode(MarkupItem item, LensAnnotation lens){
		item.assertsAsSubject(lens.getJenaproperty(), lens.getJenaobject() );
			if ((options.getVerbosity_overall() >= 1) && (options.isLog_assertOnNode())) // Output Log
			{
				if ((options.getVerbosity_overall() >= 4) && (options.isLog_assertOnNode())) // Output Log
				{
				System.out.println("Applier Debug: Asserted " + lens.getJenaproperty() + " targeting " + lens.getJenaobject() + 
						" on Node " + item.hasId());
				}
				System.out.println("Applier: asserted lens " + lens.getName() + " on the requested node: " + item.hasId() );
			}
			if (options.isAllow_stats()) {	recordStats (lens.getName(), lens.getJenaproperty().toString()); } // Stat Module
	}

	
	/**
	 * This method is used to implement the assertion of a Lens Annotation on a EARMARK MarkupItem part of the EARMARKDocument on which the Applier is working
	 * This is the basic method to assert a Lens Annotation. An EARMARK MarkupItem is chosen as the subject of the assertion,
	 * Then the contents of the lens (Property and Object) are used to complete the RDF triple which will become a new statement on the document 
	 * This is the least common case, where the object of the LensAnnotation assertion is another EARMARK EarmarkItem
	 * 
	 * @param item is the handler for the EARMARK MarkupItem which will be the subject of the assertion
	 * @param lens is the LensAnnotation to be asserted on the document
	 */
	public void assertOnNodeEM(MarkupItem item, LensAnnotation lens){
		item.assertsAsSubject(lens.getJenaproperty(), lens.getEmobject());
			if ((options.getVerbosity_overall() >= 1) && (options.isLog_assertOnNodeEM())) // Output Log
			{
				if ((options.getVerbosity_overall() >= 4) && (options.isLog_assertOnNodeEM())) // Output Log - Deeper
				{
				System.out.println("Applier Debug: Asserted " + lens.getJenaproperty() + " targeting " + lens.getEmobject() + 
						" on Node " + item.hasId());
				}
				System.out.println("Applier: asserted lens " + lens.getName() + " on the requested node: " + item.hasId() );
			}
			if (options.isAllow_stats()) {	recordStats (lens.getName(), lens.getJenaproperty().toString()); } // Stat Module
	}
	
	/*
	 * Assert on a set: It simply iterates the set of MarkupItems to do the assertions
	 */
	/**
	 * This method asserts a selected LensAnnotation on a Set of MarkupItem part of the document on which the Applier is working.
	 * This method simply iterates assertOnNode on each MarkupItem part of the Set, which is the subject of the Lens Annotation.
	 * The contents of the lens (Property and Object) are used to complete the RDF triple which will become a new statement on the document
	 * This is the most common case, with the object of the Annotation a JENA RDFNode 
	 * 
	 * @param set the set of MarkupItem containing all the elements over which the LensAnnotation will be asserted with them as subject
	 * @param lens is the LensAnnotation to be asserted on the document
	 */
	public void assertOnSet(Set<MarkupItem> set, LensAnnotation lens){
		Iterator <MarkupItem> iter = set.iterator();
		while (iter.hasNext())
		{
			MarkupItem item = iter.next();
			item.assertsAsSubject(lens.getJenaproperty(), lens.getJenaobject() );
			if (options.isAllow_stats()) {	recordStats (lens.getName(), lens.getJenaproperty().toString()); } // Stat Module
				if ((options.getVerbosity_overall() >= 3) && (options.isLog_assertOnSet())) // Output Log
				{
					System.out.println("Applier Verbose: asserted lens " + lens.getName() + " on the requested node: " + item.hasId() );
				}
			
		}
	}

	
	/**
	 * This method asserts a selected LensAnnotation on a Set of MarkupItem part of the document on which the Applier is working.
	 * This method simply iterates assertOnNodeEM on each MarkupItem part of the Set, which is the subject of the Lens Annotation.
	 * The contents of the lens (Property and Object) are used to complete the RDF triple which will become a new statement on the document
	 * This is the least common case, where the object of the LensAnnotation assertion is another EARMARK EarmarkItem
	 * 
	 * @param set the set of MarkupItem containing all the elements over which the LensAnnotation will be asserted with them as subject
	 * @param lens is the LensAnnotation to be asserted on the document
	 */
	public void assertOnSetEM(Set<MarkupItem> set, LensAnnotation lens){
		Iterator <MarkupItem> iter = set.iterator();
		while (iter.hasNext())
		{
			MarkupItem item = iter.next();
			item.assertsAsSubject(lens.getJenaproperty(), lens.getEmobject() );
			if (options.isAllow_stats()) {	recordStats (lens.getName(), lens.getJenaproperty().toString()); } // Stat Module
				if ((options.getVerbosity_overall() >= 3) && (options.isLog_assertOnSet())) // Output Log
				{
					System.out.println("Applier Verbose: asserted lens " + lens.getName() + " on the requested node: " + item.hasId() );
				}
		}
	}
	
	/* XYZAssert: Mashup combo methods used as a shortcuts for the most common operations. */
	/**
	 * This is a combo method that acts as a shortcut for one of the most common operation, the one of finding an Item by id and asserting an Annotation on it
	 * This method searches in the EARMARKDocument for a MarkupItem with the required id, then it asserts the Annotation, with the item found as subject.
	 * This is the most common version, using Annotations having as objects Jena RDFNode
	 * 
	 * @param id This is the String identifying the EARMARK MarkupItem. The id will be automatically transformed into URI inside the method
	 * @param lens is the LensAnnotation to be asserted on the document
	 * @throws URISyntaxException if the id will not be parsed correctly as a valid URI
	 */
	public void searchAndAssert(String id, LensAnnotation lens) throws URISyntaxException {
		findSingleMarkupItem(id).assertsAsSubject(lens.getJenaproperty(), lens.getJenaobject());
		if (options.isAllow_stats()) {	recordStats (lens.getName(), lens.getJenaproperty().toString()); } // Stat Module
			if ((options.getVerbosity_overall() >= 1) && (options.isLog_searchAndAssert())) // Output Log
			{
				System.out.println("Applier: asserted lens " + lens.getName() + " on the node that has just been found by id: " + id);
			}
	}

	/**
	 * This method is a shortcut for a common operaton, the one of recovering an existing Annotation from the storage and asserting it on an required Item
	 * This method searches in the storage LensAnnotationCollection for an annotation with the desired name
	 * Then it searches in the EARMARKDocument for a MarkupItem with the required id and asserts the Annotation on the document, with the item found as subject
	 * This is the most common version, using Annotations having as objects Jena RDFNode
	 * 
	 * @param id This is the String identifying the EARMARK MarkupItem. The id will be automatically transformed into URI inside the method
	 * @param name is the name of LensAnnotation to be found in the storage, and then asserted on the document
	 * @throws URISyntaxException if the id will not be parsed correctly as a valid URI
	 */
	public void recoverAndAssert(String id, String name) throws URISyntaxException {
		LensAnnotation lens = storage.getAnnotation(name);
		findSingleMarkupItem(id).assertsAsSubject(lens.getJenaproperty(), lens.getJenaobject());
		if (options.isAllow_stats()) {	recordStats (lens.getName(), lens.getJenaproperty().toString()); } // Stat Module
			if ((options.getVerbosity_overall() >= 1) && (options.isLog_recoverAndAssert())) // Output Log
			{
				System.out.println("Applier: asserted lens " + lens.getName() + " on the node that has just been found by id: " + id);
			}
	}
	
	// EM Versions
	/**
	 * This is a combo method that acts as a shortcut for one of the most common operation, the one of finding an Item by id and asserting an Annotation on it
	 * This method searches in the EARMARKDocument for a MarkupItem with the required id, then it asserts the Annotation, with the item found as subject.
	 * This is the alternative version, using Annotations having as objects other EARMARK MarkupItems 
	 * 
	 * @param id This is the String identifying the EARMARK MarkupItem. The id will be automatically transformed into URI inside the method
	 * @param lens is the LensAnnotation to be asserted on the document
	 * @throws URISyntaxException if the id will not be parsed correctly as a valid URI
	 */
	public void searchAndAssertEM(String id, LensAnnotation lens) throws URISyntaxException {
		findSingleMarkupItem(id).assertsAsSubject(lens.getJenaproperty(), lens.getEmobject());
		if (options.isAllow_stats()) {	recordStats (lens.getName(), lens.getJenaproperty().toString()); } // Stat Module
			if ((options.getVerbosity_overall() >= 1) && (options.isLog_searchAndAssertEM())) // Output Log
			{
				System.out.println("Applier: asserted lens " + lens.getName() + " on the node that has just been found by id " + id);
			}
	}
	/**
	 * This method is a shortcut for a common operaton, the one of recovering an existing Annotation from the storage and asserting it on an required Item
	 * This method searches in the storage LensAnnotationCollection for an annotation with the desired name
	 * Then it searches in the EARMARKDocument for a MarkupItem with the required id and asserts the Annotation on the document, with the item found as subject
	 * This is the the alternative version, using Annotations having as objects other EARMARK MarkupItems
	 * 
	 * @param id This is the String identifying the EARMARK MarkupItem. The id will be automatically transformed into URI inside the method
	 * @param name is the name of LensAnnotation to be found in the storage, and then asserted on the document
	 * @throws URISyntaxException if the id will not be parsed correctly as a valid URI
	 */
	public void recoverAndAssertEM(String id, String name) throws URISyntaxException {
		LensAnnotation lens = storage.getAnnotation(name);
		findSingleMarkupItem(id).assertsAsSubject(lens.getJenaproperty(), lens.getEmobject());
		if (options.isAllow_stats()) {	recordStats (lens.getName(), lens.getJenaproperty().toString()); } // Stat Module
			if ((options.getVerbosity_overall() >= 1) && (options.isLog_recoverAndAssertEM())) // Output Log
			{
				System.out.println("Applier: asserted lens " + lens.getName() + " on the node that has just been found by id " + id);
			}
	}

	
	/*
	 * Mashup Combo methods:
	 * Annotate for all types of a specific element
	 */
	/**
	 * This is a combo method that acts as a shortcut for a common operation, the one of asserting an annotation on all items with a specific gid
	 * This method first uses findItemsByGIDAndNS to find a Set of MarkupItems having the required GeneralIdentifier and Namespace inside the document
	 * Then it simply iterates on this Set and asserts the specified LensAnnotation on the document for each item, using it as subject.
	 * It uses the most common annotations, the ones having Jena RDFNode as objects
	 * 
	 * @param gid The general identifier of the MarkupItems to be found in the document
	 * @param ns The namespace of the MarkupItems to be found in the document
	 * @param lens is the LensAnnotation to be asserted on all the nodes found by the search in the document
	 * @throws URISyntaxException if the ns will not be parsed correctly as a valid URI
	 */
	public void massAnnotate(String gid, String ens, LensAnnotation lens) throws URISyntaxException {
		int count = 0;
		findItemsByGIDAndNS(gid, ens);
		Iterator<MarkupItem> iter = getLastitemset().iterator();
		while (iter.hasNext())
		{
			MarkupItem mark = iter.next();
			assertOnNode(mark, lens);
			count = count + 1;
		}
			if ((options.getVerbosity_overall() >= 1) && (options.isLog_massAnnotate())) // Output Log
			{
				System.out.println("Applier: Asserted lens "+lens.getName()+" on node type "+gid+" "+count+" times");
			}
	}
	/**
	 * This is a combo method that acts as a shortcut for a common operation, the one of asserting an annotation on all items with a specific gid
	 * This method first uses findItemsByGIDAndNS to find a Set of MarkupItems having the required GeneralIdentifier and Namespace inside the document
	 * Then it simply iterates on this Set and asserts the specified LensAnnotation on the document for each item, using it as subject.
	 * It uses the least common type of annotations, the ones having other EARMARK MarkupItems as objects
	 * 
	 * @param gid The general identifier of the MarkupItems to be found in the document
	 * @param ns The namespace of the MarkupItems to be found in the document
	 * @param lens is the LensAnnotation to be asserted on all the nodes found by the search in the document
	 * @throws URISyntaxException if the ns will not be parsed correctly as a valid URI
	 */
	public void massAnnotateEM(String gid, String ens, LensAnnotation lens) throws URISyntaxException {
		int count = 0;
		findItemsByGIDAndNS(gid, ens);
		Iterator<MarkupItem> iter = getLastitemset().iterator();
		while (iter.hasNext())
		{
			MarkupItem mark = iter.next();
			assertOnNodeEM(mark, lens);
			count = count + 1;
		}
			if ((options.getVerbosity_overall() >= 1) && (options.isLog_massAnnotate())) // Output Log
			{
				System.out.println("Applier: Asserted lens "+lens.getName()+" on node type "+gid+" "+count+" times");
			}
	}
	
	
	/* 
	 * MashupCombo methods to annotate all elements found at certain conditions.
	 */
	/**
	 * This is a combo method that acts as a shortcut for asserting an annotation on the results of a findItemsWithAtts() search
	 * It first uses findItemsWithAtts() to find all the elements having the required gid, namespace, and a specific attribute equal to the desired value  
	 * Then it simply iterates on this Set and asserts the specified LensAnnotation on the document for each item, using it as subject.
	 * 
	 * @param gid The general identifier of the MarkupItems to be found in the document
	 * @param ens The namespace of the MarkupItems to be found in the document
	 * @param attr The name of the Attribute to be searched. It has to be present as the child of an element to be selected
	 * @param attval the value of that the attribute named attr has to have for an element to be selected
	 * @param lens is the LensAnnotation to be asserted on all the nodes found by the search in the document
	 * @throws URISyntaxException if the ns will not be parsed correctly as a valid URI
	 */
	public void searchWithAttsAndAssert(String gid, String ens, String attr, String attval, LensAnnotation lens) throws URISyntaxException {
		int count = 0;
		findItemsWithAtts(gid, ens, attr, attval);
			if ((options.getVerbosity_overall() >= 4) && (options.isLog_searchWithAttsAndAssert())) // Output Log
			{
				System.out.println("Applier Debug: found " + getLastitemset().size() + " items");
			}
		Iterator<MarkupItem> iter = getLastitemset().iterator();
		while (iter.hasNext())
		{
			MarkupItem mark = iter.next();
			assertOnNode(mark, lens);
			count = count + 1;
		}
			if ((options.getVerbosity_overall() >= 1) && (options.isLog_searchWithAttsAndAssert())) // Output Log
			{
				System.out.println("Applier: asserted lens "+lens.getName()+" on node type "+gid+" "+count+" times");
			}
	}
	/**
	 * This is a combo method that acts as a shortcut for asserting an annotation on the results of a findItemsWithAtts() search
	 * It first uses findItemsWithAtts() to find all the elements having the required gid, namespace, and a specific attribute
	 * Then it simply iterates on this Set and asserts the specified LensAnnotation on the document for each item, using it as subject.
	 * 
	 * @param gid The general identifier of the MarkupItems to be found in the document
	 * @param ens The namespace of the MarkupItems to be found in the document
	 * @param attr The name of the Attribute to be searched. It has to be present as the child of an element to be selected
	 * @param lens is the LensAnnotation to be asserted on all the nodes found by the search in the document
	 * @throws URISyntaxException if the ns will not be parsed correctly as a valid URI
	 */
	public void searchWithAttsAndAssert(String gid, String ens, String attr, LensAnnotation lens) throws URISyntaxException {
		int count = 0;
		findItemsWithAtts(gid, ens, attr);
			if ((options.getVerbosity_overall() >= 4) && (options.isLog_searchWithAttsAndAssert())) // Output Log
			{
				System.out.println("Applier Debug: found " + getLastitemset().size() + " items");
			}
		Iterator<MarkupItem> iter = getLastitemset().iterator();
		while (iter.hasNext())
		{
			MarkupItem mark = iter.next();
			assertOnNode(mark, lens);
			count = count + 1;
		}
			if ((options.getVerbosity_overall() >= 1) && (options.isLog_searchWithAttsAndAssert())) // Output Log
			{
				System.out.println("Applier: asserted lens "+lens.getName()+" on node type "+gid+" "+count+" times");
			}
	}
	/**
	 * This is a combo method that acts as a shortcut for asserting an annotation on the results of a findItemsWithWildAtts() search
	 * It first uses findItemsWithWildAtts() to find all the elements having the required gid, namespace, and a chosen attribute whose contents match a pattern 
	 * Then it simply iterates on this Set and asserts the specified LensAnnotation on the document for each item, using it as subject.
	 * 
	 * @param gid The general identifier of the MarkupItems to be found in the document
	 * @param ens The namespace of the MarkupItems to be found in the document
	 * @param attr The name of the Attribute to be searched. It has to be present as the child of an element to be selected 
	 * @param pattern the required content for the attribute attr. It can contain multiple wildcards '*' (asterisk).
	 * @param lens is the LensAnnotation to be asserted on all the nodes found by the search in the document
	 * @throws URISyntaxException if the ns will not be parsed correctly as a valid URI
	 */
	public void searchWithWildAttsAndAssert(String gid, String ens, String attr, String pattern, LensAnnotation lens) throws URISyntaxException {
		int count = 0;
		findItemsWithWildAtts(gid, ens, attr, pattern);
			if ((options.getVerbosity_overall() >= 4) && (options.isLog_searchWithWildAttsAndAssert())) // Output Log
			{
				System.out.println("Applier Debug: found " + getLastitemset().size() + " items");
			}
		Iterator<MarkupItem> iter = getLastitemset().iterator();
		while (iter.hasNext())
		{
			MarkupItem mark = iter.next();
			assertOnNode(mark, lens);
			count = count + 1;
		}
			if ((options.getVerbosity_overall() >= 1) && (options.isLog_searchWithWildAttsAndAssert())) // Output Log
			{
				System.out.println("Applier: asserted lens "+lens.getName()+" on node type "+gid+" "+count+" times");
			}
	}
	
	/**
	 * This method creates a new EARMARK Element in the document over which the Applier is currently working
	 * This is a simple wrapper method for the document.creatElement(id, gi, ns, type) of EARMARK API.
	 * 
	 * @param id The desired ID of the new Element
	 * @param gid The general identifier of the MarkupItems to be created in the document
	 * @param ns The namespace of the MarkupItems to be created in the document
	 * @param type The desired EARMARKType of the new Element (not to be confused with the rdf:type)
	 * @throws URISyntaxException if the ns or the id will not be parsed correctly as a valid URI
	 */
	public void newEmElement (String id, String gid, String ns, Collection.Type type) throws URISyntaxException {
		// Un semplice wrapper per il document.createElement(id, gi, ns, type) delle Api Earmark;
		URI totaluri = new URI (ns+id);
		if ((options.getVerbosity_overall() >= 4) && (options.isLog_newEMElement())) // Output Log
		{
			System.out.println("Applier Debug: Obtained URI "+totaluri+" from Strings: " +ns+id);
		}
		try {
			// document.createElement(id, gid, nsuri, type); --> Unexpected behaviour, not using this.
			document.createElement(totaluri, gid, type);
		} catch (ExistingIdException extId) {
			System.err.println("Applier Error - Existing Id Exception Caught in creating a new element" +
					" An Element with id: " + id + " gid: " + gid + " and ns: " + ns + " already exists in the document");
		}
		if ((options.getVerbosity_overall() >= 3) && (options.isLog_newEMElement())) // Output Log
		{
			System.out.println("Applier Verbose: The new Element with id: " + id + " gid: " + gid + " and ns: " + ns + " has been succesfully created");
		}
	}
		
	/**
	 * This method simply creates a new PointerRange in the EARMARKDocument on which the Applier is working
	 * It is a simple wrapper method for the document.createPointerRange(name, docuverse, begins, ends) of the EARMARK API
	 * 
	 * @param name the identifier of the new PointerRange that is to be created
	 * @param begins the start of new PointerRange
	 * @param ends the end of the new PointerRange
	 * @param refdocuverse the Docuverse to which this new PointerRange will be referring
	 * @throws URISyntaxException if the name of the docuverse will not be parsed correctly as a valid URI
	 */
	public void newPointerRange (String name, int begins, int ends, String refdocuverse) throws URISyntaxException {
		Docuverse docuverse = (Docuverse) findSingleItem(refdocuverse);
		if (!(docuverse.getType().equals(Docuverse.Type.StringDocuverse) || docuverse.getType().equals(Docuverse.Type.URIDocuverse)))
		{
			System.err.println("Applier Error in creating new Pointer Range: Cannot find the required docuverse " + refdocuverse);
		}
		try {
			document.createPointerRange(name, docuverse, begins, ends);
			if ((options.getVerbosity_overall() >= 3) && (options.isLog_newPointerRange())) // Output Log
			{
				System.out.println("Applier Verbose: The new pointer range " + begins + "-" + ends + " with id " + name + " has been succesfully created");
			}
		} catch (ExistingIdException extId) {
			System.err.println("Applier Error - Pointer Range Existing Id Exception Caught: " + extId + 
					"requested name: " + name);
		}
		
	}
		
	
	// GETTERS AND SETTERS
	/**
	 * @return the name
	 */
	@Override
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	@Override
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the lenstype
	 */
	public String getLenstype() {
		return lenstype;
	}
	/**
	 * @param lenstype the lenstype to set
	 */
	public void setLenstype(String lenstype) {
		this.lenstype = lenstype;
	}
	/**
	 * @return the storage
	 */
	public LensAnnotationCollection getStorage() {
		return storage;
	}
	/**
	 * @param storage the storage to set
	 */
	public void setStorage(LensAnnotationCollection storage) {
		this.storage = storage;
	}
	/**
	 * @return the document
	 */
	@Override
	public EARMARKDocument getDocument() {
		return document;
	}
	/**
	 * @param document the document to set
	 */
	@Override
	public void setDocument(EARMARKDocument document) {
		this.document = document;
	}
	/**
	 * @return the currentitem
	 */
	@Override
	public MarkupItem getCurrentitem() {
		return currentitem;
	}
	/**
	 * @param currentitem the currentitem to set
	 */
	@Override
	public void setCurrentitem(MarkupItem currentitem) {
		this.currentitem = currentitem;
	}
	/**
	 * @return the founditem
	 */
	@Override
	public EARMARKItem getCurrententity() {
		return currententity;
	}
	/**
	 * @param founditem the founditem to set
	 */
	@Override
	public void setCurrententity(EARMARKItem founditem) {
		this.currententity = founditem;
	}
	/**
	 * @return the currentnode
	 */
	public RDFNode getCurrentnode() {
		return currentnode;
	}
	/**
	 * @param currentnode the currentnode to set
	 */
	public void setCurrentnode(RDFNode currentnode) {
		this.currentnode = currentnode;
	}
	/**
	 * @return the currentproperty
	 */
	public Property getCurrentproperty() {
		return currentproperty;
	}
	/**
	 * @param currentproperty the currentproperty to set
	 */
	public void setCurrentproperty(Property currentproperty) {
		this.currentproperty = currentproperty;
	}
	/**
	 * @return the lastannotation
	 */
	public LensAnnotation getLastannotation() {
		return lastannotation;
	}
	/**
	 * @param lastannotation the lastannotation to set
	 */
	public void setLastannotation(LensAnnotation lastannotation) {
		this.lastannotation = lastannotation;
	}
	/**
	 * 
	 * @return
	 */
	
	/**
	 * @return the info
	 */
	public AppMetaInfo getInfo() {
		return info;
	}
	/**
	 * @param info the info to set
	 */
	public void setInfo(AppMetaInfo info) {
		this.info = info;
	}
	/**
	 * @return the options
	 */
	@Override
	public SemLensApplierPreferences getOptions() {
		return options;
	}
	/**
	 * @param options the options to set
	 */
	public void setOptions(SemLensApplierPreferences options) {
		this.options = options;
	}
	
}
