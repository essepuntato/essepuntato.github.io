package slam.utilities;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import it.essepuntato.earmark.core.MarkupItem;

/** 
 * This is a very simple utility class that contains tools used to systematically reduce a MarkupItem Set in a single or in multiple steps, 
 * by removing from it several other smaller Sets. 
 * It contains a baseset field with a Set of Markup Items, which is the original set from which the items should be removed, 
 * and methods to either remove all items except the ones specified in a smaller subsets or to remove from the baseset just those items part of the subset.
 * 
 * @author Jacopo Zingoni
 */
public class MarkupItemSetReducer {
	
	/**
	 * The original set from which the item should be removed
	 */
	private Set<MarkupItem> baseset;
	/**
	 * The last set of items to be removed from the baseset 
	 */
	private Set<MarkupItem> lastreducer;
	
	/**
	 * The basic constructor
	 * 
	 * @param base the Set of MarkupItem which is to be reduced
	 */
	public MarkupItemSetReducer (Set<MarkupItem> base) {
		this.baseset = base;
	}
	
	/**
	 * A method to remove from the baseset all the items included in the lastreducer Set of MarkupItems.
	 * 
	 * @return the resized baseset Set of MarkupItems
	 */
	public Set<MarkupItem> reduce()
	{
		baseset.removeAll(this.lastreducer);
		System.out.println("Reducer: Now the set has size " + baseset.size());
		return baseset;
	}
	
	/**
	 * A method to remove from the baseset all the items included in the removee parameter
	 * 
	 * @param removee the Set of MarkupItems to be removed from the baseset, which will become also the new lastreducer
	 * @return the resized baseset Set of MarkupItems
	 */
	public Set<MarkupItem> reduce(Set<MarkupItem> removee) {
		this.lastreducer = removee;
		return reduce();
	}
	
	/**
	 * A method to reduce the baseset by removing ALL items except the ones in the keeper Set of MarkupItem
	 * 
	 * @param keeper a Set of MarkupItem which contains all the items that are to be kept in the baseset
	 * @return a resized baseset purged of all items not part of the keeper Set
	 */
	public Set<MarkupItem> keep(Set<MarkupItem> keeper) {
		Iterator<MarkupItem> iter = this.baseset.iterator();
		HashSet<MarkupItem> newset = (HashSet<MarkupItem>) ((HashSet<MarkupItem>) this.baseset).clone();
		
		/* Iterator<MarkupItem> keepiter = keeper.iterator();
		System.out.println("Debug Reducer: " + keeper.size());
		while (keepiter.hasNext()){	MarkupItem keeperitem = keepiter.next();	System.out.println("Debug Reducer: " + keeperitem);	} */

		while (iter.hasNext())
		{
			MarkupItem currentitem = iter.next();
			// System.out.println("Debug Reducer: " + currentitem);
			// System.out.println("Debug Reducer: " + !(keeper.contains(currentitem)));
			if (!(keeper.contains(currentitem)))
			{
				// System.out.println("Debug Reducer: I am now removing from size: " + newset.size());
				newset.remove(currentitem);
			}
		}
		System.out.println("Reducer: Now the set has size " + newset.size());
		this.baseset = newset;
		return newset;
	}
	
	// GETTERS AND SETTERS
	/**
	 * @return the baseset
	 */
	public Set<MarkupItem> getBaseset() {
		return baseset;
	}

	/**
	 * @param baseset the baseset to set
	 */
	public void setBaseset(Set<MarkupItem> baseset) {
		this.baseset = baseset;
	}

	/**
	 * @return the lastreducer
	 */
	public Set<MarkupItem> getLastreducer() {
		return lastreducer;
	}

	/**
	 * @param lastreducer the lastreducer to set
	 */
	public void setLastreducer(Set<MarkupItem> lastreducer) {
		this.lastreducer = lastreducer;
	}
	

}
