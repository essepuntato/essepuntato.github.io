package slam.utilities;

import java.util.ArrayList;

/* Elenco di costanti che rappresentino le lenti semantiche */

public final class LensesTypes {
	
	public static final String RCONTEXT = "Research Context"; 
	
	public static final String CONTRIBUTION = "Contribution";
	
	public static final String PCONTEXT = "Publication Context";
	
	public static final String STRUCTURE = "Structure";
	
	public static final String RHETORIC = "Rhetoric";
	
	public static final String CITATION = "Citation";
	
	public static final String ARGUMENTATION = "Argumentation";
	
	public static final String SEMANTICS = "Semantics";
	
	public static final ArrayList<String> acceptedTypes = new ArrayList<String>(7);
	static {
		acceptedTypes.add(RCONTEXT);
		acceptedTypes.add(CONTRIBUTION);
		acceptedTypes.add(PCONTEXT);
		acceptedTypes.add(STRUCTURE);
		acceptedTypes.add(RHETORIC);
		acceptedTypes.add(CITATION);
		acceptedTypes.add(ARGUMENTATION);
		acceptedTypes.add(SEMANTICS);
	}
}
