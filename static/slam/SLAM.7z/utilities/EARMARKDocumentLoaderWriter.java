package slam.utilities;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.Map;

import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.util.FileManager;

import it.essepuntato.earmark.core.io.EARMARKWriter;
import it.essepuntato.earmark.core.io.JenaReader;
import it.essepuntato.earmark.core.EARMARKDocument;

/**
 * This is an utility class that assists the user in loading an EARMARKDocument from the filesystem, or in writing it in several different formats.
 * It can be used either to convert an EARMARKDocument to another representation (i.e: RDF-XML to TURTLE)
 * Or it can be used to save an EARMARKDocument after it has been modified, for example, after several lenses are applied to it.
 * It also allows to set namespaces. It is suggested to use maps defined in the LensesNames class
 * Out of simplicity, both output and input files should be in the same directory
 * 
 * @author Jacopo Zingoni
 *
 */
public class EARMARKDocumentLoaderWriter {
	
	/** the base pathname of the directory where the two files should be */
	private String basepath; 		/* path di base della directory dove si trovano i due file da convertire */
	/** This is the name of the input file to be loaded */
	private String inputdocname; 	/* nome del file di input */
	/** This is the desired filename for the output*/
	private String outputdocname; 	/* nome del file dove si desidera l'output */
	/** This is the input file path as an URI */
	private URI inputdocpath; 		/* URI del file in input per la conversione */
	/** This is the output file path as an URI */
	private URI outputdocpath; 		/* URI del file dove si desidera l'output */
	/** This is the handler for the input file, as a Java File type */
	private File inputfile; 		/* Handler del file in input*/
	/** This is the handler for the output file, as a Java File type */
	private File outputfile;		/* Handler del file in output*/
	/** This is the handler for the EARMARKDocument on which I am working */
	private EARMARKDocument currentdoc; /* Handler per l'EARMARKDocument sul documento su cui sto lavorando */
	/** This is the handler for the EARMARK JenaReader I am using */
	private JenaReader currentreader; 	/* Handler per uno JenaReader */
	
		// Costruttore 1: Tramite Stringhe
	/**
	 * The main constructor method for this class. 
	 * A LoaderWriter is created by setting a directory base path, an input and output filename, all as Strings
	 * 
	 * @param base the base pathname of the directory where the two files should be
	 * @param input the name of the input file to be loaded
	 * @param output the desired filename for the output
	 * @throws URISyntaxException if the resulting URI for the files path is not well formed
	 * @throws FileNotFoundException if the input file is not found or the output file cannot be created
	 */
	public EARMARKDocumentLoaderWriter(String base, String input, String output) throws URISyntaxException, FileNotFoundException {
		this.basepath = base;
		this.inputdocname = input;
		this.outputdocname = output;
		this.generateURIs(); // Scrivo gli URI interni al convertitore
		this.readyFiles(); // Preparo gli Handler dei Files
	}
		// Costruttore 2: Direttamente con degli URI
	/**
	 * Another constructor method for this class. 
	 * A LoaderWriter is created by setting directly the two desired input and output URIs for it
	 * 
	 * @param inputURI 	This is the input file path as an URI
	 * @param outputURI This is the desired output file path as an URI
	 * @throws FileNotFoundException if the input file is not found or the output file cannot be created
	 */
	public EARMARKDocumentLoaderWriter(URI inputURI, URI outputURI) throws FileNotFoundException {
		this.inputdocpath = inputURI;
		this.outputdocpath = outputURI;
		this.readyFiles(); // Preparo gli Handler dei Files
	}
		// Invocata dal Constr sulle stringhe: Assembla gli URI interni del convertitore a partire delle stringhe
	/**
	 * A very simple method just to create the URIs from the String parameters
	 * 
	 * @throws URISyntaxException if the resulting URI for the files path is not well formed
	 */
	public void generateURIs() throws URISyntaxException {
		this.inputdocpath = new URI (basepath + inputdocname);
		this.outputdocpath = new URI (basepath + outputdocname);
	}
		// Invocata dal Constr: Prepara gli handler dei file
	/**
	 * A very simple method to create the File handlers to the required input and output files
	 * 
	 * @throws FileNotFoundException if the input file is not found or the output file cannot be created
	 */
	public void readyFiles() throws FileNotFoundException {
		this.inputfile = new File(inputdocpath);
		this.outputfile = new File(outputdocpath);
		System.out.println("LoaderWriter - File Handlers Completed and Ready"); // Just to Debug
	}

	// Metodo per caricare il file di input e preparare lo Jena Reader
	/**
	 * This method loads the Input File as an EARMARKDocument and creates a new JenaReader to read it
	 * 
	 * @throws FileNotFoundException if the input file is not found
	 */
	public void loadInputFile() throws FileNotFoundException {
		System.out.println(Charset.defaultCharset()); // Giusto per controllare
		
		currentdoc = new EARMARKDocument(outputdocpath);	/* Preparo il documento Earmark - E gli assegno l'URI di output  */
		currentreader = new JenaReader();	/* Creo un lettore Jena */
		
		currentdoc = currentreader.read(inputfile);		/* Lo JenaReader carica il file all'URI di input - e lo assegno al currentdoc EARMARK */
		
		System.out.println("Debug: Reader has loaded the input file loaded correctly from: " + this.inputdocpath); // Just to check
	}
	
	
	/* 
	 * Prova per vedere che succede con sta roba qua - caricamento del file TURTLE (al momento buggato) 
	 * */
	public void loadTurtleInputFile() throws FileNotFoundException {
		System.out.println(Charset.defaultCharset()); // Giusto per controllare
		currentdoc = new EARMARKDocument(outputdocpath);	/* Preparo il documento Earmark - E gli assegno l'URI di output  */
		/* ECCO DOVE STAVA LA GABOLA, QUESTO E' UN LETTORE JENA CHE NON E' DI JENA, BENSI E' UNO JENAREADER DI EARMARK */
		/* Apparentemente Ora il problema risulta corretto */
		

		// create an empty model
		Model model = ModelFactory.createDefaultModel();

		// use the FileManager to find the input file
		InputStream in = FileManager.get().open( this.basepath + this.inputdocname );
		if (in == null) {
		    throw new IllegalArgumentException(
		                                 "File: " + basepath+inputdocname + " not found");
		}
		// read the Turtle file
		model.read(in, null, EARMARKWriter.TURTLE);		
		// model.write(System.out);
		/* Allora il modello lo carico tranquillamente */
		/* PERTANTO I CAZZI SON QUA */
		currentdoc = EARMARKDocument.load(model);
		
		/* ECCOLI I CAZZI */
		System.out.println("Hey LOOK AT ME!");
		System.out.println((EARMARKDocument.load(model)).getTextContent());
		System.out.println((EARMARKDocument.load(model)).toString());
		System.out.println((EARMARKDocument.load(model)).getDocumentAsTurtle());
		
		/* PER QUALE MOTIVO NON VA IL METODO LOAD? - PROBABILE BUG */
		System.out.println(currentdoc.toString());
		System.out.println("Debug: Input TURTLE file loaded correctly"); // Just to check
	}
	
	// Metodo di scrittura in cui posso passare come parametro il formato di output desiderato
	/**
	 * The main method used to output and to write the loaded EARMARKDocument on to the filesystem, usually after some operations have been performed on it
	 * This version of the method allows to set namespaces prior to writing the output
	 * 
	 * @param outputform the desired output format, i.e.: TURTLE or XML-RDF. Most are premade in the EARMARKWriter class of the EARMARK API
	 * @param namespaces the required abbreviation:namespaceuri pairings to be used in the document. Some premade maps are in the LensesNames class
	 * @throws FileNotFoundException if the outputfile cannot be handled
	 */
	public void writeToFormatWithNS(String outputform, Map<String,String> namespaces) throws FileNotFoundException {
		
		// Debug INFO
		System.out.println(outputform);
		System.out.println(namespaces);
		
		currentdoc.store(outputfile, outputform, namespaces);	// This method is just Syntactic Sugar for the Store method of EAMARKDocument
		
		System.out.println("Done Writing. Format: " + outputform + " Written - Added selected namespaces");
	}

	// Metodo di conversione in cui posso passare come parametro il formato di output desiderato
	/**
	 * The main method used to output and to write the loaded EARMARKDocument on to the filesystem, usually after some operations have been performed on it
	 * This is a short version, which doesn't require namespaces setup, and mantains the ones already set in the document
	 * 
	 * @param outputform the desired output format, i.e.: TURTLE or XML-RDF. Most are premade in the EARMARKWriter class of the EARMARK API
	 * @throws FileNotFoundException if the outputfile cannot be handled
	 */
	public void writeToFormat(String outputform) throws FileNotFoundException {
		
		currentdoc.store(outputfile, outputform); /* Il file in output viene riscritto dal documento EARMARK nel formato specificato */
		
		System.out.println("Done Writing. Format: " + outputform + " Written");
	}
	
	// Uno dei metodi di conversione: Da RDF-XML a Turtle
	/**
	 * Just a shortcut to write the input document directly to the filesystem in the TURTLE format
	 * 
	 * @throws FileNotFoundException if the outputfile cannot be handled
	 */
	public void writeToTurtle() throws FileNotFoundException {

		currentdoc.store(outputfile, EARMARKWriter.TURTLE);	/* Il file in output viene riscritto dal documento Earmark in formato TURTLE */
		
		System.out.println("Done writing - Turtle document ready");
	}
	
	// Uno dei metodi di conversione: Da Turtle a RDF-XML
	/**
	 * Just a shortcut to write the input document directly to the filesystem in the RDF-XML format
	 * 
	 * @throws FileNotFoundException if the outputfile cannot be handled
	 */
	public void writeToRDF() throws FileNotFoundException {
		
		currentdoc.store(outputfile, EARMARKWriter.RDFXML);	/* Il file in output viene riscritto dal documento Earmark in formato RDF-XML */
		
		System.out.println("Done writing - RDF_XML document ready");
	}
	
	/* Metodo statico per settare namespaces su un documento -- Dubbi sul funzionamento corretto causa bug di EARMARK */
	public static EARMARKDocument setNamespaces(EARMARKDocument doc, Map<String,String> namespaces)
	{
		Model jenadocmodel = doc.getDocumentAsModel();
		
		jenadocmodel.setNsPrefixes(namespaces);
		
		// jenadocmodel.write(System.out); // Debug di controllo per verificare se nello Jena Model i namespace sono inseriti correttamente, e SI, lo sono.
		// Perchè si perdono a ripassare in Earmark?
		
		EARMARKDocument finaldoc = EARMARKDocument.load(jenadocmodel);
		
		// Ma se facessi invece...
		// EARMARKDocument finaldoc = EARMARKDocument.getReader().read(jenadocmodel);
		// Probabilmente non andrà lo stesso.
		
		return finaldoc;
	}
	
	/*	
	// Il metodo per settare namespaces prima di scegliere il formato di output
	public void setLensesNamespaces_Old() throws FileNotFoundException {
		
		Model jenamodel = currentdoc.getDocumentAsModel(); // Converto il file in un modello Jena
		
		 Di base dovrebbero essere sempre già settati, quindi li skippo 
		// jenamodel.setNsPrefix(LensesNames.CO_NS, LensesNames.CO_URI);
		// jenamodel.setNsPrefix(LensesNames.EM_NS, LensesNames.EM_URI);
		// jenamodel.setNsPrefix(LensesNames.EMOVER_NS, LensesNames.EMOVER_URI);
		
		jenamodel.setNsPrefix(LensesNames.LA_NS, LensesNames.LA_URI);	// Linguistic Act per LA:expresses
		
		jenamodel.setNsPrefix(LensesNames.PATTERN_NS, LensesNames.PATTERN_URI);		// Patterns
		jenamodel.setNsPrefix(LensesNames.DOCO_NS, LensesNames.DOCO_URI);			// Document Component Ontology
		jenamodel.setNsPrefix(LensesNames.DEO_NS, LensesNames.DEO_URI);				// Discourse Elements Ontology
		jenamodel.setNsPrefix(LensesNames.CITO_NS, LensesNames.CITO_URI);			// Citation Typing Ontology
		jenamodel.setNsPrefix(LensesNames.AMO_NS, LensesNames.AMO_URI);				// Argument Model Ontology
		
		// jenamodel.write(System.out); // Ho verificato, nello Jena Model i namespace sono inseriti correttamente
		// Perchè si perdono a ripassare in Earmark?
		
		currentdoc = EARMARKDocument.load(jenamodel); // Load è un metodo statico - ricarico lo jenamodel nel mio documento
	}
	*/
	
	
	/* Getters e Setters Autogenerati */
	
	/**
	 * @return the basepath
	 */
	public String getBasepath() {
		return basepath;
	}
	/**
	 * @param basepath the basepath to set
	 */
	public void setBasepath(String basepath) {
		this.basepath = basepath;
	}
	/**
	 * @return the inputdocname
	 */
	public String getInputdocname() {
		return inputdocname;
	}
	/**
	 * @param inputdocname the inputdocname to set
	 */
	public void setInputdocname(String inputdocname) {
		this.inputdocname = inputdocname;
	}
	/**
	 * @return the outputdocname
	 */
	public String getOutputdocname() {
		return outputdocname;
	}
	/**
	 * @param outputdocname the outputdocname to set
	 */
	public void setOutputdocname(String outputdocname) {
		this.outputdocname = outputdocname;
	}
	/**
	 * @return the inputdocpath
	 */
	public URI getInputdocpath() {
		return inputdocpath;
	}
	/**
	 * @param inputdocpath the inputdocpath to set
	 */
	public void setInputdocpath(URI inputdocpath) {
		this.inputdocpath = inputdocpath;
	}
	/**
	 * @return the outputdocpath
	 */
	public URI getOutputdocpath() {
		return outputdocpath;
	}
	/**
	 * @param outputdocpath the outputdocpath to set
	 */
	public void setOutputdocpath(URI outputdocpath) {
		this.outputdocpath = outputdocpath;
	}
	/**
	 * @return the inputfile
	 */
	public File getInputfile() {
		return inputfile;
	}
	/**
	 * @param inputfile the inputfile to set
	 */
	public void setInputfile(File inputfile) {
		this.inputfile = inputfile;
	}
	/**
	 * @return the outputfile
	 */
	public File getOutputfile() {
		return outputfile;
	}
	/**
	 * @param outputfile the outputfile to set
	 */
	public void setOutputfile(File outputfile) {
		this.outputfile = outputfile;
	}
	/**
	 * @return the currentdoc
	 */
	public EARMARKDocument getCurrentdoc() {
		return currentdoc;
	}
	/**
	 * @param currentdoc the currentdoc to set
	 */
	public void setCurrentdoc(EARMARKDocument currentdoc) {
		this.currentdoc = currentdoc;
	}
	/**
	 * @return the currentreader
	 */
	public JenaReader getCurrentreader() {
		return currentreader;
	}
	/**
	 * @param currentreader the currentreader to set
	 */
	public void setCurrentreader(JenaReader currentreader) {
		this.currentreader = currentreader;
	}

}
