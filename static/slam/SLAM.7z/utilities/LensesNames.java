package slam.utilities;

import java.util.HashMap;

public final class LensesNames {
	
	/* Collections Ontology part of the SWAN Ontlogy Suite */
	public static final String CO_NS = "co";
	public static final String CO_URI = "http://swan.mindinformatics.org/ontologies/1.2/collections/";
	
	/* Linguistic Acts Ontology */
	public static final String LA_NS = "la";
	public static final String LA_URI = "http://www.ontologydesignpatterns.org/cp/owl/semiotics.owl#";
	
	/* EARMARK Ontologies */
	public static final String EM_NS = "earmark";
	public static final String EM_URI = "http://www.essepuntato.it/2008/12/earmark#";
	public static final String EMOVER_NS = "emoverlaps";
	public static final String EMOVER_URI = "http://www.essepuntato.it/2011/05/overlapping/";
	public static final String OVERTRICKS_NS = "overlaptricks";
	public static final String OVERTRICKS_URI = "http://www.rolfini.it/semanticweb/overlaptricksEAR#";
	
	/* Structural Patterns Ontology */
	public static final String PATTERN_NS = "pattern";
	public static final String PATTERN_URI = "http://www.essepuntato.it/2008/12/pattern#";
	
	/* Document Components Ontology, as defined in the SPAR ontology Suite */
	public static final String DOCO_NS = "doco";
	public static final String DOCO_URI = "http://purl.org/spar/doco/";
	
	/* Discourse Elements Ontology, as defined in the SPAR ontology Suite */
	public static final String DEO_NS = "deo";
	public static final String DEO_URI = "http://purl.org/spar/deo/";
	
	/* Citation Typing Ontology, as defined in the SPAR ontology Suite */
	public static final String CITO_NS = "cito";
	public static final String CITO_URI = "http://purl.org/spar/cito/";
	
	/* Argument Model Ontology, as defined in the SPAR ontlogy Suite */
	public static final String AMO_NS = "amo";
	public static final String AMO_URI = "http://purl.org/spar/amo/";
	
	/* EARMARK SWEX Document namespace - base NS - not added */
	public static final String SWEX_URI = "http://www.essepuntato.it/2010/04/SWWEx";
	public static final String SWEX_URI2 = "http://www.essepuntato.it/2010/04/SWWEx#";
	public static final String SWEX_URI3 = "http://www.essepuntato.it/2010/04/SWWEx/";
	public static final String EMPTY_URI = "";
	
	/* Creo una mappa per tutte queste coppie */
	public static HashMap<String,String> prefixNSMapLite = new HashMap<String, String>();
	static {
		HashMap<String,String> aMap = new HashMap<String, String>();
		aMap.put(LA_NS, LA_URI);
		aMap.put(PATTERN_NS, PATTERN_URI);
		aMap.put(DOCO_NS, DOCO_URI);
		aMap.put(DEO_NS, DEO_URI);
		aMap.put(CITO_NS, CITO_URI);
		aMap.put(AMO_NS, AMO_URI);
		prefixNSMapLite = aMap;
		// System.out.println(prefixNSMapLite);
	}
	public static HashMap<String,String> prefixNSMapFull = new HashMap<String, String>();
	static {
		HashMap<String,String> aMap = new HashMap<String, String>();
		aMap.put(LA_NS, LA_URI);
		aMap.put(PATTERN_NS, PATTERN_URI);
		aMap.put(DOCO_NS, DOCO_URI);
		aMap.put(DEO_NS, DEO_URI);
		aMap.put(CITO_NS, CITO_URI);
		aMap.put(AMO_NS, AMO_URI);
		aMap.put(CO_NS, CO_URI);
		aMap.put(EM_NS, EM_URI);
		aMap.put(EMOVER_NS, EMOVER_URI);
		aMap.put(OVERTRICKS_NS, OVERTRICKS_URI);
		prefixNSMapFull = aMap;
		// System.out.println(prefixNSMapFull);
	}
	
}
