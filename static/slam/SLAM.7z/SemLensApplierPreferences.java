package slam;

/**
 * Class with all the options and preferences on the behaviour of a SemLensApplier
 * It is mainly used to set the options of the output log during an annotation.
 * 
 * As a reminder, the SemLensApplier Class extends the EarmarkFinder Class.
 * The same is true for the preferences: this class extends the EarmarkFinderPreferences Class 
 * 
 * @author Jacopo Zingoni
 */
public class SemLensApplierPreferences extends EarmarkFinderPreferences {
	
	/**
	 * A field to regulate the overall verbosity of the output log
	 * 
	 * Allowed levels:
	 * 4 = "debug" => Highest level of messaging
	 * 3 = "high" => Most of the output will appear in the log
	 * 2 = "medium" => Default setting, most of the important messages and notifications will appear in the log
	 * 1 = "low" => Only the most important output will appear in the log
	 * 0 = "silent" => As silent as it can be.
	 */
	private int verbosity_overall = 2;
	
	/* Flags to disable the output in a single method */
	
	/** This flag is used to allow/mute the System.out messages for the createProperty method of the Applier */
	private boolean log_createProperty = true;
	/** This flag is used to allow/mute the System.out messages for the createJenaResObject method of the Applier */
	private boolean log_createJenaResObject = true;
	
	/** This flag is used to allow/mute the System.out messages for the buildAnnotation method of the Applier */
	private boolean log_buildAnnotation = true;
	/** This flag is used to allow/mute the System.out messages for the buildEMAnnotation method of the Applier */
	private boolean log_buildEMAnnotation = true;
	
	/** This flag is used to allow/mute the System.out messages for the assertOnNode method of the Applier */
	private boolean log_assertOnNode = true;
	/** This flag is used to allow/mute the System.out messages for the assertOnNodeEM method of the Applier */
	private boolean log_assertOnNodeEM = true;
	/** This flag is used to allow/mute the System.out messages for the assertOnSet method of the Applier */
	private boolean log_assertOnSet = true;
	/** This flag is used to allow/mute the System.out messages for the assertOnSetEM method of the Applier */
	private boolean log_assertOnSetEM = true;
	
	/** This flag is used to allow/mute the System.out messages for the searchAndAssert method of the Applier */
	private boolean log_searchAndAssert = true;
	/** This flag is used to allow/mute the System.out messages for the searchAndAssertEM method of the Applier */
	private boolean log_searchAndAssertEM = true;
	/** This flag is used to allow/mute the System.out messages for the recoverAndAssert method of the Applier */
	private boolean log_recoverAndAssert = true;
	/** This flag is used to allow/mute the System.out messages for the recoverAndAssertEM method of the Applier */
	private boolean log_recoverAndAssertEM = true;
	
	/** This flag is used to allow/mute the System.out messages for the massAnnotate method of the Applier */
	private boolean log_massAnnotate = true;
	
	/** This flag is used to allow/mute the System.out messages for the searchWithAttsAndAssert method of the Applier */
	private boolean log_searchWithAttsAndAssert = true;
	/** This flag is used to allow/mute the System.out messages for the searchWithWildAttsAndAssert method of the Applier */
	private boolean log_searchWithWildAttsAndAssert = true;
	
	/** This flag is used to allow/mute the System.out messages for the newEMElement method of the Applier */
	private boolean log_newEMElement = true;
	/** This flag is used to allow/mute the System.out messages for the newPointerRange method of the Applier */
	private boolean log_newPointerRange = true;
	
	/** This flag is used to allow/mute the System.out messages for the private statistical sub-methods of the Applier */
	private boolean log_privatestatsmethods = false;
	/** This flag is used to allow/mute the System.out messages for the the private wildcard sub-methods of the Applier */
	private boolean log_privatewildmethods = false;
	
	/* To allow statistical recording */
	/** This flag is used to allow the recording of stats by the Applier MetaInfo statistical module */
	private boolean allow_stats = true;
	
	
	
	/**
	 * Generic Empty Constructor
	 */
	public SemLensApplierPreferences() {
		// Nothing important goes here
		super();
	}


	// 	GETTERS AND SETTERS
	/**
	 * @return the verbosity_overall
	 */
	public int getVerbosity_overall() {
		return verbosity_overall;
	}


	/**
	 * @param verbosity_overall the verbosity_overall to set
	 */
	public void setVerbosity_overall(int verbosity_overall) {
		if ((verbosity_overall < 0) || (verbosity_overall > 5))
		{
			System.err.println("Error, unacceptable parameters for the logging options: verbosity must be between 0 and 5");
		}
		this.verbosity_overall = verbosity_overall;
	}
	/**
	 * @return the log_createProperty
	 */
	public boolean isLog_createProperty() {
		return log_createProperty;
	}
	/**
	 * @param log_createProperty the log_createProperty to set
	 */
	public void setLog_createProperty(boolean log_createProperty) {
		this.log_createProperty = log_createProperty;
	}
	/**
	 * @return the log_createJenaResObject
	 */
	public boolean isLog_createJenaResObject() {
		return log_createJenaResObject;
	}
	/**
	 * @param log_createJenaResObject the log_createJenaResObject to set
	 */
	public void setLog_createJenaResObject(boolean log_createJenaResObject) {
		this.log_createJenaResObject = log_createJenaResObject;
	}
	/**
	 * @return the log_buildAnnotation
	 */
	public boolean isLog_buildAnnotation() {
		return log_buildAnnotation;
	}
	/**
	 * @param log_buildAnnotation the log_buildAnnotation to set
	 */
	public void setLog_buildAnnotation(boolean log_buildAnnotation) {
		this.log_buildAnnotation = log_buildAnnotation;
	}
	/**
	 * @return the log_buildEMAnnotation
	 */
	public boolean isLog_buildEMAnnotation() {
		return log_buildEMAnnotation;
	}
	/**
	 * @param log_buildEMAnnotation the log_buildEMAnnotation to set
	 */
	public void setLog_buildEMAnnotation(boolean log_buildEMAnnotation) {
		this.log_buildEMAnnotation = log_buildEMAnnotation;
	}
	/**
	 * @return the log_assertOnNode
	 */
	public boolean isLog_assertOnNode() {
		return log_assertOnNode;
	}
	/**
	 * @param log_assertOnNode the log_assertOnNode to set
	 */
	public void setLog_assertOnNode(boolean log_assertOnNode) {
		this.log_assertOnNode = log_assertOnNode;
	}
	/**
	 * @return the log_assertOnNodeEM
	 */
	public boolean isLog_assertOnNodeEM() {
		return log_assertOnNodeEM;
	}
	/**
	 * @param log_assertOnNodeEM the log_assertOnNodeEM to set
	 */
	public void setLog_assertOnNodeEM(boolean log_assertOnNodeEM) {
		this.log_assertOnNodeEM = log_assertOnNodeEM;
	}
	/**
	 * @return the log_assertOnSet
	 */
	public boolean isLog_assertOnSet() {
		return log_assertOnSet;
	}
	/**
	 * @param log_assertOnSet the log_assertOnSet to set
	 */
	public void setLog_assertOnSet(boolean log_assertOnSet) {
		this.log_assertOnSet = log_assertOnSet;
	}
	/**
	 * @return the log_assertOnSetEM
	 */
	public boolean isLog_assertOnSetEM() {
		return log_assertOnSetEM;
	}
	/**
	 * @param log_assertOnSetEM the log_assertOnSetEM to set
	 */
	public void setLog_assertOnSetEM(boolean log_assertOnSetEM) {
		this.log_assertOnSetEM = log_assertOnSetEM;
	}
	/**
	 * @return the log_searchAndAssert
	 */
	public boolean isLog_searchAndAssert() {
		return log_searchAndAssert;
	}
	/**
	 * @param log_searchAndAssert the log_searchAndAssert to set
	 */
	public void setLog_searchAndAssert(boolean log_searchAndAssert) {
		this.log_searchAndAssert = log_searchAndAssert;
	}
	/**
	 * @return the log_searchAndAssertEM
	 */
	public boolean isLog_searchAndAssertEM() {
		return log_searchAndAssertEM;
	}
	/**
	 * @param log_searchAndAssertEM the log_searchAndAssertEM to set
	 */
	public void setLog_searchAndAssertEM(boolean log_searchAndAssertEM) {
		this.log_searchAndAssertEM = log_searchAndAssertEM;
	}
	/**
	 * @return the log_recoverAndAssert
	 */
	public boolean isLog_recoverAndAssert() {
		return log_recoverAndAssert;
	}
	/**
	 * @param log_recoverAndAssert the log_recoverAndAssert to set
	 */
	public void setLog_recoverAndAssert(boolean log_recoverAndAssert) {
		this.log_recoverAndAssert = log_recoverAndAssert;
	}
	/**
	 * @return the log_recoverAndAssertEM
	 */
	public boolean isLog_recoverAndAssertEM() {
		return log_recoverAndAssertEM;
	}
	/**
	 * @param log_recoverAndAssertEM the log_recoverAndAssertEM to set
	 */
	public void setLog_recoverAndAssertEM(boolean log_recoverAndAssertEM) {
		this.log_recoverAndAssertEM = log_recoverAndAssertEM;
	}
	/**
	 * @return the log_massAnnotate
	 */
	public boolean isLog_massAnnotate() {
		return log_massAnnotate;
	}
	/**
	 * @param log_massAnnotate the log_massAnnotate to set
	 */
	public void setLog_massAnnotate(boolean log_massAnnotate) {
		this.log_massAnnotate = log_massAnnotate;
	}
	/**
	 * @return the log_findItemsWithAtts
	 */
	/**
	 * @return the log_searchWithAttsAndAssert
	 */
	public boolean isLog_searchWithAttsAndAssert() {
		return log_searchWithAttsAndAssert;
	}
	/**
	 * @param log_searchWithAttsAndAssert the log_searchWithAttsAndAssert to set
	 */
	public void setLog_searchWithAttsAndAssert(boolean log_searchWithAttsAndAssert) {
		this.log_searchWithAttsAndAssert = log_searchWithAttsAndAssert;
	}
	/**
	 * @return the log_searchWithWildAttsAndAssert
	 */
	public boolean isLog_searchWithWildAttsAndAssert() {
		return log_searchWithWildAttsAndAssert;
	}
	/**
	 * @param log_searchWithWildAttsAndAssert the log_searchWithWildAttsAndAssert to set
	 */
	public void setLog_searchWithWildAttsAndAssert(
			boolean log_searchWithWildAttsAndAssert) {
		this.log_searchWithWildAttsAndAssert = log_searchWithWildAttsAndAssert;
	}
	/**
	 * @return the log_newElement
	 */
	public boolean isLog_newEMElement() {
		return log_newEMElement;
	}
	/**
	 * @param log_newElement the log_newElement to set
	 */
	public void setLog_newEMElement(boolean log_newEMElement) {
		this.log_newEMElement = log_newEMElement;
	}
	/**
	 * @return the log_newPointerRange
	 */
	public boolean isLog_newPointerRange() {
		return log_newPointerRange;
	}
	/**
	 * @param log_newPointerRange the log_newPointerRange to set
	 */
	public void setLog_newPointerRange(boolean log_newPointerRange) {
		this.log_newPointerRange = log_newPointerRange;
	}
	/**
	 * @return the log_privatestatsmethods
	 */
	public boolean isLog_privatestatsmethods() {
		return log_privatestatsmethods;
	}
	/**
	 * @param log_privatestatsmethods the log_privatestatsmethods to set
	 */
	public void setLog_privatestatsmethods(boolean log_privatestatsmethods) {
		this.log_privatestatsmethods = log_privatestatsmethods;
	}
	/**
	 * @return the log_privatewildmethods
	 */
	public boolean isLog_privatewildmethods() {
		return log_privatewildmethods;
	}
	/**
	 * @param log_privatewildmethods the log_privatewildmethods to set
	 */
	public void setLog_privatewildmethods(boolean log_privatewildmethods) {
		this.log_privatewildmethods = log_privatewildmethods;
	}

	/**
	 * @return the allow_stats
	 */
	public boolean isAllow_stats() {
		return allow_stats;
	}
	/**
	 * @param allow_stats the allow_stats to set
	 */
	public void setAllow_stats(boolean allow_stats) {
		this.allow_stats = allow_stats;
	}


}
