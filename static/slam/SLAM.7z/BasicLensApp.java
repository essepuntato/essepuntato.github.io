package slam;

import java.net.URISyntaxException;

/**
 * This abstract class implements the interface SemLensApplication, but in order to be concretely used by any project it has to be extended by a concrete class,
 * one for any single semantic lens we want to apply to a given document.  
 * It is simply a skeleton class for the implementation of the main Interface SemLensApplication.
 * 
 * @author Jacopo Zingoni
 */
public abstract class BasicLensApp implements SemLensApplication {
	
	/**
	 * This is the Applier specific to this Lens Application
	 */
	private SemLensApplier applier;

	
	/**
	 * This is the public method that contains all the instructions to annotate a Lens, using an Applier contained by the concrete class.
	 */
	@Override
	public abstract void annotate() throws URISyntaxException;

	// Getters and Setters
	@Override
	public final SemLensApplier getApplier() {
		return this.applier;
	}

	@Override
	public final void setApplier(SemLensApplier applier) {
		this.applier = applier;
	}

}
