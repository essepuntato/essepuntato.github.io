package slam;

import java.util.AbstractMap;
import java.util.AbstractMap.SimpleEntry;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

/**
 * This class is a generic Black Box for meta-information on a Semantic Lens Applier, represented by the SemLensApplier class
 * 
 * Objects of this class are located inside said SemLensApplier(s), 
 * They contain an AuthorMetaInfo class to store information on the SemLens Application author, and several statistical recording methods for the Applier
 *  
 * 
 * @author Jacopo Zingoni
 * 
 */
public class AppMetaInfo {
	
	/**
	 * A field containing an AuthorMetaInfo, a class used to store information on the author of a Semantic Lens Application 
	 */
	private AuthorMetaInfo author;
	
	
	/*
	 * Statistic Section
	 * 
	 */
	
	/**
	 * A private field, counting the total number of annotations recorded by the applier
	 */
	private int totalannotations = 0;
	
	
	/**
	 * A private field, used to associate each assertion used by the Applier with an Integer counting how many times it has been used by it.
	 */
	private HashMap <String, Integer> assertions = new HashMap<String, Integer>();
	
	/**
	 * A private field, used to associate each property used by the Applier with an Integer counting how many times it has been used by it.
	 */
	private HashMap <String, Integer> properties = new HashMap<String, Integer>();
	
	// Generic Constructor
	/**
	 * A generic, empty constructor
	 */
	public AppMetaInfo() {
	}
	
	
	/**
	 * This method is used to output how many times an Assertion present in the assertions HashMap is used
	 * It outputs the result on the System.out
	 * 
	 * @param assertion the String with the name of the assertion
	 * 
	 * @return an integer counting how many times said assertion has been used
	 */
	public int assertionTimes(String assertion) {
		if (assertions.containsKey(assertion))
		{
			int timesresult = assertions.get(assertion);
			System.out.println("Number of times the assertion keyed " + assertion + " is used: " + timesresult);
			return timesresult;
		}
		else {
			System.err.println("SemLensApplier Statistic Module in App Meta Info: Couldn't find assertion keyed: " + assertion);
			return 0;
		}
	}
	
	/**
	 * This method is used to output how many times a Property present in the properties HashMap is used.
	 * It outputs the result on the System.out
	 * 
	 * @param property the String with the name of the property
	 * 
	 * @return an integer counting how many times said property has been used
	 */
	public int propertyTimes(String property) {
		if (properties.containsKey(property))
		{
			int timesresult = properties.get(property);
			System.out.println("Number of times the properties with predicate " + property + " is used: " + timesresult);
			return timesresult;
		}
		else {
			System.err.println("SemLensApplier Statistic Module in App Meta Info: Couldn't find property: " + property);
			return 0;
		}
	}
	/**
	 * This method is used to output how many different assertions are used in an Applier. 
	 * It simply counts the size of the assertions HashMap and outputs it on the System.out 
	 * 
	 * @return How many different assertions are used
	 */
	public int differentAssertions() {
		System.out.println("Number of different lenses annotation used: " + assertions.size());
		return assertions.size();
	}
	/**
	 * This method is used to output how many different properties are used in an Applier. 
	 * It simply counts the size of the properties HashMap and outputs it on the System.out 
	 * 
	 * @return How many different properties are used
	 */
	public int differentProperties() {
		System.out.println("Number of different properties used in the assertions: " + properties.size());
		return properties.size();
	}
	/**
	 * This method simply visits the entire HashMap for the assertions, and outputs the most used one (the one with the highest Value integer)
	 * It prints its results on the System.out as well
	 * 
	 * @return a SimpleEntry with the String used to identify the assertion and the Integer counting how many times it was used.
	 */
	public SimpleEntry<String, Integer> mostUsedAssertion() {
		Iterator<Entry<String,Integer>> iter = assertions.entrySet().iterator();
		AbstractMap.SimpleEntry<String,Integer> winner = new AbstractMap.SimpleEntry<String, Integer>("winner", 0);
		while (iter.hasNext())
		{
			Entry<String,Integer> entry = iter.next();
			if (entry.getValue() >= winner.getValue())
			{
				winner = new AbstractMap.SimpleEntry<String, Integer>(entry);
			}
		}
		System.out.println("Most used assertion is " + winner.getKey() + " and it's used " + winner.getValue() + " times");
		return winner;
	}
	/**
	 * This method simply visits the entire HashMap for the properties, and outputs the most used one (the one with the highest Value integer)
	 * It prints its results on the System.out as well
	 * 
	 * @return a SimpleEntry with the String used to identify the properties and the Integer counting how many times it was used.
	 */
	public SimpleEntry<String, Integer> mostUsedProperty() {
		Iterator<Entry<String,Integer>> iter = properties.entrySet().iterator();
		AbstractMap.SimpleEntry<String,Integer> winner = new AbstractMap.SimpleEntry<String, Integer>("winner", 0);
		while (iter.hasNext())
		{
			Entry<String,Integer> entry = iter.next();
			if (entry.getValue() >= winner.getValue())
			{
				winner = new AbstractMap.SimpleEntry<String, Integer>(entry);
				// winner = (SimpleEntry<String, Integer>) entry;
			}
		}
		System.out.println("Most used property is " + winner.getKey() + " and it's used " + winner.getValue() + " times");
		return winner;
	}
	/**
	 * This is a simple method that outputs on the System.out a small statistic summary about all the assertions used by an Applier  
	 */
	public void summaryOfAssertions() {
		System.out.println("\n Summary of Assertions used:");
		Iterator<String> iter = assertions.keySet().iterator();
		while (iter.hasNext())
		{
			assertionTimes(iter.next());
		}
		differentAssertions();
		mostUsedAssertion();
	}
	/**
	 * This is a simple method that outputs on the System.out a small statistic summary about all the properties used by an Applier  
	 */
	public void summaryOfProperties() {
		System.out.println("\n Summary of Properties used:");
		Iterator<String> iter = properties.keySet().iterator();
		while (iter.hasNext())
		{
			propertyTimes(iter.next());
		}
		differentProperties();
		mostUsedProperty();
	}
	/**
	 * This is a simple combo method that combines summaryOfAssertions() and summaryOfProperties.  
	 */
	public void summary() {
		System.out.println("\n \n Total annotations for this applications are: " + totalannotations);
		summaryOfAssertions();
		summaryOfProperties();
	}
	/**
	 * A simple method that is used inside the Applier to increment the totalannotations counter for this AppMetaInfo
	 */
	public void increaseTotal() {
		totalannotations = totalannotations + 1;
	}
	/**
	 * This method is a generalization of increaseTotal, allowing to specify how many times the totalannotations counter inside this class should be increased.
	 * So far it has been never used
	 * 
	 * @param add is the integer to be added
	 */
	public void increaseTotal(int add) {
		totalannotations = totalannotations + add;
	}
	
	// Getters and Setters
	/**
	 * @return the author
	 */
	public AuthorMetaInfo getAuthor() {
		return author;
	}

	/**
	 * @param author the author to set
	 */
	public void setAuthor(AuthorMetaInfo author) {
		this.author = author;
	}
	/**
	 * @return the totalannotations
	 */
	public int getTotalannotations() {
		return totalannotations;
	}

	/**
	 * @param totalannotations the totalannotations to set
	 */
	public void setTotalannotations(int totalannotations) {
		this.totalannotations = totalannotations;
	}

	/**
	 * @return the assertions
	 */
	public HashMap<String, Integer> getAssertions() {
		return assertions;
	}

	/**
	 * @param assertions the assertions to set
	 */
	public void setAssertions(HashMap<String, Integer> assertions) {
		this.assertions = assertions;
	}

	/**
	 * @return the properties
	 */
	public HashMap<String, Integer> getProperties() {
		return properties;
	}

	/**
	 * @param properties the properties to set
	 */
	public void setProperties(HashMap<String, Integer> properties) {
		this.properties = properties;
	}

	
}