package slam;

/**
 * Class with all the options and preferences on the behaviour of an EarmarkFinder
 * It is mainly used to set the options of the output log during an annotation.
 * 
 * @author Jacopo Zingoni
 */
public class EarmarkFinderPreferences {

	/**
	 * A field to regulate the overall verbosity of the output log
	 * 
	 * Allowed levels:
	 * 4 = "debug" => Highest level of messaging
	 * 3 = "high" => Most of the output will appear in the log
	 * 2 = "medium" => Default setting, most of the important messages and notifications will appear in the log
	 * 1 = "low" => Only the most important output will appear in the log
	 * 0 = "silent" => As silent as it can be.
	 */
	private int verbosity_finder = 2;
	
	
	/** This flag is used to allow/mute the System.out messages for the findSingleItem method of the Applier */
	private boolean log_findSingleItem = true;
	/** This flag is used to allow/mute the System.out messages for the findItemsByGID method of the Applier */
	private boolean log_findItemsByGID = true;
	/** This flag is used to allow/mute the System.out messages for the findItemsByGIDAndNS method of the Applier */
	private boolean log_findItemsByGIDAndNS = true;
	/** This flag is used to allow/mute the System.out messages for the findItemsWithAtts method of the Applier */
	private boolean log_findItemsWithAtts = true;
	/** This flag is used to allow/mute the System.out messages for the findItemsWithWildAtts method of the Applier */
	private boolean log_findItemsWithWildAtts = true;
	/** This flag is used to allow/mute the System.out messages for the findItemsExcept method of the Applier */
	private boolean log_findItemsExcept = true;
	/** This flag is used to allow/mute the System.out messages for the findItemsWithARangeOfIds method of the Applier */
	private boolean log_findItemsWithARangeOfIds = true;

	/**
	 * Generic Empty Constructor
	 */
	public EarmarkFinderPreferences() {
		super();
	}

	
	/**
	 * @return the verbosity_overall
	 */
	public int getVerbosity_finder() {
		return verbosity_finder;
	}
	/**
	 * @param verbosity_overall the verbosity_overall to set
	 */
	public void setVerbosity_finder(int verbosity_finder) {
		this.verbosity_finder = verbosity_finder;
	}

	/**
	 * @return the log_findSingleItem
	 */
	public boolean isLog_findSingleItem() {
		return log_findSingleItem;
	}
	/**
	 * @param log_findSingleItem the log_findSingleItem to set
	 */
	public void setLog_findSingleItem(boolean log_findSingleItem) {
		this.log_findSingleItem = log_findSingleItem;
	}
	
	/**
	 * @return the log_findItemsByGID
	 */
	public boolean isLog_findItemsByGID() {
		return log_findItemsByGID;
	}
	/**
	 * @param log_findItemsByGID the log_findItemsByGID to set
	 */
	public void setLog_findItemsByGID(boolean log_findItemsByGID) {
		this.log_findItemsByGID = log_findItemsByGID;
	}

	/**
	 * @return the log_findItemsByGIDAndNS
	 */
	public boolean isLog_findItemsByGIDAndNS() {
		return log_findItemsByGIDAndNS;
	}
	/**
	 * @param log_findItemsByGIDAndNS the log_findItemsByGIDAndNS to set
	 */
	public void setLog_findItemsByGIDAndNS(boolean log_findItemsByGIDAndNS) {
		this.log_findItemsByGIDAndNS = log_findItemsByGIDAndNS;
	}

	/**
	 * @return the log_findItemsWithAtts
	 */
	public boolean isLog_findItemsWithAtts() {
		return log_findItemsWithAtts;
	}
	/**
	 * @param log_findItemsWithAtts the log_findItemsWithAtts to set
	 */
	public void setLog_findItemsWithAtts(boolean log_findItemsWithAtts) {
		this.log_findItemsWithAtts = log_findItemsWithAtts;
	}

	/**
	 * @return the log_findItemsWithWildAtts
	 */
	public boolean isLog_findItemsWithWildAtts() {
		return log_findItemsWithWildAtts;
	}
	/**
	 * @param log_findItemsWithWildAtts the log_findItemsWithWildAtts to set
	 */
	public void setLog_findItemsWithWildAtts(boolean log_findItemsWithWildAtts) {
		this.log_findItemsWithWildAtts = log_findItemsWithWildAtts;
	}

	/**
	 * @return the log_findItemsExcept
	 */
	public boolean isLog_findItemsExcept() {
		return log_findItemsExcept;
	}
	/**
	 * @param log_findItemsExcept the log_findItemsExcept to set
	 */
	public void setLog_findItemsExcept(boolean log_findItemsExcept) {
		this.log_findItemsExcept = log_findItemsExcept;
	}

	/**
	 * @return the log_findItemsWithARangeOfIds
	 */
	public boolean isLog_findItemsWithARangeOfIds() {
		return log_findItemsWithARangeOfIds;
	}
	/**
	 * @param log_findItemsWithARangeOfIds the log_findItemsWithARangeOfIds to set
	 */
	public void setLog_findItemsWithARangeOfIds(boolean log_findItemsWithARangeOfIds) {
		this.log_findItemsWithARangeOfIds = log_findItemsWithARangeOfIds;
	}

}