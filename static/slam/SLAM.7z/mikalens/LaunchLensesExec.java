package slam.mikalens;

import java.io.FileNotFoundException;
import java.net.URISyntaxException;

import slam.SemLensApplier;
import slam.mikalens.notused.ContributionAppOnMika;
import slam.mikalens.notused.MiscTestsLens;
import slam.mikalens.notused.PublicationContextAppOnMika;
import slam.mikalens.notused.ResearchContextAppOnMika;
import slam.mikalens.notused.SemanticAppOnMika;
import slam.utilities.EARMARKDocumentLoaderWriter;
import slam.utilities.LensesNames;
import slam.utilities.LensesTypes;


import it.essepuntato.earmark.core.EARMARKDocument;
import it.essepuntato.earmark.core.io.EARMARKWriter;

public class LaunchLensesExec { 

	/**
	 * @param args
	 */
	public static void main(String[] args) throws URISyntaxException, FileNotFoundException {
		// QUESTO E' INVECE DOVE METTO L'INSIEME DELLE CHIAMATE ALLE VARIE APPLICAZIONI DELLE LENTI, e dove ci sono tutti i passaggi di read/write
		
		/* ######### Carico il documento ############ */
		// Base path della directory
		String dirpath = new String("file:///C:/Users/Jacopo/Documents/_Università/__%20Tesi%20Specialistica/____%20Progetto%20Eclipse/");
		// Input file rdfxml (sadly so) with NS
		String input_rdfxml_name = new String("Mika-EMARKv3-RDF-XML-InUse_03d-Inhuman.xml");
		// Output file rdfxml
		String output_rdfxml_name = new String("Mika-EMARKv3-RDF-XML-From_03d_AppliedLenses.xml");
		// Output file Turtle
		String output_turtle_name = new String("Mika-EMARKv3-Turtle-From_03d_AppliedLenses.turtle");
		
		EARMARKDocumentLoaderWriter loader = new EARMARKDocumentLoaderWriter(
				dirpath, // Base path, 
				input_rdfxml_name, // Input
				output_rdfxml_name); // Desired Output Name
		
		
		loader.loadInputFile();	// Loading the files
		EARMARKDocument doc = loader.getCurrentdoc();		
		
		System.out.println("##### Launch Lenses EXEC: Caricato il documento " + loader.getBasepath()+loader.getInputdocname());
		
		// Tengo un contatore generale di tutte le somme totali
		int totalassertions = 0;
		
		/* ------------- Nuove aggiunte alle lenti ---------------- */
		/* Creo il primo Applier */
		SemLensApplier ricerca = new SemLensApplier("Ricerca", LensesTypes.RCONTEXT, doc, "Storage Ricerca");
		/* Lo passo alla prima SemLensApplication e la inizializzo */
		ResearchContextAppOnMika rcapp = new ResearchContextAppOnMika(ricerca);
		/* Lancio la prima SemLensApplication */
		System.out.println("\n Annotazione della lente del Contesto di Ricerca");
		rcapp.annotate();
		totalassertions = totalassertions + rcapp.getApplier().getInfo().getTotalannotations();
		
		/* Contribution and Roles */
		SemLensApplier contributi = new SemLensApplier("Contributi", LensesTypes.CONTRIBUTION, doc, "Storage Contributi");
		ContributionAppOnMika contrapp = new ContributionAppOnMika(contributi);
		System.out.println("\n Annotazione della lente Strutturale");
		contrapp.annotate();
		totalassertions = totalassertions + contrapp.getApplier().getInfo().getTotalannotations();
		
		/* Publication Context */
		SemLensApplier pubcontext = new SemLensApplier("Pubblicazione", LensesTypes.PCONTEXT, doc, "Storage Pubblicazione");
		PublicationContextAppOnMika pubapp = new PublicationContextAppOnMika(pubcontext);
		System.out.println("\n Annotazione della lente del Contesto di Pubblicazione");
		pubapp.annotate();
		totalassertions = totalassertions + pubapp.getApplier().getInfo().getTotalannotations();
		/* --------------- ---------------- */
		
		/* Creo il primo Applier */
		SemLensApplier struttura = new SemLensApplier("Struttura", LensesTypes.STRUCTURE, doc, "Storage Struttura");
		/* Lo passo alla prima SemLensApplication e la inizializzo */
		StructureAppOnMika structapp = new StructureAppOnMika(struttura);
		/* Lancio la prima SemLensApplication */
		System.out.println("\n Annotazione della lente Strutturale");
		structapp.annotate();
		totalassertions = totalassertions + structapp.getApplier().getInfo().getTotalannotations();
		
		/* ### Così via fino alla fine ## */
		/* Retorica */
		SemLensApplier retorica = new SemLensApplier("Retorica", LensesTypes.RHETORIC, doc, "Storage Retorica");
		RhetoricAppOnMika rhetapp = new RhetoricAppOnMika(retorica);
		System.out.println("\n Annotazione della lente Retorica");
		rhetapp.annotate();
		totalassertions = totalassertions + rhetapp.getApplier().getInfo().getTotalannotations();
		
		/* Citazioni */
		SemLensApplier citazioni = new SemLensApplier("Citazioni", LensesTypes.CITATION, doc, "Storage Citazioni");
		CitationAppOnMika citeapp = new CitationAppOnMika(citazioni);
		System.out.println("\n Annotazione della lente Citazionale");
		citeapp.annotate();
		totalassertions = totalassertions + citeapp.getApplier().getInfo().getTotalannotations();
		
		/* Argument Model */
		SemLensApplier argomentazione = new SemLensApplier("Argomentazione", LensesTypes.ARGUMENTATION, doc, "Storage Argomentazione");
		ArgumentAppOnMika amoapp = new ArgumentAppOnMika(argomentazione);
		System.out.println("\n Annotazione della lente Argomentativa");
		amoapp.annotate();
		totalassertions = totalassertions + amoapp.getApplier().getInfo().getTotalannotations();
		
		/* --- Aggiunta Finale --- Semantica (Parziale) */
		SemLensApplier semantica = new SemLensApplier("Semantica", LensesTypes.SEMANTICS, doc, "Storage Semantica");
		SemanticAppOnMika semapp = new SemanticAppOnMika(semantica);
		System.out.println("\n Annotazione (PARZIALE) della lente Semantica");
		semapp.annotate();
		totalassertions = totalassertions + semapp.getApplier().getInfo().getTotalannotations();
		
		// Output finale
		System.out.println("Totale delle asserzioni usate per tutte e 4 le applicazioni di lenti: " + totalassertions + "\n");
		
		/* ###### Scrivo finalmente il documento annotato ##### */
		loader.generateURIs();
		loader.readyFiles();
		loader.writeToFormatWithNS(EARMARKWriter.RDFXML, LensesNames.prefixNSMapFull);
		
		// Scriviamolo anche in Turtle, ti disp?
		loader.setOutputdocname(output_turtle_name);
		loader.generateURIs();
		loader.readyFiles();
		loader.writeToFormatWithNS(EARMARKWriter.TURTLE, LensesNames.prefixNSMapFull);
	}

}
