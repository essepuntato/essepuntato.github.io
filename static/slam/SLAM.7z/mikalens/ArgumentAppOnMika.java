package slam.mikalens;

import it.essepuntato.earmark.core.Collection;

import java.net.URISyntaxException;

import slam.BasicLensApp;
import slam.SemLensApplier;
import slam.utilities.LensesNames;


public class ArgumentAppOnMika extends BasicLensApp {
	
	private SemLensApplier applier;
	
	/* Costruttori */
	public ArgumentAppOnMika(){
		/* Pura inizializzazione */
	}
	
	/* Costruttore base */
	public ArgumentAppOnMika(SemLensApplier applier) {
		setApplier(applier);
	}
	
	@Override
	public void annotate() throws URISyntaxException {
		
		applier = getApplier();
		System.out.println("Argument Model Lens Application Starting to Annotate");
		
		/* Setto le opzioni che desidero */
		applier.getOptions().setLog_findSingleItem(false);
		// applier.getOptions().setVerbosity_overall(3);
		
		// Creo ora tutti gli elementi per i 61 diversi argomenti
		applier.newEmElement("my_arg01", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg02", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg03", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg04", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg05", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg06", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg07", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg08", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg09", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg10", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg11", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg12", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg13", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg14", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg15", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg16", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg17", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg18", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg19", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg20", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg21", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg22", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg23", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg24", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg25", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg26", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg27", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg28", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg29", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg30", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg31", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg32", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg33", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg34", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg35", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg36", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg37", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg38", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg39", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg40", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg41", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg42", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg43", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg44", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg45", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg46", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg47", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg48", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg49", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg50", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg51", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg52", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg53", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg54", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg55", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg56", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg57", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg58", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg59", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg60", "", LensesNames.SWEX_URI2, Collection.Type.List);
		applier.newEmElement("my_arg61", "", LensesNames.SWEX_URI2, Collection.Type.List);
		
		// Annoto in massa tutti i nuovi elementi dandogli il tipo amo:Argument
		// applier.buildAnnotation("RDF Type: Argument", "http://www.w3.org/1999/02/22-rdf-syntax-ns#", "type", "amo:Argument");
		applier.buildAnnotation("RDF Type: Argument", "http://www.w3.org/1999/02/22-rdf-syntax-ns#", "type", "http://purl.org/spar/amo/Argument");
		applier.assertOnSet(applier.findItemsWithARangeOfIds("http://www.essepuntato.it/2010/04/SWWEx#my_arg", "00", 01, 61, ""),
				applier.getLastannotation());
		
		/*
		 * Codici delle abbreviazioni:
		 * arg = Argument
		 * c = Claim
		 * d = Data/Evidence
		 * w = Warrant
		 * 
		 * q = Qualifier
		 * 
		 * r = Rebuttal
		 * b = Backing
		 * 
		 */
		
		// Arg 01
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg01_r01-p_2", 1618, 1791, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg01_c01-p_3", 1792, 1842, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg01_q01-p_3", 1843, 1891, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg01_w01-p_3", 1892, 1993, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg01_d01-p_3", 1994, 2075, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		// Funziona benone, ho solo un po' troppi output di debug a schermo
		
		applier.buildAnnotation("Arg01 AMO:Rebuttal 01", LensesNames.AMO_URI, "hasRebuttal", "http://www.essepuntato.it/2010/04/SWWEx#r_arg01_r01-p_2");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg01", applier.getLastannotation());
		applier.buildAnnotation("Arg01 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg01_c01-p_3");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg01", applier.getLastannotation());
		applier.buildAnnotation("Arg01 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg01_q01-p_3");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg01", applier.getLastannotation());
		applier.buildAnnotation("Arg01 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg01_w01-p_3");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg01", applier.getLastannotation());
		applier.buildAnnotation("Arg01 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg01_d01-p_3");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg01", applier.getLastannotation());
		
		// Arg 02
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg02_q01-p_4", 2076, 2461, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg02_c01-p_4", 2462, 2668, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg02_q02-p_4", 2669, 2993, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg02_d01-p_4", 2994, 3114, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg02_w01-p_4", 3115, 3218, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg02 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg02_q01-p_4");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg02", applier.getLastannotation());
		applier.buildAnnotation("Arg02 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg02_c01-p_4");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg02", applier.getLastannotation());
		applier.buildAnnotation("Arg02 AMO:Qualifier 02", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg02_q02-p_4");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg02", applier.getLastannotation());
		applier.buildAnnotation("Arg02 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg02_d01-p_4");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg02", applier.getLastannotation());
		applier.buildAnnotation("Arg02 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg02_w01-p_4");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg02", applier.getLastannotation());
		
		// Arg 03
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg03_c01-p_4", 3219, 3416, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		// Warrant e data are included in argument 02
		
		applier.buildAnnotation("Arg03 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg03_c01-p_4");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg03", applier.getLastannotation());
		applier.buildAnnotation("Arg03 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#my_arg02");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg03", applier.getLastannotation());
		applier.buildAnnotation("Arg03 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg02_d01-p_4");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg03", applier.getLastannotation());
		
		// Arg 04
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg04_c01-p_5", 3417, 3600, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg04_d01-p_5", 3601, 3758, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg04_w01-p_5", 3759, 4051, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg04_w02-p_5", 4052, 4159, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg04 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg04_c01-p_5");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg04", applier.getLastannotation());
		applier.buildAnnotation("Arg04 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg04_d01-p_5");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg04", applier.getLastannotation());
		applier.buildAnnotation("Arg04 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg04_w01-p_5");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg04", applier.getLastannotation());
		applier.buildAnnotation("Arg04 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg04_w02-p_5");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg04", applier.getLastannotation());
		
		// Arg 05
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg05_q01-p_6", 4579, 4826, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg05_c01-p_6", 4827, 4963, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg05_w01-p_7", 4964, 5081, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg05_d01-p_7", 5121, 5248, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg05_d02-p_7", 5302, 5457, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg05 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg05_q01-p_6");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg05", applier.getLastannotation());
		applier.buildAnnotation("Arg05 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg05_c01-p_6");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg05", applier.getLastannotation());
		applier.buildAnnotation("Arg05 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg05_w01-p_7");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg05", applier.getLastannotation());
		applier.buildAnnotation("Arg05 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg05_d01-p_7");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg05", applier.getLastannotation());
		applier.buildAnnotation("Arg05 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg05_d02-p_7");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg05", applier.getLastannotation());
		
		// Arg 06
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg06_c01-p_7", 4963, 5120, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg06_w01-p_7", 5249, 5301, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		// DATA IS THE SAME AS the first from Argument 05, and, in addition to that...
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg06_d02-p_7", 5302, 5964, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		// Also it has the whole Argument 07 as a qualifier
		
		applier.buildAnnotation("Arg06 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#my_arg07");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg06", applier.getLastannotation());
		applier.buildAnnotation("Arg06 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg06_c01-p_7");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg06", applier.getLastannotation());
		applier.buildAnnotation("Arg06 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg06_w01-p_7");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg06", applier.getLastannotation());
		applier.buildAnnotation("Arg06 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg05_d01-p_7");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg06", applier.getLastannotation()); // Note, this is intentional
		applier.buildAnnotation("Arg06 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg06_d02-p_7");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg06", applier.getLastannotation());
		
		// Arg 07
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg07_c01-p_9", 5967, 6193, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg07_d01-p_9", 6194, 6231, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg07_w01-p_9", 6232, 6308, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg07_b01-p_9", 6309, 6579, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg07_d02-p_9", 6580, 6724, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg07_w02-p_9", 6725, 6815, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg07_b02-p_9", 6816, 6923, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg07_d03-p_9", 6924, 7012, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg07 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg07_c01-p_9");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg07", applier.getLastannotation());
		applier.buildAnnotation("Arg07 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg07_d01-p_9");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg07", applier.getLastannotation());
		applier.buildAnnotation("Arg07 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg07_w01-p_9");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg07", applier.getLastannotation());
		applier.buildAnnotation("Arg07 AMO:Backing 01", LensesNames.AMO_URI, "hasBacking", "http://www.essepuntato.it/2010/04/SWWEx#r_arg07_b01-p_9");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg07", applier.getLastannotation());
		applier.buildAnnotation("Arg07 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg07_d02-p_9");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg07", applier.getLastannotation());
		applier.buildAnnotation("Arg07 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg07_w02-p_9");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg07", applier.getLastannotation());
		applier.buildAnnotation("Arg07 AMO:Backing 02", LensesNames.AMO_URI, "hasBacking", "http://www.essepuntato.it/2010/04/SWWEx#r_arg07_b02-p_9");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg07", applier.getLastannotation());
		applier.buildAnnotation("Arg07 AMO:Evidence 03", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg07_d03-p_9");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg07", applier.getLastannotation());
		
		
		// Arg 08
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg08_q01-p_10", 7148, 7428, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg08_c01-p_10", 7429, 7558, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg08_d01-p_11", 7559, 7695, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg08_w01-p_11", 7696, 7766, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg08_b01-p_11", 7767, 7954, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg08_d02-p_11", 7955, 8140, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg08 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg08_q01-p_10");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg08", applier.getLastannotation());
		applier.buildAnnotation("Arg08 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg08_c01-p_10");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg08", applier.getLastannotation());
		applier.buildAnnotation("Arg08 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg08_d01-p_11");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg08", applier.getLastannotation());
		applier.buildAnnotation("Arg08 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg08_w01-p_11");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg08", applier.getLastannotation());
		applier.buildAnnotation("Arg08 AMO:Backing 01", LensesNames.AMO_URI, "hasBacking", "http://www.essepuntato.it/2010/04/SWWEx#r_arg08_b01-p_11");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg08", applier.getLastannotation());
		applier.buildAnnotation("Arg08 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg08_d02-p_11");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg08", applier.getLastannotation());
		
		// Arg 09 
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg09_q01-p_13", 8551, 8954, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg09_c01-p_13", 8955, 9115, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg09_r01-p_13", 9116, 9202, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg09_w01-p_14", 9203, 9356, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg09_d01-p_14", 9357, 9927, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg09_w02-p_14", 9928, 10117, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg09_d02-p_14", 10118, 10420, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg09 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg09_q01-p_13");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg09", applier.getLastannotation());
		applier.buildAnnotation("Arg09 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg09_c01-p_13");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg09", applier.getLastannotation());
		applier.buildAnnotation("Arg09 AMO:Rebuttal 01", LensesNames.AMO_URI, "hasRebuttal", "http://www.essepuntato.it/2010/04/SWWEx#r_arg09_r01-p_13");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg09", applier.getLastannotation());
		applier.buildAnnotation("Arg09 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg09_w01-p_14");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg09", applier.getLastannotation());
		applier.buildAnnotation("Arg09 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg09_d01-p_14");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg09", applier.getLastannotation());
		applier.buildAnnotation("Arg09 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg09_w02-p_14");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg09", applier.getLastannotation());
		applier.buildAnnotation("Arg09 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg09_d02-p_14");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg09", applier.getLastannotation());
		
		// Arg 10
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg10_c01-p_15", 10421, 10668, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg10_w01-p_15", 10669, 10919, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		// The data is the WHOLE argument 09

		applier.buildAnnotation("Arg10 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg10_c01-p_15");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg10", applier.getLastannotation());
		applier.buildAnnotation("Arg10 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg10_w01-p_15");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg10", applier.getLastannotation());
		applier.buildAnnotation("Arg10 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#my_arg09");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg10", applier.getLastannotation());
		
		// Arg 11
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg11_c01-p_16", 10920, 11065, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg11_d01-p_16", 11066, 11231, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg11_w01-p_16", 11232, 11415, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg11_d02-p_16", 11416, 11556, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg11_w02-p_16", 11557, 11682, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg11 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg11_c01-p_16");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg11", applier.getLastannotation());
		applier.buildAnnotation("Arg11 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg11_d01-p_16");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg11", applier.getLastannotation());
		applier.buildAnnotation("Arg11 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg11_w01-p_16");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg11", applier.getLastannotation());
		applier.buildAnnotation("Arg11 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg11_d02-p_16");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg11", applier.getLastannotation());
		applier.buildAnnotation("Arg11 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg11_w02-p_16");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg11", applier.getLastannotation());
		
		// Section 2.1
		// Arg 12
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg12_c01-p_18", 11960, 12115, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg12_q01-p_18", 12116, 12218, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg12_c02-p_19", 12219, 12292, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg12_q02-p_19", 12293, 12851, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg12_c03-p_19", 12852, 12898, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg12_d01-p_19", 12899, 13010, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg12_q03-p_19", 13011, 13179, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg12_d02-p_19", 13180, 13333, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg12_w01-p_19", 13334, 13395, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg12_q04-p_19", 13396, 13445, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg12_b01-p_19", 13446, 13632, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg12 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg12_c01-p_18");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg12", applier.getLastannotation());
		applier.buildAnnotation("Arg12 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg12_q01-p_18");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg12", applier.getLastannotation());
		applier.buildAnnotation("Arg12 AMO:Claim 02", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg12_c02-p_19");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg12", applier.getLastannotation());
		applier.buildAnnotation("Arg12 AMO:Qualifier 02", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg12_q02-p_19");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg12", applier.getLastannotation());
		applier.buildAnnotation("Arg12 AMO:Claim 03", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg12_c03-p_19");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg12", applier.getLastannotation());
		applier.buildAnnotation("Arg12 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg12_d01-p_19");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg12", applier.getLastannotation());
		applier.buildAnnotation("Arg12 AMO:Qualifier 03", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg12_q03-p_19");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg12", applier.getLastannotation());
		applier.buildAnnotation("Arg12 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg12_d02-p_19");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg12", applier.getLastannotation());
		applier.buildAnnotation("Arg12 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg12_w01-p_19");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg12", applier.getLastannotation());		
		applier.buildAnnotation("Arg12 AMO:Qualifier 04", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg12_q04-p_19");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg12", applier.getLastannotation());
		applier.buildAnnotation("Arg12 AMO:Backing 01", LensesNames.AMO_URI, "hasBacking", "http://www.essepuntato.it/2010/04/SWWEx#r_arg12_b01-p_19");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg12", applier.getLastannotation());
		
		// Arg 13
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg13_w01-p_19", 13633, 13693, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg13_d01-p_19", 13694, 13768, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg13_q01-p_19", 13769, 13882, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg13_c01-p_19", 13882, 14041, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg13 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg13_w01-p_19");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg13", applier.getLastannotation());
		applier.buildAnnotation("Arg13 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg13_d01-p_19");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg13", applier.getLastannotation());
		applier.buildAnnotation("Arg13 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg13_q01-p_19");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg13", applier.getLastannotation());
		applier.buildAnnotation("Arg13 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg13_c01-p_19");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg13", applier.getLastannotation());
		
		// Arg 14
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg14_q01-p_20", 14042, 14312, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg14_c01-p_20", 14313, 14367, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg14_d01-p_20", 14368, 14425, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg14_w01-p_20", 14426, 14548, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		// Further data is hinted at in the rest of the document by the warrant
		
		applier.buildAnnotation("Arg14 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg14_q01-p_20");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg14", applier.getLastannotation());
		applier.buildAnnotation("Arg14 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg14_c01-p_20");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg14", applier.getLastannotation());
		applier.buildAnnotation("Arg14 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg14_d01-p_20");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg14", applier.getLastannotation());
		applier.buildAnnotation("Arg14 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg14_w01-p_20");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg14", applier.getLastannotation());
		
		// Arg 15
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg15_w01-p_21", 14549, 14623, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg15_q01-p_21", 14624, 14685, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg15_c01-p_21", 14686, 14805, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg15_d01-p_21", 14805, 15174, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg15 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg15_w01-p_21");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg15", applier.getLastannotation());
		applier.buildAnnotation("Arg15 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg15_q01-p_21");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg15", applier.getLastannotation());
		applier.buildAnnotation("Arg15 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg15_c01-p_21");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg15", applier.getLastannotation());
		applier.buildAnnotation("Arg15 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg15_d01-p_21");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg15", applier.getLastannotation());
		
		// Arg 16
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg16_q01-p_22", 15175, 15248, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg16_c01-p_22", 15249, 15325, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg16_w01-p_22", 15326, 15417, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg16_d01-p_22", 15417, 15668, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg16 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg16_q01-p_22");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg16", applier.getLastannotation());
		applier.buildAnnotation("Arg16 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg16_c01-p_22");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg16", applier.getLastannotation());
		applier.buildAnnotation("Arg16 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg16_w01-p_22");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg16", applier.getLastannotation());
		applier.buildAnnotation("Arg16 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg16_d01-p_22");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg16", applier.getLastannotation());
		
		// Arg 17
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg17_w01-p_22", 15669, 15875, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg17_c01-p_22", 15876, 16077, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg17_d01-p_22", 16078, 16238, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg17 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg17_w01-p_22");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg17", applier.getLastannotation());
		applier.buildAnnotation("Arg17 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg17_c01-p_22");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg17", applier.getLastannotation());
		applier.buildAnnotation("Arg17 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg17_d01-p_22");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg17", applier.getLastannotation());
		
		// Arg 18
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg18_c01-p_22", 16239, 16375, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		// Has the same Data and Warrants as 17 ("Based on the same observations"), but it is probably a separate argument & claim.
		
		applier.buildAnnotation("Arg18 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg17_w01-p_22");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg18", applier.getLastannotation());
		applier.buildAnnotation("Arg18 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg17_d01-p_22");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg18", applier.getLastannotation());
		applier.buildAnnotation("Arg18 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg18_c01-p_22");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg18", applier.getLastannotation());
		
		// Arg 19
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg19_c01-p_23", 16531, 16620, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg19_w01-p_23", 16621, 16824, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg19_q01-p_23", 16825, 16970, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg19_d01-p_23", 16971, 17065, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg19_q02-p_23", 17066, 17197, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg19_d02-p_23", 17198, 17409, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg19 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg19_c01-p_23");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg19", applier.getLastannotation());
		applier.buildAnnotation("Arg19 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg19_w01-p_23");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg19", applier.getLastannotation());
		applier.buildAnnotation("Arg19 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg19_q01-p_23");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg19", applier.getLastannotation());
		applier.buildAnnotation("Arg19 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg19_d01-p_23");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg19", applier.getLastannotation());
		applier.buildAnnotation("Arg19 AMO:Qualifier 02", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg19_q02-p_23");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg19", applier.getLastannotation());
		applier.buildAnnotation("Arg19 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg19_d02-p_23");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg19", applier.getLastannotation());
		
		// Arg 20
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg20_c01-p_24", 17410, 17505, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg20_q01-p_24", 17506, 17570, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg20_d01-p_24", 17571, 17714, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg20_w01-p_24", 17715, 17777, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg20_d02-p_24", 17778, 17910, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg20_w02-p_24", 17911, 17987, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg20 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg20_c01-p_24");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg20", applier.getLastannotation());
		applier.buildAnnotation("Arg20 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg20_q01-p_24");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg20", applier.getLastannotation());
		applier.buildAnnotation("Arg20 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg20_d01-p_24");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg20", applier.getLastannotation());
		applier.buildAnnotation("Arg20 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg20_w01-p_24");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg20", applier.getLastannotation());
		applier.buildAnnotation("Arg20 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg20_d02-p_24");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg20", applier.getLastannotation());
		applier.buildAnnotation("Arg20 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg20_w02-p_24");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg20", applier.getLastannotation());
		
		
		// Section 3
		// Arg 21
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg21_d01-p_26", 18588, 18685, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg21_w01-p_26", 18686, 19066, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg21_d02-p_26", 19067, 19179, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg21_c01-p_26", 19180, 19378, "http://www.essepuntato.it/2010/04/SWWEx#d_text");

		applier.buildAnnotation("Arg21 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg21_d01-p_26");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg21", applier.getLastannotation());
		applier.buildAnnotation("Arg21 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg21_w01-p_26");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg21", applier.getLastannotation());
		applier.buildAnnotation("Arg21 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg21_d02-p_26");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg21", applier.getLastannotation());
		applier.buildAnnotation("Arg21 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg21_c01-p_26");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg21", applier.getLastannotation());
		
		// Arg 22
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg22_c01-p_27", 19379, 19483, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg22_d01-p_27", 19484, 19793, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg22_w01-p_27", 19794, 19917, "http://www.essepuntato.it/2010/04/SWWEx#d_text");

		applier.buildAnnotation("Arg22 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg22_c01-p_27");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg22", applier.getLastannotation());
		applier.buildAnnotation("Arg22 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg22_d01-p_27");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg22", applier.getLastannotation());
		applier.buildAnnotation("Arg22 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg22_w01-p_27");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg22", applier.getLastannotation());
		
		// Arg 23
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg23_c01-p_28", 19918, 19972, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg23_d01-p_28", 19973, 20091, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg23_w01-p_28", 20092, 20199, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg23 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg23_c01-p_28");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg23", applier.getLastannotation());
		applier.buildAnnotation("Arg23 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg23_d01-p_28");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg23", applier.getLastannotation());
		applier.buildAnnotation("Arg23 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg23_w01-p_28");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg23", applier.getLastannotation());
		
		// Arg 24 (23b?)
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg24_c01-p_28", 20200, 20226, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg24_w01-p_28", 20227, 20337, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg24_d01-p_28", 20338, 20681, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg24_w02-p_28", 20682, 20831, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg24_b01-p_28", 20832, 20963, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg24 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg24_c01-p_28");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg24", applier.getLastannotation());
		applier.buildAnnotation("Arg24 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg24_w01-p_28");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg24", applier.getLastannotation());
		applier.buildAnnotation("Arg24 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg24_d01-p_28");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg24", applier.getLastannotation());
		applier.buildAnnotation("Arg24 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg24_w02-p_28");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg24", applier.getLastannotation());
		applier.buildAnnotation("Arg24 AMO:Backing 01", LensesNames.AMO_URI, "hasBacking", "http://www.essepuntato.it/2010/04/SWWEx#r_arg24_b01-p_28");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg24", applier.getLastannotation());
		
		// Arg 25
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg25_d01-p_30", 21518, 21593, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg25_c01-p_30", 21594, 21663, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg25_q01-p_30", 21630, 21715, "http://www.essepuntato.it/2010/04/SWWEx#d_text"); // Overlapping Qualifiers
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg25_w01-p_30", 21716, 21798, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg25_q02-p_30", 21799, 21922, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg25 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg25_d01-p_30");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg25", applier.getLastannotation());
		applier.buildAnnotation("Arg25 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg25_c01-p_30");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg25", applier.getLastannotation());
		applier.buildAnnotation("Arg25 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg25_q01-p_30");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg25", applier.getLastannotation());
		applier.buildAnnotation("Arg25 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg25_w01-p_30");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg25", applier.getLastannotation());
		applier.buildAnnotation("Arg25 AMO:Qualifier 02", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg25_q02-p_30");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg25", applier.getLastannotation());
		
		// Arg 26 -- Its Data is the whole previous figure and the warrants are the captions
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg26_c01-p_34", 23053, 23121, "http://www.essepuntato.it/2010/04/SWWEx#d_text");

		applier.buildAnnotation("Arg26 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#e_div_7");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg26", applier.getLastannotation());
		applier.buildAnnotation("Arg26 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#e_dd_1");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg26", applier.getLastannotation());
		applier.buildAnnotation("Arg26 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#e_div_9");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg26", applier.getLastannotation());
		applier.buildAnnotation("Arg26 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#e_dd_2");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg26", applier.getLastannotation());
		applier.buildAnnotation("Arg26 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg26_c01-p_34");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg26", applier.getLastannotation());
		// TODO: CHECK - Eventualmente usare asserzioni EM? (qui e altrove)
		
		// Arg 27
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg27_c01-p_35", 23122, 23184, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg27_w01-p_35", 23185, 23218, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg27_d01-p_35", 23219, 23444, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg27 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg27_c01-p_35");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg27", applier.getLastannotation());
		applier.buildAnnotation("Arg27 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg27_w01-p_35");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg27", applier.getLastannotation());
		applier.buildAnnotation("Arg27 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg27_d01-p_35");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg27", applier.getLastannotation());
		
		// Arg 28
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg28_c01-p_35", 23445, 23514, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg28_d01-p_35", 23515, 23637, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg28_w01-p_35", 23638, 23814, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg28_b01-p_35", 23815, 23998, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg28_d02-p_35", 23999, 24116, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg28_w02-p_35", 24117, 24243, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg28 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg28_c01-p_35");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg28", applier.getLastannotation());
		applier.buildAnnotation("Arg28 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg28_d01-p_35");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg28", applier.getLastannotation());
		applier.buildAnnotation("Arg28 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg28_w01-p_35");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg28", applier.getLastannotation());
		applier.buildAnnotation("Arg28 AMO:Backing 01", LensesNames.AMO_URI, "hasBacking", "http://www.essepuntato.it/2010/04/SWWEx#r_arg28_b01-p_35");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg28", applier.getLastannotation());
		applier.buildAnnotation("Arg28 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg28_d02-p_35");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg28", applier.getLastannotation());
		applier.buildAnnotation("Arg28 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg28_w02-p_35");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg28", applier.getLastannotation());
		
		// Arg 29 --- Also acts as warrant for Argument 30
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg29_c01-p_37", 24923, 25057, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg29_w01-p_37", 25058, 25169, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg29_d01-p_37", 25170, 25410, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg29_w02-p_37", 25299, 25539, "http://www.essepuntato.it/2010/04/SWWEx#d_text"); // Overlapping Warrant
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg29_d02-p_37", 25540, 25772, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg29 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg29_c01-p_37");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg29", applier.getLastannotation());
		applier.buildAnnotation("Arg29 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg29_w01-p_37");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg29", applier.getLastannotation());
		applier.buildAnnotation("Arg29 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg29_d01-p_37");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg29", applier.getLastannotation());
		applier.buildAnnotation("Arg29 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg29_w02-p_37");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg29", applier.getLastannotation());
		applier.buildAnnotation("Arg29 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg29_d02-p_37");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg29", applier.getLastannotation());
		
		// Arg 30 -- Has his own warrant in Argument 29
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg30_d01-p_38", 25773, 25777, "http://www.essepuntato.it/2010/04/SWWEx#d_text"); // Together with the table
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg30_c01-p_38", 25778, 25858, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg30_d02-p_38", 25859, 26258, "http://www.essepuntato.it/2010/04/SWWEx#d_text");

		applier.buildAnnotation("Arg30 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#my_arg29");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg30", applier.getLastannotation());
		applier.buildAnnotation("Arg30 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg30_d01-p_38");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg30", applier.getLastannotation());
		applier.buildAnnotation("Arg30 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg30_c01-p_38");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg30", applier.getLastannotation());
		applier.buildAnnotation("Arg30 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg30_d02-p_38");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg30", applier.getLastannotation());
		applier.buildAnnotation("Arg30 AMO:Evidence 03", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#e_dl_4"); // Table 2
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg30", applier.getLastannotation()); 
		
		// Arg 31
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg31_c01-p_40", 26800, 26971, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg31_d01-p_40", 26972, 27059, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg31_w01-p_40", 27060, 27147, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg31 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg31_c01-p_40");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg31", applier.getLastannotation());
		applier.buildAnnotation("Arg31 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg31_d01-p_40");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg31", applier.getLastannotation());
		applier.buildAnnotation("Arg31 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg31_w01-p_40");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg31", applier.getLastannotation());
		
		// Arg 32
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg32_c01-p_40", 27148, 27296, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg32_d01-p_40", 27297, 27390, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg32_w01-p_40", 27391, 27484, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg32_b01-p_40", 27485, 27570, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg32 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg32_c01-p_40");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg32", applier.getLastannotation());
		applier.buildAnnotation("Arg32 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg32_d01-p_40");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg32", applier.getLastannotation());
		applier.buildAnnotation("Arg32 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg32_w01-p_40");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg32", applier.getLastannotation());
		applier.buildAnnotation("Arg32 AMO:Backing 01", LensesNames.AMO_URI, "hasBacking", "http://www.essepuntato.it/2010/04/SWWEx#r_arg32_b01-p_40");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg32", applier.getLastannotation());
		
		// Arg 33 --- Has additional data in Table 3
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg33_r01-p_41", 27571, 27706, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg33_q01-p_41", 27707, 27842, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg33_c01-p_41", 27843, 27916, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg33_d01-p_41", 27917, 27935, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg33_q02-p_41", 27936, 28107, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg33_d02-p_41", 28108, 28215, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg33_w01-p_41", 28216, 28370, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg33 AMO:Rebuttal 01", LensesNames.AMO_URI, "hasRebuttal", "http://www.essepuntato.it/2010/04/SWWEx#r_arg33_r01-p_41");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg33", applier.getLastannotation());
		applier.buildAnnotation("Arg33 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg33_q01-p_41");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg33", applier.getLastannotation());
		applier.buildAnnotation("Arg33 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg33_c01-p_41");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg33", applier.getLastannotation());
		applier.buildAnnotation("Arg33 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg33_d01-p_41");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg33", applier.getLastannotation());
		applier.buildAnnotation("Arg33 AMO:Qualifier 02", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg33_q02-p_41");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg33", applier.getLastannotation());
		applier.buildAnnotation("Arg33 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg33_d02-p_41");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg33", applier.getLastannotation());
		applier.buildAnnotation("Arg33 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg33_w01-p_41");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg33", applier.getLastannotation());
		applier.buildAnnotation("Arg33 AMO:Evidence 03", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#e_dl_5"); // Table 3
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg33", applier.getLastannotation()); 
		
		// Arg 34 --- Has data in Table 3
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg34_c01-p_43", 28895, 28990, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg34_w01-p_43", 28991, 29292, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg34 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg34_c01-p_43");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg34", applier.getLastannotation());
		applier.buildAnnotation("Arg34 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg34_w01-p_43");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg34", applier.getLastannotation());
		applier.buildAnnotation("Arg34 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#e_dl_5"); // Table 3
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg34", applier.getLastannotation()); 
		
		// Section 3.2
		// Arg 35 --- Has data in Table 3
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg35_c01-p_44", 29378, 29425, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg35_w01-p_44", 29426, 29508, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg35_r01-p_44", 29508, 29701, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg35 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg35_c01-p_44");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg35", applier.getLastannotation());
		applier.buildAnnotation("Arg35 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg35_w01-p_44");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg35", applier.getLastannotation());
		applier.buildAnnotation("Arg35 AMO:Rebuttal 01", LensesNames.AMO_URI, "hasRebuttal", "http://www.essepuntato.it/2010/04/SWWEx#r_arg35_r01-p_44");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg35", applier.getLastannotation());
		applier.buildAnnotation("Arg35 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#e_dl_5"); // Table 3
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg35", applier.getLastannotation()); 

		
		// Arg 36
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg36_c01-p_45", 29702, 29869, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg36_w01-p_45", 29870, 30202, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg36_d01-p_46", 30203, 30478, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg36_w02-p_47", 30479, 30551, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg36_d02-p_47", 30552, 30712, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg36_q01-p_47", 30713, 30867, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg36 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg36_c01-p_45");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg36", applier.getLastannotation());
		applier.buildAnnotation("Arg36 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg36_w01-p_45");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg36", applier.getLastannotation());
		applier.buildAnnotation("Arg36 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg36_d01-p_46");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg36", applier.getLastannotation());
		applier.buildAnnotation("Arg36 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg36_w02-p_47");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg36", applier.getLastannotation());
		applier.buildAnnotation("Arg36 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg36_d02-p_47");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg36", applier.getLastannotation());
		applier.buildAnnotation("Arg36 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg36_q01-p_47");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg36", applier.getLastannotation());
		
		// Arg 37
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg37_c01-p_48", 30868, 31015, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg37_d01-p_48", 31061, 31633, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg37_q01-p_48", 31634, 31729, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg37_w01-p_48", 31730, 31818, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg37_w02-p_49", 31819, 31919, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg37_q02-p_49", 31920, 32377, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg37 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg37_c01-p_48");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg37", applier.getLastannotation());
		applier.buildAnnotation("Arg37 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg37_d01-p_48");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg37", applier.getLastannotation());
		applier.buildAnnotation("Arg37 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg37_q01-p_48");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg37", applier.getLastannotation());
		applier.buildAnnotation("Arg37 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg37_w01-p_48");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg37", applier.getLastannotation());
		applier.buildAnnotation("Arg37 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg37_w02-p_49");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg37", applier.getLastannotation());
		applier.buildAnnotation("Arg37 AMO:Qualifier 02", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg37_q02-p_49");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg37", applier.getLastannotation());

		// Arg 38
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg38_d01-p_50", 32378, 32467, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg38_c01-p_50", 32468, 32598, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg38_w01-p_50", 32599, 32665, "http://www.essepuntato.it/2010/04/SWWEx#d_text");

		applier.buildAnnotation("Arg38 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg38_d01-p_50");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg38", applier.getLastannotation());
		applier.buildAnnotation("Arg38 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg38_c01-p_50");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg38", applier.getLastannotation());
		applier.buildAnnotation("Arg38 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg38_w01-p_50");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg38", applier.getLastannotation());
		
		// Arg 39
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg39_r01-p_51", 32666, 32816, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg39_q01-p_51", 32817, 32919, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg39_c01-p_51", 32920, 33008, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg39_w01-p_51", 33009, 33298, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg39_d01-p_51", 33299, 33624, "http://www.essepuntato.it/2010/04/SWWEx#d_text");

		applier.buildAnnotation("Arg39 AMO:Rebuttal 01", LensesNames.AMO_URI, "hasRebuttal", "http://www.essepuntato.it/2010/04/SWWEx#r_arg39_r01-p_51");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg39", applier.getLastannotation());
		applier.buildAnnotation("Arg39 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg39_q01-p_51");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg39", applier.getLastannotation());
		applier.buildAnnotation("Arg39 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg39_c01-p_51");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg39", applier.getLastannotation());
		applier.buildAnnotation("Arg39 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg39_w01-p_51");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg39", applier.getLastannotation());
		applier.buildAnnotation("Arg39 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg39_d01-p_51");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg39", applier.getLastannotation());

		
		// Arg 40
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg40_c01-p_52", 33625, 33704, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg40_w01-p_52", 33705, 33776, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg40_d01-p_52", 33777, 34243, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg40_w02-p_52", 34244, 34372, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg40_d02-p_52", 34373, 34450, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg40 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg40_c01-p_52");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg40", applier.getLastannotation());
		applier.buildAnnotation("Arg40 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg40_w01-p_52");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg40", applier.getLastannotation());
		applier.buildAnnotation("Arg40 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg40_d01-p_52");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg40", applier.getLastannotation());
		applier.buildAnnotation("Arg40 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg40_w02-p_52");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg40", applier.getLastannotation());
		applier.buildAnnotation("Arg40 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg40_d02-p_52");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg40", applier.getLastannotation());

		
		// Arg 41 -- Two claims but I'd say the same argument
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg41_c01-p_53", 34451, 34644, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg41_c02-p_53", 34645, 34723, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg41_d01-p_53", 34724, 34828, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg41_w01-p_53", 34829, 35019, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg41_d02-p_53", 35020, 35110, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg41_w02-p_53", 35111, 35256, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg41_b01-p_53", 35257, 35306, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg41 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg41_c01-p_53");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg41", applier.getLastannotation());
		applier.buildAnnotation("Arg41 AMO:Claim 02", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg41_c02-p_53");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg41", applier.getLastannotation());
		applier.buildAnnotation("Arg41 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg41_d01-p_53");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg40", applier.getLastannotation());
		applier.buildAnnotation("Arg41 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg41_w01-p_53");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg40", applier.getLastannotation());
		applier.buildAnnotation("Arg41 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg41_d01-p_53");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg40", applier.getLastannotation());
		applier.buildAnnotation("Arg41 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg41_w02-p_53");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg40", applier.getLastannotation());
		applier.buildAnnotation("Arg41 AMO:Backing 01", LensesNames.AMO_URI, "hasBacking", "http://www.essepuntato.it/2010/04/SWWEx#r_arg41_b01-p_53");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg41", applier.getLastannotation());
		
		// Section 4
		// Arg 42
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg42_q01-p_54", 35321, 35438, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg42_c01-p_54", 35439, 35556, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg42_d01-p_54", 35557, 35673, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg42_q02-p_54", 35674, 35791, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg42_d02-p_54", 35792, 35954, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg42_r01-p_54", 35955, 36059, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg42_w01-p_54", 36060, 36277, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg42_d03-p_55", 36278, 36873, "http://www.essepuntato.it/2010/04/SWWEx#d_text"); // Is also data for other arguments (43, 44)
		
		applier.buildAnnotation("Arg42 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_q01-p_54");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg42", applier.getLastannotation());
		applier.buildAnnotation("Arg42 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_c01-p_54");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg42", applier.getLastannotation());
		applier.buildAnnotation("Arg42 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_d01-p_54");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg42", applier.getLastannotation());
		applier.buildAnnotation("Arg42 AMO:Qualifier 02", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_q02-p_54");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg42", applier.getLastannotation());
		applier.buildAnnotation("Arg42 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_d02-p_54");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg42", applier.getLastannotation());
		applier.buildAnnotation("Arg42 AMO:Rebuttal 01", LensesNames.AMO_URI, "hasRebuttal", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_r01-p_54");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg42", applier.getLastannotation());
		applier.buildAnnotation("Arg42 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_w01-p_54");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg42", applier.getLastannotation());
		applier.buildAnnotation("Arg42 AMO:Evidence 03", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_d03-p_55");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg42", applier.getLastannotation());
		
//		applier.buildAnnotation("Arg42 Q Forces C", LensesNames.AMO_URI, "forces", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_c01-p_54");
//		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#r_arg42_q01-p_54", applier.getLastannotation());
//		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#r_arg42_q02-p_54", applier.getLastannotation());
//		applier.buildAnnotation("Arg42 W Leads To C", LensesNames.AMO_URI, "leadsTo", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_c01-p_54");
//		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#r_arg42_w01-p_54", applier.getLastannotation());
//		applier.buildAnnotation("Arg42 E Proves C", LensesNames.AMO_URI, "proves", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_c01-p_54");
//		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#r_arg42_d01-p_54", applier.getLastannotation());
//		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#r_arg42_d02-p_54", applier.getLastannotation());
//		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#r_arg42_d03-p_55", applier.getLastannotation());
//		applier.buildAnnotation("Arg42 E Supports W", LensesNames.AMO_URI, "supports", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_w01-p_54");
//		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#r_arg42_d01-p_54", applier.getLastannotation());
//		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#r_arg42_d02-p_54", applier.getLastannotation());
//		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#r_arg42_d03-p_55", applier.getLastannotation());
//		applier.buildAnnotation("Arg42 C Disproved by R", LensesNames.AMO_URI, "isDisprovedBy", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_r01-p_54");
//		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#r_arg42_c01-p_54", applier.getLastannotation());
		
		// Arg 43 --- Has data also in table 4
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg43_w01-p_56", 36874, 36914, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg43_c01-p_56", 36915, 37125, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg43_d02-p_56", 37126, 37295, "http://www.essepuntato.it/2010/04/SWWEx#d_text"); // Is also data for 44

		applier.buildAnnotation("Arg43 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg43_w01-p_56");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg43", applier.getLastannotation());
		applier.buildAnnotation("Arg43 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg43_c01-p_56");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg43", applier.getLastannotation());
		applier.buildAnnotation("Arg43 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_d03-p_55"); // See 42
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg43", applier.getLastannotation()); 
		applier.buildAnnotation("Arg43 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg43_d02-p_56");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg43", applier.getLastannotation());
		applier.buildAnnotation("Arg43 AMO:Evidence 03", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#e_dl_6"); // Table 4
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg43", applier.getLastannotation()); 
		
		// Arg 44 --- Has data also in table 4
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg44_c01-p_56", 37296, 37463, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg44_w01-p_56", 37464, 37573, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg44 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg44_c01-p_56");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg44", applier.getLastannotation());
		applier.buildAnnotation("Arg44 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg44_w01-p_56");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg44", applier.getLastannotation());
		applier.buildAnnotation("Arg44 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg42_d03-p_55"); // See 42
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg44", applier.getLastannotation());
		applier.buildAnnotation("Arg44 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg43_d02-p_56"); // See 43
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg44", applier.getLastannotation());
		applier.buildAnnotation("Arg44 AMO:Evidence 03", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#e_dl_6"); // Table 4
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg44", applier.getLastannotation()); 
		
		// Arg 45
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg45_c01-p_56", 37574, 37742, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg45_c02-p_56", 37743, 37888, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg45_q01-p_56", 37889, 37973, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		// Has Data in table 4 as well, and Argument 44 (and 43 too?) are his warrants [and in a sense, also his additional data]

		applier.buildAnnotation("Arg44 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#my_arg43");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg45", applier.getLastannotation());
		applier.buildAnnotation("Arg44 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#my_arg44");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg45", applier.getLastannotation());
		applier.buildAnnotation("Arg45 AMO:Claim 02", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg45_c01-p_56");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg45", applier.getLastannotation());
		applier.buildAnnotation("Arg45 AMO:Claim 02", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg45_c01-p_56");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg45", applier.getLastannotation());
		applier.buildAnnotation("Arg45 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg45_q01-p_56");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg45", applier.getLastannotation());
		applier.buildAnnotation("Arg45 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#e_dl_6"); // Table 4
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg45", applier.getLastannotation());
		
		// Section 5
		// Arg 46
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg46_c01-p_58", 38407, 38567, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg46_d01-p_58", 38568, 38609, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg46_r01-p_58", 38610, 38719, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg46_w01-p_58", 38720, 38929, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg46 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg46_c01-p_58");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg46", applier.getLastannotation());
		applier.buildAnnotation("Arg46 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg46_d01-p_58");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg46", applier.getLastannotation());
		applier.buildAnnotation("Arg46 AMO:Rebuttal 01", LensesNames.AMO_URI, "hasRebuttal", "http://www.essepuntato.it/2010/04/SWWEx#r_arg46_r01-p_58");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg46", applier.getLastannotation());
		applier.buildAnnotation("Arg46 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg46_w01-p_58");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg46", applier.getLastannotation());
		
		// Arg 47
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg47_c01-p_59", 38930, 39040, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg47_w01-p_59", 39041, 39160, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg47_d01-p_59", 39161, 39820, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg47_w02-p_59", 39821, 39942, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg47_b01-p_59", 39943, 40251, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg47 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg47_c01-p_59");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg47", applier.getLastannotation());
		applier.buildAnnotation("Arg47 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg47_w01-p_59");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg47", applier.getLastannotation());
		applier.buildAnnotation("Arg47 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg47_d01-p_59");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg47", applier.getLastannotation());
		applier.buildAnnotation("Arg47 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg47_w02-p_59");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg47", applier.getLastannotation());
		applier.buildAnnotation("Arg47 AMO:Backing 01", LensesNames.AMO_URI, "hasBacking", "http://www.essepuntato.it/2010/04/SWWEx#r_arg47_b01-p_59");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg47", applier.getLastannotation());
		
		// Arg 48
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg48_c01-p_59", 40252, 40388, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg48_d01-p_59", 40266, 40312, "http://www.essepuntato.it/2010/04/SWWEx#d_text"); // Overlapping with the Claims
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg48_w01-p_59", 40389, 40621, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg48 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg48_c01-p_59");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg48", applier.getLastannotation());
		applier.buildAnnotation("Arg48 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg48_d01-p_59");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg48", applier.getLastannotation());
		applier.buildAnnotation("Arg48 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg48_w01-p_59");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg48", applier.getLastannotation());
		
		// Arg 49
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg49_c01-p_59", 40622, 40702, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg49_d01-p_59", 40703, 40841, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg49_w01-p_59", 40842, 40939, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg49_d02-p_59", 40940, 40954, "http://www.essepuntato.it/2010/04/SWWEx#d_text"); //Also has data in figure 6
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg49_b01-p_59", 40955, 41114, "http://www.essepuntato.it/2010/04/SWWEx#d_text");

		applier.buildAnnotation("Arg49 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg49_c01-p_59");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg49", applier.getLastannotation());
		applier.buildAnnotation("Arg49 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg49_d01-p_59");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg49", applier.getLastannotation());
		applier.buildAnnotation("Arg49 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg49_w01-p_59");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg49", applier.getLastannotation());
		applier.buildAnnotation("Arg49 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg49_d02-p_59");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg49", applier.getLastannotation());
		applier.buildAnnotation("Arg49 AMO:Backing 01", LensesNames.AMO_URI, "hasBacking", "http://www.essepuntato.it/2010/04/SWWEx#r_arg49_b01-p_59");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg49", applier.getLastannotation());
		applier.buildAnnotation("Arg49 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#e_dl_10");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg49", applier.getLastannotation());
		applier.buildAnnotation("Arg49 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#e_dd_18");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg49", applier.getLastannotation());
		
		// Arg 50
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg50_q01-p_64", 41810, 41872, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg50_w01-p_64", 41873, 41895, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg50_c01-p_64", 41896, 42059, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg50_d01-p_64", 42060, 42090, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg50_r01-p_64", 42091, 42324, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg50 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg50_q01-p_64");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg50", applier.getLastannotation());
		applier.buildAnnotation("Arg50 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg50_w01-p_64");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg50", applier.getLastannotation());
		applier.buildAnnotation("Arg50 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg50_c01-p_64");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg50", applier.getLastannotation());
		applier.buildAnnotation("Arg50 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg50_d01-p_64");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg50", applier.getLastannotation());
		applier.buildAnnotation("Arg50 AMO:Rebuttal 01", LensesNames.AMO_URI, "hasRebuttal", "http://www.essepuntato.it/2010/04/SWWEx#r_arg50_r01-p_64");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg50", applier.getLastannotation());
		
		// Arg 51
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg51_d01-p_64", 42325, 42363, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg51_c01-p_64", 42363, 42423, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg51_w01-p_64", 42424, 42470, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg51_b01-p_64", 42471, 42505, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg51_r01-p_64", 42506, 42604, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg51 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg51_d01-p_64");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg51", applier.getLastannotation());
		applier.buildAnnotation("Arg51 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg51_c01-p_64");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg51", applier.getLastannotation());
		applier.buildAnnotation("Arg51 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg51_w01-p_64");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg51", applier.getLastannotation());
		applier.buildAnnotation("Arg51 AMO:Backing 01", LensesNames.AMO_URI, "hasBacking", "http://www.essepuntato.it/2010/04/SWWEx#r_arg51_b01-p_64");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg51", applier.getLastannotation());
		applier.buildAnnotation("Arg51 AMO:Rebuttal 01", LensesNames.AMO_URI, "hasRebuttal", "http://www.essepuntato.it/2010/04/SWWEx#r_arg51_r01-p_64");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg51", applier.getLastannotation());
		
		// Arg 52
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg52_c01-p_65", 42605, 42634, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg52_w01-p_65", 42635, 42683, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg52_r01-p_65", 42684, 43050, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg52_d01-p_65", 43051, 43150, "http://www.essepuntato.it/2010/04/SWWEx#d_text");

		applier.buildAnnotation("Arg52 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg52_c01-p_65");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg52", applier.getLastannotation());
		applier.buildAnnotation("Arg52 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg52_w01-p_65");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg52", applier.getLastannotation());
		applier.buildAnnotation("Arg52 AMO:Rebuttal 01", LensesNames.AMO_URI, "hasRebuttal", "http://www.essepuntato.it/2010/04/SWWEx#r_arg52_r01-p_65");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg52", applier.getLastannotation());
		applier.buildAnnotation("Arg52 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg52_d01-p_65");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg52", applier.getLastannotation());

		// Arg 53
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg53_c01-p_65", 43151, 43269, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg53_d01-p_65", 43270, 43411, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg53_q01-p_65", 43412, 43604, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg53_w01-p_65", 43605, 43667, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg53_q02-p_65", 43668, 43714, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg53_w02-p_65", 43715, 43778, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg53_d02-p_65", 43779, 43919, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg53 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg53_c01-p_65");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg53", applier.getLastannotation());
		applier.buildAnnotation("Arg53 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg53_d01-p_65");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg53", applier.getLastannotation());
		applier.buildAnnotation("Arg53 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg53_q01-p_65");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg53", applier.getLastannotation());
		applier.buildAnnotation("Arg53 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg53_w01-p_65");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg53", applier.getLastannotation());
		applier.buildAnnotation("Arg53 AMO:Qualifier 02", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg53_q02-p_65");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg53", applier.getLastannotation());
		applier.buildAnnotation("Arg53 AMO:Warrant 02", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg53_w02-p_65");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg53", applier.getLastannotation());
		applier.buildAnnotation("Arg53 AMO:Evidence 02", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg53_d02-p_65");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg53", applier.getLastannotation());

		// Arg 54
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg54_c01-p_66", 43920, 44003, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg54_w01-p_66", 44004, 44134, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg54_d01-p_66", 44135, 44249, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg54_q01-p_66", 44250, 44457, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg54 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg54_c01-p_66");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg54", applier.getLastannotation());
		applier.buildAnnotation("Arg54 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg54_w01-p_66");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg54", applier.getLastannotation());
		applier.buildAnnotation("Arg54 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg54_d01-p_66");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg54", applier.getLastannotation());
		applier.buildAnnotation("Arg54 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg54_q01-p_66");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg54", applier.getLastannotation());
		
		// Arg 55
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg55_c01-p_67", 44458, 44784, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg55_w01-p_67", 44785, 44928, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg55_d01-p_67", 44929, 45128, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg55 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg55_c01-p_67");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg55", applier.getLastannotation());
		applier.buildAnnotation("Arg55 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg55_w01-p_67");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg55", applier.getLastannotation());
		applier.buildAnnotation("Arg55 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg55_d01-p_67");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg55", applier.getLastannotation());
		
		// Arg 56
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg56_q01-p_68", 45129, 45174, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg56_c01-p_68", 45175, 45276, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg56_w01-p_68", 45277, 45360, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg56_b01-p_68", 45361, 45456, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg56_d01-p_68", 45457, 45556, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg56 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg56_q01-p_68");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg56", applier.getLastannotation());
		applier.buildAnnotation("Arg56 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg56_c01-p_68");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg56", applier.getLastannotation());
		applier.buildAnnotation("Arg56 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg56_w01-p_68");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg56", applier.getLastannotation());
		applier.buildAnnotation("Arg56 AMO:Backing 01", LensesNames.AMO_URI, "hasBacking", "http://www.essepuntato.it/2010/04/SWWEx#r_arg56_b01-p_68");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg56", applier.getLastannotation());
		applier.buildAnnotation("Arg56 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg56_d01-p_68");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg56", applier.getLastannotation());
		
		// Section 6
		// Arg 57
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg57_q01-p_69", 45588, 45691, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg57_q02-p_69", 45692, 45777, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg57_w01-p_69", 45778, 45912, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg57_c01-p_69", 45913, 46119, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg57_d01-p_69", 46120, 46262, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg57 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg57_q01-p_69");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg57", applier.getLastannotation());
		applier.buildAnnotation("Arg57 AMO:Qualifier 02", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg57_q02-p_69");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg57", applier.getLastannotation());
		applier.buildAnnotation("Arg57 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg57_w01-p_69");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg57", applier.getLastannotation());
		applier.buildAnnotation("Arg57 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg57_c01-p_69");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg57", applier.getLastannotation());
		applier.buildAnnotation("Arg57 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg57_d01-p_69");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg57", applier.getLastannotation());
		
		// Arg 58 ---- TODO: DATA AND WARRANTS FOR THIS ARE ALL ELSEWHERE IN THE DOCUMENT (more or less, the whole paper) - HOW TO BETTER REPR IT? ROOT?
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg58_c01-p_70", 46263, 46520, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg58_c02-p_70", 46521, 46795, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg58_c03-p_70", 46796, 47008, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg58 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg58_c01-p_70");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg58", applier.getLastannotation());
		applier.buildAnnotation("Arg58 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg58_c02-p_70");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg58", applier.getLastannotation());
		applier.buildAnnotation("Arg58 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg58_c03-p_70");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg58", applier.getLastannotation());
		
		// Arg 59
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg59_d01-p_71", 47119, 47281, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg59_w01-p_71", 47282, 47441, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg59_c01-p_71", 47442, 47649, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg59_r01-p_71", 47650, 47800, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg59_q01-p_71", 47801, 47992, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg59 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg59_d01-p_71");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg59", applier.getLastannotation());
		applier.buildAnnotation("Arg59 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg59_w01-p_71");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg59", applier.getLastannotation());
		applier.buildAnnotation("Arg59 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg59_c01-p_71");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg59", applier.getLastannotation());
		applier.buildAnnotation("Arg59 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg59_q01-p_71");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg59", applier.getLastannotation());


		// Arg 60
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg60_w01-p_71", 47993, 48004, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg60_q01-p_71", 48005, 48091, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg60_d01-p_71", 48092, 48220, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg60_d02-p_71", 48221, 48238, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg60_c01-p_71", 48239, 48346, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg60 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg60_w01-p_71");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg60", applier.getLastannotation());
		applier.buildAnnotation("Arg60 AMO:Qualifier 01", LensesNames.AMO_URI, "hasQualifier", "http://www.essepuntato.it/2010/04/SWWEx#r_arg60_q01-p_71");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg60", applier.getLastannotation());
		applier.buildAnnotation("Arg60 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg60_d01-p_71");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg60", applier.getLastannotation());
		applier.buildAnnotation("Arg60 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg60_d02-p_71");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg60", applier.getLastannotation());
		applier.buildAnnotation("Arg60 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg60_c01-p_71");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg60", applier.getLastannotation());
		
		// Arg 61
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg61_c01-p_72", 48347, 48461, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg61_d01-p_72", 48462, 48691, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		applier.newPointerRange(LensesNames.SWEX_URI2 + "r_arg61_w01-p_72", 48692, 48857, "http://www.essepuntato.it/2010/04/SWWEx#d_text");
		
		applier.buildAnnotation("Arg61 AMO:Claim 01", LensesNames.AMO_URI, "hasClaim", "http://www.essepuntato.it/2010/04/SWWEx#r_arg61_c01-p_72");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg61", applier.getLastannotation());
		applier.buildAnnotation("Arg61 AMO:Evidence 01", LensesNames.AMO_URI, "hasEvidence", "http://www.essepuntato.it/2010/04/SWWEx#r_arg61_d01-p_72");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg61", applier.getLastannotation());
		applier.buildAnnotation("Arg61 AMO:Warrant 01", LensesNames.AMO_URI, "hasWarrant", "http://www.essepuntato.it/2010/04/SWWEx#r_arg61_w01-p_72");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#my_arg61", applier.getLastannotation());
		
		/* Stampo un riassunto delle statistiche per questa applicazione */
		applier.getInfo().summary();
		
	}

}
