package slam.mikalens;


import java.net.URISyntaxException;
import java.util.HashMap;

import slam.BasicLensApp;
import slam.SemLensApplier;
import slam.utilities.LensesNames;


public class StructureAppOnMika extends BasicLensApp {
	
	private SemLensApplier applier;
	
	
	/* Costruttori */
	public StructureAppOnMika(){
		/* Pura inizializzazione */
	}
	
	/* Costruttore base */
	public StructureAppOnMika(SemLensApplier applier) {
		setApplier(applier);
	}
	
	
	@Override
	public void annotate() throws URISyntaxException {
		/* Preparo l'applier */
		applier = getApplier();
		System.out.println("Structure Lens Application Starting to Annotate");
		
		/* Setto le opzioni che desidero */
		applier.getOptions().setLog_assertOnNode(false);
		applier.getOptions().setLog_findSingleItem(false);
		
		/* ######### MIXED ######### */
		/* Block Pattern:
		 * A container of text and other substructures which does NOT allow other block elements in its content (even recursively)
		 * It was meant to represent block-level elements such as paragraphs. Its own content model allowes for mixed inline, popup flat and milestone elements
		 * It can only be contained by a BUCKET pattern.
		 */
		applier.buildAnnotation("Block", LensesNames.LA_URI, "expresses", LensesNames.PATTERN_URI+"Block");
		/* The headlines elements, like h2, are good examples of block elements, for their mixed content models and their usual positioning */
		applier.massAnnotate("h1", LensesNames.EMPTY_URI, applier.getLastannotation());
		applier.massAnnotate("h2", LensesNames.EMPTY_URI, applier.getLastannotation());
		applier.massAnnotate("h3", LensesNames.EMPTY_URI, applier.getLastannotation());
		/* All the elements contained by lists and tables, like td, li, etc. can be reasonably identified as blocks*/
		applier.massAnnotate("li", LensesNames.EMPTY_URI, applier.getLastannotation());
		applier.massAnnotate("th", LensesNames.EMPTY_URI, applier.getLastannotation());
		applier.massAnnotate("td", LensesNames.EMPTY_URI, applier.getLastannotation());
		applier.massAnnotate("dt", LensesNames.EMPTY_URI, applier.getLastannotation());
		applier.massAnnotate("dd", LensesNames.EMPTY_URI, applier.getLastannotation());
		/* We then have the p element. Even if block pattern is obviously inspired to this kind of elements, in general 
		 * it would be very hard to assign this element a pattern coherent to the pattern ontology without considering the context.
		 * Fortunately, the document is very structured, and ALMOST all <p> elements are located inside the main container of the document, 
		 * and most of the time they don't contain any other element that might conflict with the block pattern, such as lists or other divs. 
		 * This said, i can safely assign <p> the Block pattern to all "svArticle section" paragraphs, while I will be assigning the "Inline" one to the
		 * others, which are some kind of labels for tables, images or footnotes contained in dd/dt elements */
		applier.searchWithAttsAndAssert("p", LensesNames.EMPTY_URI, "class", "svArticle section", applier.getLastannotation());
		// OBSOLETE => applier.massAnnotate("p", LensesNames.EMPTY_URI, applier.getLastannotation());
		/* We arrive to the div element. Its general its allowed content model in (X)HTML makes this element one of the most versatile ones
		 * But we have to consider this specific case of use. As such, in Mika's Paper it is never used to directly contain any type of
		 * text. Even so, we are in a conflicting position, since it's not clearly a container. The problem is that many "span" and "a"
		 * elements are sometimes directly contained by a div. And this gives us great difficulties. As such, I will sometimes categorize
		 * it as a container and some others as a block */
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_2", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_3", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_6", applier.getLastannotation());

		
		/* Inline Pattern:
		 * This is a mixed container of text and other elements much like bucket, but it can ONLY be contained by other INLINE or BLOCK elements.
		 * It has the very same content model, and is disjoint with block
		 */
		applier.buildAnnotation("Inline", LensesNames.LA_URI, "expresses", LensesNames.PATTERN_URI+"Inline");
		/* We then have the p element. Even if block pattern is obviously inspired to this kind of elements, in general 
		 * it would be very hard to assign this element a pattern coherent to the pattern ontology without considering the context.
		 * Fortunately, the document is very structured, and ALMOST all <p> elements are located inside the main container of the document, 
		 * and most of the time they don't contain any other element that might conflict with the block pattern, such as lists or other divs. 
		 * This said, i can safely assign <p> the Block pattern to all "svArticle section" paragraphs, while I will be assigning the "Inline" one to the
		 * others, which are some kind of labels for tables, images or footnotes contained in dd/dt elements */
		HashMap<String,String> paramap = new HashMap<String, String>();
		paramap.put("class", "svArticle section");
		applier.assertOnSet(applier.findItemsExcept("p", LensesNames.EMPTY_URI, paramap), applier.getLastannotation());
		/* The span element in this document can't be limited to just an atom, like em did, even if their own content model are very similar
		 * As such, both span and a, are immediately identified as Inline */
		applier.massAnnotate("span", LensesNames.EMPTY_URI, applier.getLastannotation());
		applier.massAnnotate("a", LensesNames.EMPTY_URI, applier.getLastannotation());
		/* The same can be said about sub. As for sup, i have decided to apply the same pattern out of logical symmetry, even if in this document there would
		 * be enough space for other assignments. */
		applier.massAnnotate("sub", LensesNames.EMPTY_URI, applier.getLastannotation());
		applier.massAnnotate("sup", LensesNames.EMPTY_URI, applier.getLastannotation());
		
		/* ######### MARKER ######## */
		/* Meta Pattern:
		 * Content-less elements whose meaning depends on their presence in the document and their own attributes
		 * CHECK: They are not allowed in mixed content structures.
		 *  */
		applier.buildAnnotation("Meta", LensesNames.LA_URI, "expresses", LensesNames.PATTERN_URI+"Meta");
		/* I initially thought to assign META to the IMG tag, but then reassigned it to the Milestone pattern */
		// applier.massAnnotate("meta", LensesNames.EMPTY_URI, applier.getLastannotation()); // Non presente
		applier.massAnnotate("script", LensesNames.EMPTY_URI, applier.getLastannotation());
		
		/* Milestone Pattern:
		 * Content-less structure whose meaning depends mostly on their position in the document
		 * */
		applier.buildAnnotation("Milestone", LensesNames.LA_URI, "expresses", LensesNames.PATTERN_URI+"Milestone");
		/* Img responds well to these requirements, as well as several other header level tags */
		applier.massAnnotate("img", LensesNames.EMPTY_URI, applier.getLastannotation());
		/* HR and BR respond completely to the Milestone pattern definition */
		applier.massAnnotate("hr", LensesNames.EMPTY_URI, applier.getLastannotation());
		// applier.massAnnotate("br", LensesNames.EMPTY_URI, applier.getLastannotation()); // Non presenti
		
		/* ######### FLAT ########## */
		/* Atom Pattern:
		 * A very simple literal text class without sub-elements, that is contained by Inline or Blocks (Mixed contents) but NOT by Buckets/Containers.
		 */
		applier.buildAnnotation("Atom", LensesNames.LA_URI, "expresses", LensesNames.PATTERN_URI+"Atom");
		/* In the context of this document, em is only ever used as an atom, at leaf level, even if its theoretical content model allows for a different use
		 * However, since my aim is not to model (X)HTML, but to apply patterns to this document, i assigned it the atom pattern */
		applier.massAnnotate("em", LensesNames.EMPTY_URI, applier.getLastannotation());
		
		/* Field Pattern:
		 * A simple box of text (without other sub-elements) contained by any kind of Bucket pattern.
		 */
		applier.buildAnnotation("Field", LensesNames.LA_URI, "expresses", LensesNames.PATTERN_URI+"Field");
		
		/* ######### BUCKET ######## */
		/* Popup Pattern:
		 * It is a structure that does not allow textual content inside itself and IT IS CONTAINED ONLY BY MIXED patterns (inline/block).
		 * Thus it cannot be used as a root for documents, and can contain all the usual containers, fields, meta, or block element.
		 */
		applier.buildAnnotation("Popup", LensesNames.LA_URI, "expresses", LensesNames.PATTERN_URI+"Popup");
		/* noscript: Popup or inline? I think popup is good enough */
		applier.massAnnotate("noscript", LensesNames.EMPTY_URI, applier.getLastannotation());
		
		/* Container Pattern:
		 * A Container is a sequence of other substructures that DOES NOT DIRECTLY contain text.
		 * This pattern is meant to represent higher-document structures that give shape and organization to a text document.
		 * Is thus a sequence of heterogeneous, unordered, optional and repeatable elements
		 * Container is a super-class which includes HC, Record and Table as disjoint sub-classes.
		 * A Container can hold any kind of Bucket (except Popups), Fields, Meta and Block patterns
		 */
		applier.buildAnnotation("Container", LensesNames.LA_URI, "expresses", LensesNames.PATTERN_URI+"Container");
		/* body is the quintessential container */
		applier.massAnnotate("body", LensesNames.EMPTY_URI, applier.getLastannotation());
		/* I wish I could have been able to characterize dl as a table pattern, much like ol and ul, but it seems to me that to do so would not be correct:
		 * The problem is that, although contents of a definition list are regular and homogeneous, they are composed by an alternance of TWO regular
		 * elements, not just one. As such, I was sadly forced to assign it to the more general Container pattern.
		 * A similar line of thought forced me to assign Container also to the table  */
		applier.massAnnotate("dl", LensesNames.EMPTY_URI, applier.getLastannotation());
		applier.massAnnotate("table", LensesNames.EMPTY_URI, applier.getLastannotation());
		/* We arrive to the div element. Its general allowed content model in (X)HTML makes this element one of the most versatile ones
		 * But we have to consider this specific case of use. As such, in Mika's Paper it is never used to directly contain any type of
		 * text. Even so, we are in a conflicting position, since it's not clearly a container. The problem is that many "span" and "a"
		 * elements are sometimes directly contained by a div. And this gives us great difficulties. As such, I will sometimes categorize
		 * it as a container and some others as a block */
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_1", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_4", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_5", applier.getLastannotation());
		/* Figures and Text Boxes marked as div */
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_7", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_8", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_9", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_10", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_11", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_12", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_13", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_14", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_15", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_16", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_17", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_18", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_19", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_20", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_21", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_22", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_23", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_24", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_25", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_26", applier.getLastannotation());
		/* The last 3 divs located in the final section of the document */
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_27", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_28", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_29", applier.getLastannotation());
		
		
		/* HeadedContainer Pattern:
		 * An HeadedContainer is a container starting with a head of one or more block elements, to represent nested hierarchical elements.
		 * It has the same sequence of elements of a container, but they are headed by a sequence of blocks.   
		 */
		applier.buildAnnotation("HeadedContainer", LensesNames.LA_URI, "expresses", LensesNames.PATTERN_URI+"HeadedContainer");
		// None whatsoever in this document
		
		/* Record Pattern:
		 * A container that does not allow substructures to repeat themselves internally. 
		 * The elements included are optional, heterogeneous and non repeatable 
		 */
		applier.buildAnnotation("Record", LensesNames.LA_URI, "expresses", LensesNames.PATTERN_URI+"Record");
		/* The html tag itself is perfectly suited to this definition */
		applier.massAnnotate("html", LensesNames.EMPTY_URI, applier.getLastannotation());
		
		
		/* Table Pattern:
		 * A container that allows a repetition of homgeneous substructures. 
		 * Thus, all sub-elements are homogeneous. 
		 */
		applier.buildAnnotation("Table", LensesNames.LA_URI, "expresses", LensesNames.PATTERN_URI+"Table");
		/* Elements like ul, ol, tr and th are undoubtely encompassed by the table pattern */
		applier.massAnnotate("ul", LensesNames.EMPTY_URI, applier.getLastannotation());
		applier.massAnnotate("ol", LensesNames.EMPTY_URI, applier.getLastannotation());
		applier.massAnnotate("tr", LensesNames.EMPTY_URI, applier.getLastannotation());
		applier.massAnnotate("tbody", LensesNames.EMPTY_URI, applier.getLastannotation());
		applier.massAnnotate("thead", LensesNames.EMPTY_URI, applier.getLastannotation());
		/* I wish i could have been able to characterize dl as a table pattern, much like ol and ul. But it isn't possible (see above) */
		
		/* Stampo un riassunto delle statistiche per questa applicazione */
		applier.getInfo().summary();
	}

}
