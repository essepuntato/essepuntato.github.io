package slam.mikalens.notused;

import java.net.URISyntaxException;

import slam.BasicLensApp;
import slam.SemLensApplier;


public class SemanticAppOnMika extends BasicLensApp {

	private SemLensApplier applier;
	
	/* Costruttori */
	public SemanticAppOnMika(){
		/* Pura inizializzazione */
	}
	
	/* Costruttore base */
	public SemanticAppOnMika(SemLensApplier applier) {
		setApplier(applier);
	}
	@Override
	public void annotate() throws URISyntaxException {

	}

}
