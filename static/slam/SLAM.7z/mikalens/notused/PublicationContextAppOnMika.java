package slam.mikalens.notused;

import java.net.URISyntaxException;

import slam.BasicLensApp;
import slam.SemLensApplier;


public class PublicationContextAppOnMika extends BasicLensApp {

	private SemLensApplier applier;
	
	/* Costruttori */
	public PublicationContextAppOnMika(){
		/* Pura inizializzazione */
	}
	
	/* Costruttore base */
	public PublicationContextAppOnMika(SemLensApplier applier) {
		setApplier(applier);
	}
	
	@Override
	public void annotate() throws URISyntaxException {

	}

}
