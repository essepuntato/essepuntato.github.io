package slam.mikalens.notused;

import java.net.URISyntaxException;

import slam.BasicLensApp;
import slam.SemLensApplier;


public class ContributionAppOnMika extends BasicLensApp {

	private SemLensApplier applier;
	
	/* Costruttori */
	public ContributionAppOnMika(){
		/* Pura inizializzazione */
	}
	
	/* Costruttore base */
	public ContributionAppOnMika(SemLensApplier applier) {
		setApplier(applier);
	}
	
	@Override
	public void annotate() throws URISyntaxException {

	}

}
