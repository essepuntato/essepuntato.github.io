package slam.mikalens;


import java.net.URISyntaxException;

import slam.BasicLensApp;
import slam.SemLensApplier;
import slam.utilities.LensesNames;
import slam.utilities.MarkupItemSetReducer;


public class RhetoricAppOnMika extends BasicLensApp {
	
	private SemLensApplier applier;
	
	/* Costruttori */
	public RhetoricAppOnMika(){
		/* Pura inizializzazione */
	}
	
	/* Costruttore base */
	public RhetoricAppOnMika(SemLensApplier applier) {
		setApplier(applier);
	}
	
	
	@Override
	public void annotate() throws URISyntaxException {
		
		applier = getApplier();
		System.out.println("Rhetoric Lens Application Starting to Annotate");
		
		/* Setto le opzioni che desidero */
		applier.getOptions().setLog_assertOnNode(false);
		applier.getOptions().setLog_findSingleItem(false);
		
		
		/* I considered using this on the first div "centerpane", but then decided against it, 
		 * since if I did so the back matter would be included in the body matter, due to the markup structure of the document */
		applier.buildAnnotation("Body Matter", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"BodyMatter");
		// applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_29", applier.getLastannotation());
		
		/* There are several UL items which could be a front matter: I am applying the annotation to all of them */
		applier.buildAnnotation("Front Matter", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"FrontMatter");
		/* I decided to use the single search and assert method, as the others would be slower for such small result subsets
		 * But it might be of significance that the first UL containers for the Front Matter 
		 * are all characterized by specific attributes (id), corresponding to their role */
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_ul_1", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_ul_2", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_ul_3", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_ul_4", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_ul_5", applier.getLastannotation());
		
		/* This is the Title of the Document */
		applier.buildAnnotation("Title", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"Title");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_h1_1", applier.getLastannotation());
		
		/* Back to the first elements of the Front Matter: The Author List */
		applier.buildAnnotation("List of Authors", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"ListOfAuthors");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_ul_1", applier.getLastannotation());
		applier.buildAnnotation("Text Chunk", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"TextChunk");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_a_1", applier.getLastannotation());
		
		/* List of Organizations - Affiliations of the authors */
		applier.buildAnnotation("List of Organizations", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"ListOfOrganizations");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_ul_2", applier.getLastannotation());
		applier.buildAnnotation("DEO External Resource Description", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"ExternalResourceDescription");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_li_2", applier.getLastannotation());
		
		/* Article Date - Cannot characterize in any meaningful way */
		
		/* Article Doi - List of References */
		applier.buildAnnotation("List of References", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"ListOfReferences");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_ul_4", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_li_4", applier.getStorage().getAnnotation("DEO External Resource Description"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_li_5", applier.getStorage().getAnnotation("DEO External Resource Description"));
		
		/* Article Info - General List of information */
		applier.buildAnnotation("List", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"List");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_ul_5", applier.getLastannotation());
		applier.buildAnnotation("DEO Supplementary Info", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"SupplementaryInformationDescription");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_li_6", applier.getLastannotation());
		
		/* Onwards to the Abstract of the document */
		applier.buildAnnotation("Abstract", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"Abstract");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_4", applier.getLastannotation());
		applier.buildAnnotation("Paragraph", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"Paragraph");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_1", applier.getLastannotation());
		applier.buildAnnotation("DEO Introduction", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"Introduction");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_2", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_1", applier.getLastannotation());
		
		
		/* Keywords List */
		// I considered assigning the "Section" element to this keyword list, but in the context of the document I belive it would be meaningless
		// especially when compared to the rest of the structure. I kept the "Label" assignment to its own elements, however.
		
		// applier.buildAnnotation("Section", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"Section");
		// applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_ul_6", applier.getLastannotation());
		applier.buildAnnotation("Label", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"Label");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_li_7", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_li_8", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_li_9", applier.getLastannotation());
		
		/* ******************************************************************************** */
		/* *	Notes about Elements NOT ANNOTATED in the article text					  * */
		/* ******************************************************************************** */
		/* On Section Titles for the main text of the article -> h2 & h3 tags */
		// Unable to annotate them meaningfully, as I cannot build "section" elements of the Doco ontology, given the structure of the markup
		// I keep this comments as a remainder.
		
		/* On Internal Inline Citation References */
		// Given the uncertain situation, so far I'll simply annotate them with "deo:Reference" together with other Intra-document References
		
		/* On Footnotes references: */
		// The same problem stated above applies
		
		/* On Formula and Formula Boxes */
		// Unable to characterize them with the appropriate elements of the DOCO ontlogy, given the underlying markup structure, 
		// which forces a pattern-assignment not compatible with DOCO requirements
		
		/* On Inline Images */
		// The same problem stated above. They are also used to complete formulas
		
		
		/* Onwards to the Article Body */
		/* Main Text Paragraphs */
		// All the main body text is included in p elements, which are doco:Paragraphs
		applier.searchWithAttsAndAssert("p", LensesNames.EMPTY_URI, "class", "svArticle section", applier.getStorage().getAnnotation("Paragraph"));
		
		// Annotation of DEO statements will be done paragraph per paragraph.
		applier.buildAnnotation("DEO Background", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"Background");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_2", applier.getLastannotation());
		
		applier.buildAnnotation("DEO Problem Statement", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"ProblemStatement");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_3", applier.getLastannotation());
		
		applier.buildAnnotation("DEO Motivation", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"Motivation");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_4", applier.getLastannotation());
		
		applier.buildAnnotation("DEO Model", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"Model");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_5", applier.getLastannotation());
		
		applier.assertOnNode(applier.findSingleMarkupItem("http://www.essepuntato.it/2010/04/SWWEx#e_p_5"), 
				applier.getStorage().getAnnotation("DEO Model"));
		
		/* ***** Intra-document references ***** */
		applier.buildAnnotation("DEO Reference", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"Reference");
		// I'm using DEO:Reference to annotate them.
		// By the way, I am currently using a very BROAD annotation, that will cover also inline citations
		applier.searchWithAttsAndAssert("a", LensesNames.EMPTY_URI, "class", "intra_ref", applier.getLastannotation());
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_6", applier.getStorage().getAnnotation("DEO Background"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_7", applier.getStorage().getAnnotation("DEO Background"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_8", applier.getStorage().getAnnotation("DEO Background"));
		
		// I wish I could introduce a new DEO term, to assert that an text section is used to point out something, or to refine some concepts.
		// TODO PRECISAZIONE?
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_9", applier.getStorage().getAnnotation("DEO Background"));
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_10", applier.getStorage().getAnnotation("DEO Model"));
		
		applier.buildAnnotation("DEO Methods", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"Methods");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_11", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_12", applier.getLastannotation());
		
		// I finally find a well done markup for a formula-box to be applied.
		applier.buildAnnotation("Formula Box", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"FormulaBox");
		/* As before, since it is an element that appears in the document only once,
		 * I decided to use the single search and assert method, as the others would be slower for such small result subsets
		 * But it might be of significance that classes like "formula" and "mathml" are used to characterize this divs */
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_5", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_5", applier.getStorage().getAnnotation("DEO Model"));
		applier.buildAnnotation("Formula", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"Formula");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_6", applier.getLastannotation());
		/* There is a SERIOUS recurring problem in the assignment of this LensesNames.DOCO_URI+"Formula" to this div, 
		 * as it should be in theory assigned to a Popup pattern element */
		
		/* The text continues */
		applier.buildAnnotation("DEO Scenario", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"Scenario");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_13", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_14", applier.getLastannotation());
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_15", applier.getStorage().getAnnotation("DEO Model"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_16", applier.getStorage().getAnnotation("DEO Model"));
		
		// I was very uncertain on what kind of DEO to assign at this point - In the end i opted for Methods
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_17", applier.getStorage().getAnnotation("DEO Methods"));
		// OK NUMERAZIONE PARAGRAFI
		
		/* Onwards to section 2.1 */
		applier.buildAnnotation("DEO Related Work", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"RelatedWork");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_18", applier.getLastannotation());
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_19", applier.getStorage().getAnnotation("DEO Methods"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_20", applier.getStorage().getAnnotation("DEO Methods"));
		
		applier.buildAnnotation("DEO Discussion", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"Discussion");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_21", applier.getLastannotation());
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_22", applier.getStorage().getAnnotation("DEO Methods"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_23", applier.getStorage().getAnnotation("DEO Model"));
		
		applier.buildAnnotation("DEO Data", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"Data");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_24", applier.getLastannotation());
		// OK NUMERAZIONE PARAGRAFI
		
		/* Start of Section 3 */
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_25", applier.getStorage().getAnnotation("DEO Methods"));
		
		// As an alternative, the three following paragraphs could have been annotated as Background again, but I opted for Scenario
		applier.buildAnnotation("DEO Scenario", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"Scenario");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_26", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_27", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_28", applier.getLastannotation());
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_29", applier.getStorage().getAnnotation("DEO Methods"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_30", applier.getStorage().getAnnotation("DEO Methods"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_31", applier.getStorage().getAnnotation("DEO Model"));
		// OK NUMERAZIONE PARAGRAFI
		
		/* *** Figure Boxes *** */
		/* This time I'll be able to use the classes and ids to annotate all of them in a single stroke */
		applier.buildAnnotation("Figure Box", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"FigureBox");
		applier.searchWithWildAttsAndAssert("div", LensesNames.EMPTY_URI, "id", "figure_fig*", applier.getLastannotation());
		
		applier.buildAnnotation("Figure", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"Figure");
		MarkupItemSetReducer reducer_figlarge = new MarkupItemSetReducer(applier.findItemsWithAtts("img", LensesNames.EMPTY_URI, "class", "figure large"));
		// reducer_figlarge.keep(applier.findItemsWithWildAtts("img", LensesNames.EMPTY_URI, "alt", "Full-size image (*K)"));
		applier.assertOnSet(reducer_figlarge.keep(applier.findItemsWithWildAtts("img", LensesNames.EMPTY_URI, "alt", "Full-size image (*K)")), applier.getLastannotation());
		// There were 2 <img> XHTML elements with the same class "figure large" for each image, one inside a noscript, the other outside.
		// Since there were only 6 figures in the documents, i could have annotated them manually, but instead i opted to show the adaptability of EarMark APIs
		// I acted on the fact that the alt attribute is different for each of those 2 images, and used my own apis to select just one subset of 6 images
		
		// These two images are Data classes for DEO
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_dl_1", applier.getStorage().getAnnotation("DEO Data"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_dl_2", applier.getStorage().getAnnotation("DEO Data"));
		
		/* These are the images caption for all the document */
		applier.buildAnnotation("Figure Label", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"FigureLabel");
		applier.searchWithWildAttsAndAssert("dd", LensesNames.EMPTY_URI, "id", "labelCaptionfig*", applier.getLastannotation());
		applier.buildAnnotation("DEO Caption", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"Caption");
		applier.searchWithWildAttsAndAssert("dd", LensesNames.EMPTY_URI, "id", "labelCaptionfig*", applier.getLastannotation());
		
		
		/* The text continues - 2 paragraphs lost due to captions */
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_34", applier.getStorage().getAnnotation("DEO Data"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_35", applier.getStorage().getAnnotation("DEO Data"));
		// OK NUMERAZIONE PARAGRAFI
		
		/* *** Table *** */
		// I'll start by applying the deo:Data on the table contents for this table and the next
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_11", applier.getStorage().getAnnotation("DEO Data"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_13", applier.getStorage().getAnnotation("DEO Data"));
		
		// To annotate the Table Box, I'll use the same method I adopted to annotate the figure boxes
		applier.buildAnnotation("Table Box", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"TableBox");
		applier.searchWithWildAttsAndAssert("div", LensesNames.EMPTY_URI, "id", "table_tbl*", applier.getLastannotation());
		
		/* The table label & caption */
		applier.buildAnnotation("Table Label", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"TableLabel");
		// This time I'll need to annotate them by hand, since the markup does not offer any kind of regularities.
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_dd_3", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_dd_3", applier.getStorage().getAnnotation("DEO Caption"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_dd_6", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_dd_6", applier.getStorage().getAnnotation("DEO Caption"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_dd_9", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_dd_9", applier.getStorage().getAnnotation("DEO Caption"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_dd_12", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_dd_12", applier.getStorage().getAnnotation("DEO Caption"));
		
		// The Table Itself
		applier.buildAnnotation("Table", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"Table");
		applier.searchWithAttsAndAssert("dd", LensesNames.EMPTY_URI, "class", "table", applier.getLastannotation());
		
		/* The text continues - 1 para for the table */
		// As an alternative, the three following paragraphs could have been annotated as Discussion, but I opted for Evaluation
		applier.buildAnnotation("DEO Evaluation", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"Evaluation");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_37", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_38", applier.getLastannotation());
		// Another para lost for table caption
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_40", applier.getLastannotation());
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_41", applier.getStorage().getAnnotation("DEO Discussion"));
		
		// An anticipation of the conclusions and another para lost
		applier.buildAnnotation("DEO Conclusion", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"Conclusion");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_43", applier.getLastannotation());
		// OK NUMERAZIONE PARAGRAFI
		
		/* Section 3.2 */
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_44", applier.getStorage().getAnnotation("DEO Problem Statement"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_45", applier.getStorage().getAnnotation("DEO Problem Statement"));
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_46", applier.getStorage().getAnnotation("DEO Model"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_47", applier.getStorage().getAnnotation("DEO Model"));
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_48", applier.getStorage().getAnnotation("DEO Methods"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_49", applier.getStorage().getAnnotation("DEO Methods"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_50", applier.getStorage().getAnnotation("DEO Methods"));
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_51", applier.getStorage().getAnnotation("DEO Data"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_52", applier.getStorage().getAnnotation("DEO Data"));
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_53", applier.getStorage().getAnnotation("DEO Discussion"));
		// OK NUMERAZIONE PARAGRAFI
		
		/* Section 4 */
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_54", applier.getStorage().getAnnotation("DEO Methods"));
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_55", applier.getStorage().getAnnotation("DEO Data"));
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_56", applier.getStorage().getAnnotation("DEO Evaluation"));
		
		// Applying an annotation for the other two tables (the 3rd, previously found and the 4th) - another para lost
		applier.buildAnnotation("DEO Results", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"Results");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_15", applier.getLastannotation());
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_17", applier.getLastannotation());
		// OK NUMERAZIONE PARAGRAFI
		
		/* Section 5 */
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_58", applier.getStorage().getAnnotation("DEO Related Work")); // OK
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_59", applier.getStorage().getAnnotation("DEO Discussion")); // OK
		
		// 4 Para lost for quadruple figure caption
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_64", applier.getStorage().getAnnotation("DEO Evaluation")); // OK
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_65", applier.getStorage().getAnnotation("DEO Discussion"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_66", applier.getStorage().getAnnotation("DEO Discussion"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_67", applier.getStorage().getAnnotation("DEO Discussion"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_68", applier.getStorage().getAnnotation("DEO Discussion"));
		// OK NUMERAZIONE PARAGRAFI
		
		/* Section 6 */
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_69", applier.getStorage().getAnnotation("DEO Conclusion"));
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_70", applier.getStorage().getAnnotation("DEO Conclusion"));
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_71", applier.getStorage().getAnnotation("DEO Related Work"));
		
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_p_72", applier.getStorage().getAnnotation("DEO Conclusion"));
		
		/* *** Back Matter *** */
		/* Bibliography */
		// As I did before, I'll reference these elements individually, for faster searches when having such small subsets
		applier.buildAnnotation("Back Matter", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"BackMatter");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_27", applier.getLastannotation());
		
		applier.buildAnnotation("Bibliography", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"Bibiliography");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_28", applier.getLastannotation());
		
		applier.buildAnnotation("Bibliographic Reference List", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"BibliographicReferenceList");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_ol_1", applier.getLastannotation());
		
		applier.buildAnnotation("DEO Bilbliographic Reference", LensesNames.LA_URI, "expresses", LensesNames.DEO_URI+"BibliographicReference");
		applier.searchWithAttsAndAssert("ul", LensesNames.EMPTY_URI, "class", "reference", applier.getLastannotation());
		
		applier.searchWithAttsAndAssert("li", LensesNames.EMPTY_URI, "class", "referenceLabel", applier.getStorage().getAnnotation("Label"));
		
		/* Footnotes */
		applier.buildAnnotation("List Of References", LensesNames.LA_URI, "expresses", LensesNames.DOCO_URI+"ListOfReferences");
		applier.searchAndAssert("http://www.essepuntato.it/2010/04/SWWEx#e_div_29", applier.getLastannotation());
		
		applier.searchWithAttsAndAssert("dt", LensesNames.EMPTY_URI, "class", "label", applier.getStorage().getAnnotation("Label"));
		
		/* Stampo un riassunto delle statistiche per questa applicazione */
		applier.getInfo().summary();
	}

}
