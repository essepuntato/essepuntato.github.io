package slam.mikalens;


import java.net.URISyntaxException;

import slam.BasicLensApp;
import slam.SemLensApplier;
import slam.utilities.LensesNames;


public class CitationAppOnMika extends BasicLensApp {
	
	private SemLensApplier applier;
	
	/* Costruttori */
	public CitationAppOnMika(){
		/* Pura inizializzazione */
	}
	
	/* Costruttore base */
	public CitationAppOnMika(SemLensApplier applier) {
		setApplier(applier);
	}
	
	@Override
	public void annotate() throws URISyntaxException {

		applier = getApplier();
		System.out.println("Citation Lens Application Starting to Annotate");
		
		/* Setto le opzioni che desidero */
		applier.getOptions().setVerbosity_overall(3);
		applier.getOptions().setLog_findItemsWithAtts(false);
		applier.getOptions().setLog_findItemsByGIDAndNS(false);
		applier.getOptions().setLog_createProperty(false);
		applier.getOptions().setLog_findSingleItem(false);
		
		// Citazione [1]
		applier.buildEMAnnotation("Cites As Authority [1]", LensesNames.CITO_URI, "citesAsAuthority", "http://www.essepuntato.it/2010/04/SWWEx#e_li_10");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib1"), applier.getLastannotation());
		applier.buildEMAnnotation("Confirms [1]", LensesNames.CITO_URI, "confirms", "http://www.essepuntato.it/2010/04/SWWEx#e_li_10");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib1"), applier.getLastannotation());
		applier.buildEMAnnotation("Obtains Background From [1]", LensesNames.CITO_URI, "obtainsBackgroundFrom", "http://www.essepuntato.it/2010/04/SWWEx#e_li_10");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib1"), applier.getLastannotation());
		applier.buildEMAnnotation("Cites For Information [1]", LensesNames.CITO_URI, "citesForInformation", "http://www.essepuntato.it/2010/04/SWWEx#e_li_10");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib1"), applier.getLastannotation());
		
		// Citazione [2]		
		applier.buildEMAnnotation("Obtains Background From [2]", LensesNames.CITO_URI, "obtainsBackgroundFrom", "http://www.essepuntato.it/2010/04/SWWEx#e_li_15");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib2"), applier.getLastannotation());
		applier.buildEMAnnotation("Cites For Information [2]", LensesNames.CITO_URI, "citesForInformation", "http://www.essepuntato.it/2010/04/SWWEx#e_li_15");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib2"), applier.getLastannotation());
		applier.buildEMAnnotation("Disagrees With [2]", LensesNames.CITO_URI, "disagreesWith", "http://www.essepuntato.it/2010/04/SWWEx#e_li_15");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib2"), applier.getLastannotation());
		
		/* ** Cross References between [1] & [2] that might be inferred from the text ** */ // Not correct at all
//		applier.buildEMAnnotation("[2] Qualifies [1]", LensesNames.CITO_URI, "qualifies", "http://www.essepuntato.it/2010/04/SWWEx#e_li_10");
//		applier.searchAndAssertEM("http://www.essepuntato.it/2010/04/SWWEx#e_li_15", applier.getLastannotation());
		
		// Citazione [3]
		applier.buildEMAnnotation("Obtains Background From [3]", LensesNames.CITO_URI, "obtainsBackgroundFrom", "http://www.essepuntato.it/2010/04/SWWEx#e_li_20");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib3"), applier.getLastannotation());
		applier.buildEMAnnotation("Critiques [3]", LensesNames.CITO_URI, "critiques", "http://www.essepuntato.it/2010/04/SWWEx#e_li_20");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib3"), applier.getLastannotation());
		applier.buildEMAnnotation("Cites As Related [3]", LensesNames.CITO_URI, "citesAsRelated", "http://www.essepuntato.it/2010/04/SWWEx#e_li_20");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib3"), applier.getLastannotation());
		applier.buildEMAnnotation("Reviews [3]", LensesNames.CITO_URI, "reviews", "http://www.essepuntato.it/2010/04/SWWEx#e_li_20");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib3"), applier.getLastannotation());
		applier.buildEMAnnotation("Corrects [3]", LensesNames.CITO_URI, "corrects", "http://www.essepuntato.it/2010/04/SWWEx#e_li_20");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib3"), applier.getLastannotation());
		applier.buildEMAnnotation("Uses Conclusions From [3]", LensesNames.CITO_URI, "usesConclusionsFrom", "http://www.essepuntato.it/2010/04/SWWEx#e_li_20");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib3"), applier.getLastannotation());
		
		// Citazione [4]
		applier.buildEMAnnotation("Obtains Background From [4]", LensesNames.CITO_URI, "obtainsBackgroundFrom", "http://www.essepuntato.it/2010/04/SWWEx#e_li_23");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib4"), applier.getLastannotation());
		applier.buildEMAnnotation("Confirms [4]", LensesNames.CITO_URI, "confirms", "http://www.essepuntato.it/2010/04/SWWEx#e_li_23");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib4"), applier.getLastannotation());
		applier.buildEMAnnotation("Shares Author With [4]", LensesNames.CITO_URI, "sharesAuthorWith", "http://www.essepuntato.it/2010/04/SWWEx#e_li_23");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib4"), applier.getLastannotation());
		applier.buildEMAnnotation("Agrees With [4]", LensesNames.CITO_URI, "agreesWith", "http://www.essepuntato.it/2010/04/SWWEx#e_li_23");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib4"), applier.getLastannotation());
		applier.buildEMAnnotation("Extends [4]", LensesNames.CITO_URI, "extends", "http://www.essepuntato.it/2010/04/SWWEx#e_li_23");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib4"), applier.getLastannotation());
		
		// Citazione [5]
		applier.buildEMAnnotation("Cites As Authority [5]", LensesNames.CITO_URI, "citesAsAuthority", "http://www.essepuntato.it/2010/04/SWWEx#e_li_28");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib5"), applier.getLastannotation());
		applier.buildEMAnnotation("Uses Conclusions From [5]", LensesNames.CITO_URI, "usesConclusionsFrom", "http://www.essepuntato.it/2010/04/SWWEx#e_li_28");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib5"), applier.getLastannotation());
		
		// Citazione [6]
		applier.buildEMAnnotation("Cites For Information [6]", LensesNames.CITO_URI, "citesForInformation", "http://www.essepuntato.it/2010/04/SWWEx#e_li_33");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib6"), applier.getLastannotation());
		applier.buildEMAnnotation("Obtains Background From [6]", LensesNames.CITO_URI, "obtainsBackgroundFrom", "http://www.essepuntato.it/2010/04/SWWEx#e_li_33");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib6"), applier.getLastannotation());
		applier.buildEMAnnotation("Uses Conclusions From [6]", LensesNames.CITO_URI, "usesConclusionsFrom", "http://www.essepuntato.it/2010/04/SWWEx#e_li_33");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib6"), applier.getLastannotation());
		applier.buildEMAnnotation("Uses Method In [6]", LensesNames.CITO_URI, "usesMethodIn", "http://www.essepuntato.it/2010/04/SWWEx#e_li_33");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib6"), applier.getLastannotation());
		applier.buildEMAnnotation("Credits [6]", LensesNames.CITO_URI, "credits", "http://www.essepuntato.it/2010/04/SWWEx#e_li_33");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib6"), applier.getLastannotation());
		
		// Citazione [7]
		applier.buildEMAnnotation("Critiques [7]", LensesNames.CITO_URI, "critiques", "http://www.essepuntato.it/2010/04/SWWEx#e_li_38");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib7"), applier.getLastannotation());
		applier.buildEMAnnotation("Cites As Related [7]", LensesNames.CITO_URI, "citesAsRelated", "http://www.essepuntato.it/2010/04/SWWEx#e_li_38");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib7"), applier.getLastannotation());
		// DIFFERENZIA!!! Proposta di arricchimento lente. Inoltre, seguono due annotazioni "dubbie"
		// applier.buildEMAnnotation("Cites For Information [7]", LensesNames.CITO_URI, "citesForInformation", "http://www.essepuntato.it/2010/04/SWWEx#e_li_38");
		// applier.assertOnSetEM(applier.findItemsWithAtts("span", LensesNames.EMPTY_URI, "id", "bbib7"), applier.getLastannotation());
		
		// Citazione [8]
		applier.buildEMAnnotation("Updates [8]", LensesNames.CITO_URI, "updates", "http://www.essepuntato.it/2010/04/SWWEx#e_li_41");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib8"), applier.getLastannotation());
		applier.buildEMAnnotation("Cites As Related [8]", LensesNames.CITO_URI, "citesAsRelated", "http://www.essepuntato.it/2010/04/SWWEx#e_li_41");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib8"), applier.getLastannotation());
		// applier.buildEMAnnotation("Cites For Information [8]", LensesNames.CITO_URI, "citesForInformation", "http://www.essepuntato.it/2010/04/SWWEx#e_li_41");
		// applier.assertOnSetEM(applier.findItemsWithAtts("span", LensesNames.EMPTY_URI, "id", "bbib8"), applier.getLastannotation());
		
		// Citazione [9]
		applier.buildEMAnnotation("Uses Method In [9]", LensesNames.CITO_URI, "usesMethodIn", "http://www.essepuntato.it/2010/04/SWWEx#e_li_46");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib9"), applier.getLastannotation());
		applier.buildEMAnnotation("Cites For Information [9]", LensesNames.CITO_URI, "citesForInformation", "http://www.essepuntato.it/2010/04/SWWEx#e_li_46");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib9"), applier.getLastannotation());
		applier.buildEMAnnotation("Credits [9]", LensesNames.CITO_URI, "credits", "http://www.essepuntato.it/2010/04/SWWEx#e_li_46");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib9"), applier.getLastannotation());
		// Attenzione! Scopro qua che mi serve annotare sugli "a" e non sugli span!, perchè ogni tanto ho riferimenti che non sono in uno span!!
		
		// Citazione [10]
		applier.buildEMAnnotation("Credits [10]", LensesNames.CITO_URI, "credits", "http://www.essepuntato.it/2010/04/SWWEx#e_li_51");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib10"), applier.getLastannotation());
		applier.buildEMAnnotation("Cites As Related [10]", LensesNames.CITO_URI, "citesAsRelated", "http://www.essepuntato.it/2010/04/SWWEx#e_li_51");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib10"), applier.getLastannotation());
		
		// Citazione [11]
		applier.buildEMAnnotation("Credits [11]", LensesNames.CITO_URI, "credits", "http://www.essepuntato.it/2010/04/SWWEx#e_li_56");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib11"), applier.getLastannotation());
		applier.buildEMAnnotation("Cites As Related [11]", LensesNames.CITO_URI, "citesAsRelated", "http://www.essepuntato.it/2010/04/SWWEx#e_li_56");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib11"), applier.getLastannotation());
		
		// Citazione [12]
		applier.buildEMAnnotation("Uses Method In [12]", LensesNames.CITO_URI, "usesMethodIn", "http://www.essepuntato.it/2010/04/SWWEx#e_li_59");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib12"), applier.getLastannotation());
		applier.buildEMAnnotation("Uses Conclusions From [12]", LensesNames.CITO_URI, "usesConclusionsFrom", "http://www.essepuntato.it/2010/04/SWWEx#e_li_59");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib12"), applier.getLastannotation());
		applier.buildEMAnnotation("Credits [12]", LensesNames.CITO_URI, "credits", "http://www.essepuntato.it/2010/04/SWWEx#e_li_59");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib12"), applier.getLastannotation());
		applier.buildEMAnnotation("Cites As Related [12]", LensesNames.CITO_URI, "citesAsRelated", "http://www.essepuntato.it/2010/04/SWWEx#e_li_59");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib12"), applier.getLastannotation());
		
		// Citazione [13]
		applier.buildEMAnnotation("Shares Author With [13]", LensesNames.CITO_URI, "sharesAuthorWith", "http://www.essepuntato.it/2010/04/SWWEx#e_li_64");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib13"), applier.getLastannotation());
		applier.buildEMAnnotation("Extends [13]", LensesNames.CITO_URI, "extends", "http://www.essepuntato.it/2010/04/SWWEx#e_li_64");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib13"), applier.getLastannotation());
		applier.buildEMAnnotation("Uses Data From [13]", LensesNames.CITO_URI, "usesDataFrom", "http://www.essepuntato.it/2010/04/SWWEx#e_li_64");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib13"), applier.getLastannotation());
		applier.buildEMAnnotation("Cites As Data Source [13]", LensesNames.CITO_URI, "citesAsDataSource", "http://www.essepuntato.it/2010/04/SWWEx#e_li_64");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib13"), applier.getLastannotation());
		
		// Citazione [14]
		applier.buildEMAnnotation("Cites For Information [14]", LensesNames.CITO_URI, "citesForInformation", "http://www.essepuntato.it/2010/04/SWWEx#e_li_69");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib14"), applier.getLastannotation());
		applier.buildEMAnnotation("Obtains Support From [14]", LensesNames.CITO_URI, "obtainsSupportFrom", "http://www.essepuntato.it/2010/04/SWWEx#e_li_69");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib14"), applier.getLastannotation());
		applier.buildEMAnnotation("Credits [14]", LensesNames.CITO_URI, "credits", "http://www.essepuntato.it/2010/04/SWWEx#e_li_69");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib14"), applier.getLastannotation());
		applier.buildEMAnnotation("Confirms [14]", LensesNames.CITO_URI, "confirms", "http://www.essepuntato.it/2010/04/SWWEx#e_li_69");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib14"), applier.getLastannotation());
		
		// Citazione [15]
		applier.buildEMAnnotation("Agrees With [15]", LensesNames.CITO_URI, "agreesWith", "http://www.essepuntato.it/2010/04/SWWEx#e_li_74");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib15"), applier.getLastannotation());
		applier.buildEMAnnotation("Reviews [15]", LensesNames.CITO_URI, "reviews", "http://www.essepuntato.it/2010/04/SWWEx#e_li_74");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib15"), applier.getLastannotation());
		applier.buildEMAnnotation("Cites As Related [15]", LensesNames.CITO_URI, "citesAsRelated", "http://www.essepuntato.it/2010/04/SWWEx#e_li_74");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib15"), applier.getLastannotation());
		// Future Work???
		
		// Citazione [16]
		applier.buildEMAnnotation("Shares Author With [16]", LensesNames.CITO_URI, "sharesAuthorWith", "http://www.essepuntato.it/2010/04/SWWEx#e_li_79");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib16"), applier.getLastannotation());
		applier.buildEMAnnotation("Confirms [16]", LensesNames.CITO_URI, "confirms", "http://www.essepuntato.it/2010/04/SWWEx#e_li_79");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib16"), applier.getLastannotation());
		applier.buildEMAnnotation("Extends [16]", LensesNames.CITO_URI, "extends", "http://www.essepuntato.it/2010/04/SWWEx#e_li_79");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib16"), applier.getLastannotation());
		applier.buildEMAnnotation("Cites For Information [16]", LensesNames.CITO_URI, "citesForInformation", "http://www.essepuntato.it/2010/04/SWWEx#e_li_79");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib16"), applier.getLastannotation());
		
		// Citazione [17]
		applier.buildEMAnnotation("Discusses [17]", LensesNames.CITO_URI, "discusses", "http://www.essepuntato.it/2010/04/SWWEx#e_li_84");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib17"), applier.getLastannotation());
		// Differenzia!!!
		
		// Citazione [18]
		applier.buildEMAnnotation("Discusses [18]", LensesNames.CITO_URI, "discusses", "http://www.essepuntato.it/2010/04/SWWEx#e_li_89");
		applier.assertOnSetEM(applier.findItemsWithAtts("a", LensesNames.EMPTY_URI, "href", "#bib18"), applier.getLastannotation());
		// Differenzia!!!
		
		/* Stampo un riassunto delle statistiche per questa applicazione */
		applier.getInfo().summary();
	}

}
