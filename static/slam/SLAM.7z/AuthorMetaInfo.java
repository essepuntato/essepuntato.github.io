package slam;

import java.net.URI;

/** 
 * This class is a generic and simple optional Black Box to hold and store information about the author of a Semantic Lens Application. 
 * Most of the meaningful data should either be held or within the annotated document itself or in a structured form elsewhere (FOAF, for example), 
 * this object just offers pointers to them.
 * 
 * @author Jacopo Zingoni
 */
public class AuthorMetaInfo {
	/**
	 * A String with the name of the Author
	 */
	private String name;
	/**
	 * A String with the affiliation of the Author
	 */
	private String affiliation;
	/**
	 * An URI identifying the author
	 */
	private URI uri_id;
	/**
	 * An URI pointing at a location containing a FOAF of the author
	 */
	private URI foaf;
	/**
	 * A String with some brief contact infomations
	 */
	private String contactinfo;
	
	// Generic Constructor
	/**
	 * A generic, empty constructor
	 */
	public AuthorMetaInfo() {
	}
	
	
	// Getters and Setters
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to sete
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the affiliation
	 */
	public String getAffiliation() {
		return affiliation;
	}
	/**
	 * @param affiliation the affiliation to set
	 */
	public void setAffiliation(String affiliation) {
		this.affiliation = affiliation;
	}
	/**
	 * @return the uri_id
	 */
	public URI getUri_id() {
		return uri_id;
	}
	/**
	 * @param uri_id the uri_id to set
	 */
	public void setUri_id(URI uri_id) {
		this.uri_id = uri_id;
	}
	/**
	 * @return the foaf
	 */
	public URI getFoaf() {
		return foaf;
	}
	/**
	 * @param foaf the foaf to set
	 */
	public void setFoaf(URI foaf) {
		this.foaf = foaf;
	}
	/**
	 * @return the contactinfo
	 */
	public String getContactinfo() {
		return contactinfo;
	}
	/**
	 * @param contactinfo the contactinfo to set
	 */
	public void setContactinfo(String contactinfo) {
		this.contactinfo = contactinfo;
	}
}
