package slam;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.hp.hpl.jena.rdf.model.Statement;

import it.essepuntato.earmark.core.Attribute;
import it.essepuntato.earmark.core.Collection;
import it.essepuntato.earmark.core.EARMARKChildNode;
import it.essepuntato.earmark.core.EARMARKDocument;
import it.essepuntato.earmark.core.EARMARKItem;
import it.essepuntato.earmark.core.MarkupItem;

/**
 * This class provides an extension of the EARMARK APIs in term of methods to find and select nodes in an EARMARKDocument, especially MarkupItems. 
 * The results of these searches are then reused to annotate Semantic Lenses on specific elements or sub sets of items.
 * This class is extended by the SemLensApplier class. 
 * It was originally part of the Applier, but it was then decoupled to offer more flexibility for other applications
 * 
 * The class itself is a large collection of public methods, ready to be used to select elements on a EARMARK document or Jena Model
 * In addition to providing semantic sugar for some of the already available methods of the EARMARK APIs, this class adds several features:
 * Prominently, the ability to select sets of elements by the presence of attributes, by the contents of said attributes (with wildcard support)
 * and the possibility to select all the elements NOT having a certain match of attributes and contents.
 * 
 * @author Jacopo
 *
 */

public class EarmarkFinder {

	/**
	 * A String name which acts as an identifier for the Finder
	 */
	private String name;
	
	/**
	 * This element contains all the options for the behaviour and the output of the Applier, and it's ready to be customized by the user
	 */
	private EarmarkFinderPreferences options;
	
	/**
	 * This is the handler to the EARMARKDocument where I will perform the searchs 
	 */
	private EARMARKDocument document;
	
	/** This field contains the last MarkupItem object found */
	private MarkupItem currentitem;
	/** This field contains the last EARMARKItem object found */
	private EARMARKItem currententity;
	/** This field contains the last Set<MarkupItem> object found */
	private Set<MarkupItem> lastitemset;
	/** This field contains the last Statement object found */
	private Statement laststatement;
	
	
	/**
	 * Suggested Constructor for the class.
	 * It requires a name, the type of the lens, the handler to the EARMARKDocument on which the applier is going to operate and a description for the storage
	 * 
	 * @param name the identifier of the Finder
	 * @param document the EARMARKDocument which will be the target of the searches and on which the Finder is going to work.
	 */
	public EarmarkFinder (String name, EARMARKDocument document){
		this.name = name;
		this.document = document;
		optionsInit();
	}
	
	
	/**
	 * This initializes the preferences relative to this Applier
	 */
	public void optionsInit () {
		setOptions(new EarmarkFinderPreferences());
	}
	
	
	
	/**
	 * This is the correct method that the Applier uses to find an Entity by ID inside the EARMARKDocument.
	 * A single EARMARKItem will be searched by the specified id, and then returned if found, after being stored in the currententity field.
	 * 
	 * @param id This is the String identifying the EARMARKItem. The id will be automatically transformed into URI inside the method
	 * @return the EARMARKItem with the corresponding id (or null if nothing was found)
	 * @throws URISyntaxException if the id will not be parsed correctly as a valid URI
	 */
	public EARMARKItem findSingleItem(String id) throws URISyntaxException{
		URI iduri = new URI(id);
		EARMARKItem result = document.getEntityById(iduri);
		if (result == null) {
			System.err.println("Finder Error: No entity was found corresponding to Id: " + id); // In case of no result
			return null;
		}
			if ((getOptions().getVerbosity_finder() >= 2) && (getOptions().isLog_findSingleItem())) // Output Log
			{
				System.out.println("Finder: Found node with ID: "+result.hasId());
			}
		currententity = result;
		
		return currententity;
	}
	
	/**
	 * The same as findSingleItem, this is a shortcut method with the same intent, but it returns a MarkupItem instead of the more generic EARMARKItem
	 * It is NOT to be used with Ranges! Entities searched by this method should only be MarkupItems.
	 * The item found is stored in the currentitem field
	 * 
	 * @param id This is the String identifying the EARMARKItem. The id will be automatically transformed into URI inside the method
	 * @return the EARMARKItem with the corresponding id (or null if nothing was found)
	 * @throws URISyntaxException if the id will not be parsed correctly as a valid URI
	 */
	public MarkupItem findSingleMarkupItem(String id) throws URISyntaxException{
		currentitem = (MarkupItem) findSingleItem(id);
		return currentitem;
	}
	
	/*
	 * Massive Methods & Others - Might be less useful.
	 */
	/**
	 *  This method is used to find a Set of Nodes by General ID in the EARMARKDocument of the Applier.
	 *  This is simply some syntactic sugar for the getMarkupItemByGeneralIdentifier method of the Earmark API
	 *  
	 *   @param gid The general identifier of the MarkupItems to be found in the document
	 *   @return A Set<MarkupItem> with all the items sharing the same GeneralIdentifier in the EARMARKDocument on which the Applier is working
	 */
	public Set<MarkupItem> findItemsByGID(String gid){
		Set<MarkupItem> result; // The output of the Earmark get
		result = document.getMarkupItemByGeneralIdentifier(gid); // Getting the MarkupItems in the EARMARKDocument
		if (result.isEmpty()) {
			System.err.println("No entity was found corresponding to the Id: " + gid); // In case of no results
			return null;
		}
		
			if ((getOptions().getVerbosity_finder() >= 3) && (getOptions().isLog_findItemsByGID())) // Output Log
			{
				System.out.println("Finder Verbose: Found " + result.size() + " items when searching with Id: " + gid);
			}
		
		lastitemset = result;
		return result;
	}
	
	/* Method to find a Set of nodes by general ID and Namespace in the document - Synt Sugar */
	/**
	 * 	This method is used to find a Set of Nodes by General ID and Namespace in the EARMARKDocument of the Applier.
	 *  This is simply some syntactic sugar for the getMarkupItemByGeneralIdentifierAndNamespace method of the Earmark API
	 *  
	 * @param gid The general identifier of the MarkupItems to be found in the document
	 * @param ns The namespace of the MarkupItems to be found in the document
	 * @return A Set<MarkupItem> with all the items sharing the same GeneralIdentifier in the EARMARKDocument on which the Applier is working
	 * @throws URISyntaxException if the ns will not be parsed correctly as a valid URI
	 */
	public Set<MarkupItem> findItemsByGIDAndNS(String gid, String ns) throws URISyntaxException{
		URI ens = new URI(ns);
		Set<MarkupItem> result; // The output of the Earmark get
		result = document.getMarkupItemByGeneralIdentifierAndNamespace(gid, ens); // Getting the MarkupItems in the EARMARKDocument
		if (result.isEmpty()) {
			System.err.println("No entity was found corresponding to the Id: " + gid + " with namespace NS: " + ns); // In case of no results
			return null;
		}
		
			if ((getOptions().getVerbosity_finder() >= 3)	
					&&	
					(getOptions().isLog_findItemsByGIDAndNS())) // Output Log
			{
				System.out.println("Finder Verbose: Found " + result.size() + " items when searching with Id: " + gid + " and namespace NS: " + ns);
			}
			
		lastitemset = result;
		return result;
	}
	
	/* 
	 * New Idea! Advanced Methods to select all elements that have a certain attribute, or that have a certain attribute and a specific value
	 */ 
	/**
	* This method returns selects all the elements in the EARMARKDocument with the same GID that have as a child a chosen attribute equal to a specified value
	* The method searches by GID and Namespace, like the FindItemsByGIDAndNS method, then it refines the set resulted by the search.
	* It iterates over the set, keeping only the MarkupItems having as child a chosen Attribute node with the value equal to one desired
	* 
	* @param gid The general identifier of the MarkupItems to be found in the document
	* @param ens The namespace of the MarkupItems to be found in the document
	* @param attr The name of the Attribute to be searched. It has to be present as the child of an element to be selected
	* @param attval the value of that the attribute named attr has to have for an element to be selected
	* @return a Set of MarkupItem with all the elements having the required gid, namespace, and a specific attribute equal to the desired value
	* @throws URISyntaxException if the ns will not be parsed correctly as a valid URI
	*/
	public Set<MarkupItem> findItemsWithAtts(String gid, String ens, String attr, String attval) throws URISyntaxException	{
		
		Set<MarkupItem> searchresult;
		searchresult = findItemsByGIDAndNS(gid, ens); /* Trovo tutti gli elementi con il GID specificato */
		
		Set<MarkupItem> outputresult =(Set<MarkupItem>) new HashSet<MarkupItem>() ;
		
		Iterator<MarkupItem> iter1 = searchresult.iterator(); /* Mi procuro un iteratore su di essi */
		
		while (iter1.hasNext()) // Finchè ci sono...
		{
			MarkupItem mark = iter1.next();
			if (mark.hasAttribute()) /* Se ha attributi, vado a verificare che siano quelli giusti */
			{
				Collection itematts = mark.getAttributes();
				Iterator<EARMARKChildNode> iter2 = itematts.iterator(); /* Ciclo sugli attributi */
				
				while (iter2.hasNext())
				{
					Attribute node  = (Attribute) iter2.next(); /* Lo casto in attributo */
					
					if (node.hasGeneralIdentifier().equals(attr)) /* Ho trovato l'attributo col nome giusto */
					{
							if ((getOptions().getVerbosity_finder() >= 4) && (getOptions().isLog_findItemsWithAtts())) // Output Log
							{
								System.out.println("Finder Debug: Attribute found with GID: " + node.hasGeneralIdentifier());
							}
						if (node.getTextContent().equals(attval)) /* Se il suo contenuto testuale è uguale a quello che cerco */
						{
								if ((getOptions().getVerbosity_finder() >= 4) && (getOptions().isLog_findItemsWithAtts())) // Output Log
								{
									System.out.println("Debug: Attribute content is: " + node.getTextContent());
								}
							/* Allora AGGIUNGO IL GENITORE alla lista degli elementi su cui voglio operare */
							outputresult.add((MarkupItem) node.getParentNode());
							
								if ((getOptions().getVerbosity_finder() >= 4) && (getOptions().isLog_findItemsWithAtts())) // Output Log
								{
									System.out.println("Debug: Attribute match found with GID: " + node.hasGeneralIdentifier() + 
									 		" ID: " + node.hasId() + " Text: " + node.getTextContent());
									System.out.println("Debug: Attribute parent added: " + node.getParentNode().hasId() + " proceeding to the next one");
								}
						}
					}
					/* Una volta finiti tutti gli attributi, continuo sul resto della lista */
				}
			
			}
			/* Una volta completata tutta l'ispezione, inizio a ritornare */
		}
			if ((getOptions().getVerbosity_finder() >= 2) && (getOptions().isLog_findItemsWithAtts())) // Output Log
			{
				System.out.println("Finder: Found # parent elements: " + outputresult.size() + " for attribute " + attr + " = " + attval);
			}
		
		lastitemset = outputresult;
		return outputresult;
	}
	
	/**
	* This method returns selects all the elements in the EARMARKDocument with the same GID that have as a child a chosen attribute.
	* The method searches by GID and Namespace, like the FindItemsByGIDAndNS method, then it refines the set resulted by the search.
	* It iterates over the set, keeping only the MarkupItems having as child a chosen Attribute node.
	* 
	* @param gid The general identifier of the MarkupItems to be found in the document
	* @param ens The namespace of the MarkupItems to be found in the document
	* @param attr The name of the Attribute to be searched. It has to be present as the child of an element to be selected
	* @return a Set of MarkupItem with all the elements having the required gid, namespace, and a specific attribute
	* @throws URISyntaxException if the ns will not be parsed correctly as a valid URI
	*/
	public Set<MarkupItem> findItemsWithAtts(String gid, String ens, String attr) throws URISyntaxException	{
		
		Set<MarkupItem> searchresult;
		searchresult = findItemsByGIDAndNS(gid, ens); /* Trovo tutti gli elementi con il GID specificato */
		
		Set<MarkupItem> outputresult =(Set<MarkupItem>) new HashSet<MarkupItem>() ;
		
		Iterator<MarkupItem> iter1 = searchresult.iterator(); /* Mi procuro un iteratore su di essi */
		
		while (iter1.hasNext()) // Finchè ci sono...
		{
			MarkupItem mark = iter1.next();
			if (mark.hasAttribute()) /* Se ha attributi, vado a verificare che siano quelli giusti */
			{
				Collection itematts = mark.getAttributes();
				Iterator<EARMARKChildNode> iter2 = itematts.iterator(); /* Ciclo sugli attributi */

				while (iter2.hasNext())
				{
					Attribute node  = (Attribute) iter2.next(); /* Lo casto in attributo */
					
					if (node.hasGeneralIdentifier().equals(attr)) /* Ho trovato l'attributo col nome giusto */
					{
							if ((getOptions().getVerbosity_finder() >= 4) && (getOptions().isLog_findItemsWithAtts())) // Output Log
							{
								System.out.println("Finder Debug: Attribute found with GID: " + node.hasGeneralIdentifier());
							}
						/* Allora AGGIUNGO IL GENITORE alla lista degli elementi su cui voglio operare */
						outputresult.add((MarkupItem) node.getParentNode());
						
							if ((getOptions().getVerbosity_finder() >= 4) && (getOptions().isLog_findItemsWithAtts())) // Output Log
							{
								System.out.println("Debug: Attribute match found with GID: " + node.hasGeneralIdentifier() + 
										" ID: " + node.hasId() + " Text: " + node.getTextContent());
								System.out.println("Debug: Attribute parent added: " + node.getParentNode().hasId() + " proceeding to the next one");
							}
					}
					/* Una volta finiti tutti gli attributi, continuo sul resto della lista */
				}

			}
			/* Una volta completata tutta l'ispezione, inizio a ritornare */
		}
			if ((getOptions().getVerbosity_finder() >= 2) && (getOptions().isLog_findItemsWithAtts())) // Output Log
			{
				System.out.println("Finder: Found # parent elements: " + outputresult.size() + " for attribute " + attr);
			}

		lastitemset = outputresult;
		return outputresult;
	}
	
	/*
	 * And now, With WILDCARDS Support for the attribute values!
	 * 
	 */
	/**
	 * This method returns selects all the elements with a chosen GID that have as a child a specific attribute whose contents match a desired pattern
	 * The method searches by GID and Namespace, like the FindItemsByGIDAndNS method, then it refines the set resulted by the search.
	 * It iterates over the set, keeping only the MarkupItems having as child a chosen Attribute node with the value matching a pattern.
	 * The pattern can contain one or more wildcard characters '*' (asterisk).
	 * 
	 * @param gid The general identifier of the MarkupItems to be found in the document
	 * @param ens The namespace of the MarkupItems to be found in the document
	 * @param attr The name of the Attribute to be searched. It has to be present as the child of an element to be selected
	 * @param pattern the required content for the attribute attr. It can contain multiple wildcards '*' (asterisk).
	 * @return a Set of MarkupItem with all the elements having the required gid, namespace, and a specific attribute whose contents match the pattern
	 * @throws URISyntaxException if the ns will not be parsed correctly as a valid URI
	 */
	public Set<MarkupItem> findItemsWithWildAtts(String gid, String ens, String attr, String pattern) throws URISyntaxException	{
		
		Set<MarkupItem> searchresult;
		searchresult = findItemsByGIDAndNS(gid, ens); /* Trovo tutti gli elementi con il GID specificato */
		
		Set<MarkupItem> outputresult =(Set<MarkupItem>) new HashSet<MarkupItem>() ;
		
		Iterator<MarkupItem> iter1 = searchresult.iterator(); /* Mi procuro un iteratore su di essi */
		
		while (iter1.hasNext()) // Finchè ci sono...
		{
			MarkupItem mark = iter1.next();
			if (mark.hasAttribute()) /* Se ha attributi, vado a verificare che siano quelli giusti */
			{
				Collection itematts = mark.getAttributes();
				Iterator<EARMARKChildNode> iter2 = itematts.iterator(); /* Ciclo sugli attributi */
				
				while (iter2.hasNext())
				{
					Attribute node  = (Attribute) iter2.next(); /* Lo casto in attributo */
					
					if (node.hasGeneralIdentifier().equals(attr)) /* Ho trovato l'attributo col nome giusto */
					{
						if ((getOptions().getVerbosity_finder() >= 4) && (getOptions().isLog_findItemsWithWildAtts())) // Output Log
						{
							System.out.println("Debug: Attribute found with GID: " + node.hasGeneralIdentifier());
						}
						if (containsWildCard (node.getTextContent(), pattern)) /* Se il suo contenuto testuale è uguale a quello che cerco */
						{
								if ((getOptions().getVerbosity_finder() >= 4) && (getOptions().isLog_findItemsWithWildAtts())) // Output Log
								{
									System.out.println("Debug: Attribute content is: " + node.getTextContent());
								}
							/* Allora AGGIUNGO IL GENITORE alla lista degli elementi su cui voglio operare */
							outputresult.add((MarkupItem) node.getParentNode());
							
								if ((getOptions().getVerbosity_finder() >= 4) && (getOptions().isLog_findItemsWithWildAtts())) // Output Log
								{
									System.out.println("Debug: Attribute match found with GID: " + node.hasGeneralIdentifier() +
											" ID: " + node.hasId() + " Text: " + node.getTextContent());
									System.out.println("Debug: Attribute parent added: " + node.getParentNode().hasId() + " proceeding to the next one");
								}
						}
					}
					/* Una volta finiti tutti gli attributi, continuo sul resto della lista */
				}
			
			}
			/* Una volta completata tutta l'ispezione, inizio a ritornare */
		}
			if ((getOptions().getVerbosity_finder() >= 2) && (getOptions().isLog_findItemsWithWildAtts())) // Output Log
			{
				System.out.println("Finder: Wildcard search found # parent elements: " + outputresult.size() + 
						" for attribute " + attr + " with pattern = " + pattern);	
			}
		
		lastitemset = outputresult;
		return outputresult;
	}
	
	/**
	 * This method selects in the document a Set of MarkupItem whose ids correspond to a predictable numeric series, i.e. "elem_001" to "elem_050".
	 * It creates a range of Identifiers from two static String parts (idstart and idend), and a numeric variable part (start and end)
	 * It then searches by Identifier inside the document of the Applier, using the findSingleMarkupItem method on the current_id just obtained,
	 * It keeps searching for MarkupItems and adding those found to the Set of results to be outputed, until the numbered series is fully visited
	 * 
	 * @param idstart The first (static) part of the identifier for the items part of the series to be found
	 * @param numberpatternformat a number pattern format, matching the ones used by the DecimalFormat standard java class (i.e. "##" or "000")
	 * @param start the beginning of the numbered series
	 * @param end the number at which the serie of id ends
	 * @param idends the second (static) part of the identifier for the items part of the series to be found
	 * @return a Set of MarkupItem with all the elements found in the document, matching to the resulting id patterns
	 * @throws URISyntaxException if the element ids created from the paramaters will not be parsed correctly as a valid URI
	 */
	public Set<MarkupItem> findItemsWithARangeOfIds(String idstart, String numberpatternformat, int start, int end, String idends) 
			throws URISyntaxException	{
		Set<MarkupItem> searchresult = new HashSet<MarkupItem>();
		int current = start;
		
		while (current <= end)
		{
			// Devo usare un Formatter per l'output!
			DecimalFormat formatter = new DecimalFormat(numberpatternformat);
			String output_current = formatter.format(current);
			
			String currentid = idstart+output_current+idends;  // Creo l'ID
			
			if ((getOptions().getVerbosity_finder() >= 4) && (getOptions().isLog_findItemsWithARangeOfIds())) // Output Log
			{
				System.out.println("Looking for Entity with ID: "+currentid+" now at step " + " current"); 
			}
			
			searchresult.add(findSingleMarkupItem(currentid)); // Trovo il mio oggetto
			
			current++; // Incremento la posizione a cui sono arrivato
		}
		
		if ((getOptions().getVerbosity_finder() >= 2) && (getOptions().isLog_findItemsWithARangeOfIds())) // Output Log
		{
			System.out.println("Finder: Search by pattern id: "+idstart+" with range: "+start+"-"+end+" ending in: "+idends+
					" has produced a set of results with "+searchresult.size()+" elements"); 
		}
		
		return searchresult;
	}
	
	
    /**
     * This method is for inner use only, it performs a wildcard pattern match-check inside a test, supporting wildcards like "*"
     * 
     * @param text the text to be tested for containment of a certain text pattern.
     * @param pattern is the text pattern to be matched against the text.
     * This pattern can contain the wildcard character "*" (asterisk).
     * @return <tt>true</tt> if a match is found, <tt>false</tt> if not.
     */
	private boolean containsWildCard(String text, String pattern) {
		// Separate the different parts of the requested pattern by splitting using a RegEx.
		String[] segments = pattern.split("\\*");
		// Iterate over the segments of the pattern.
		for (String part : segments) {
			int index = text.indexOf(part);
			// The part identified by the wildcard is not detected in the text.
			if (index == -1) {	return false;	}
			// If a match is found, move on, towards the right of the text.
			text = text.substring(index + part.length());
		}
		return true;
	}
    
	/*
	 * Other Utilities mashup.
	 * A method to select ALL items corresponding to a GID, EXCEPT the ones with certain attributes or attribute values 
	 */
	/**
	 * This method simply selects all items corresponding to a GID and NS, EXCEPT the ones with certain attributes having certain values.
	 * It first searches MarkupItems in the document of the Applier by using findItemsByGIDandNS(gid, ens)
	 * Then it filters the Set result obtained by iterating over the Map of attribute names and attribute values that flags items that are to be removed
	 * 
	 * @param gid The general identifier of the MarkupItems to be found in the document
	 * @param ens The namespace of the MarkupItems to be found in the document
	 * @param attnamesvalues a Map of attribute names and attribute contents. 
	 * Elements having as a child one an attribute whose name and content are associated in the map are flagged for removal from the result set
	 * @return a Set of MarkupItem with all the elements found in the document, filtered according to the attnamesvalues map contents
	 * @throws URISyntaxException if the ns will not be parsed correctly as a valid URI
	 */
	public Set<MarkupItem> findItemsExcept (String gid, String ens, Map<String,String> attnamesvalues) throws URISyntaxException {
		Set<MarkupItem> result = findItemsByGIDAndNS(gid, ens);
		
		Set<Entry<String,String>> eset = attnamesvalues.entrySet();
		
		Iterator<Entry<String,String>> iter = eset.iterator();
		
		if (iter.hasNext())
		{
			Entry <String,String> entry = iter.next();
			Set <MarkupItem> removee = findItemsWithAtts(gid, ens, entry.getKey(), entry.getValue());
			
				if ((getOptions().getVerbosity_finder() >= 3) && (getOptions().isLog_findItemsExcept())) // Output Log
				{
					System.out.println("Finder Verbose: I'm removing " + removee.size() + " elements having attributes with "+entry.getKey()
							+" "+entry.getValue()+" from a set with with size: " + result.size());
				}
			
			result.removeAll(removee);
		}
			if ((getOptions().getVerbosity_finder() >= 2) && (getOptions().isLog_findItemsExcept())) // Output Log
			{
				System.out.println("Finder: Now the initial set has only : " + result.size() + " elements left with GID: " + gid);
			}
		
		return result;
	}
	/*Other Utilities mashup: A method to select ALL items corresponding to a GID, EXCEPT the ones with certain attributes	 */
	/**
	 * This method simply selects all items corresponding to a GID and NS, EXCEPT the ones having certain attributes
	 * It first searches MarkupItems in the document of the Applier by using findItemsByGIDandNS(gid, ens)
	 * Then it filters the Set result obtained by iterating over the Set of attribute names which will flag items that are to be removed
	 * 
	 * @param gid The general identifier of the MarkupItems to be found in the document
	 * @param ens The namespace of the MarkupItems to be found in the document
	 * @param attnames a Set of attribute names: Elements having as a child one an attribute whose name is in the set are excluded from the output
	 * @return a Set of MarkupItem with all the elements found in the document, filtered according to the attnames Set
	 * @throws URISyntaxException if the ns will not be parsed correctly as a valid URI
	 */
	public Set<MarkupItem> findItemsExcept (String gid, String ens, Set<String> attnames) throws URISyntaxException {
		Set<MarkupItem> result = findItemsByGIDAndNS(gid, ens);
		
		Iterator<String> iter = attnames.iterator();
		
		if (iter.hasNext())
		{
			String attname = iter.next();
			Set <MarkupItem> removee = findItemsWithAtts(gid, ens, attname);
			
				if ((getOptions().getVerbosity_finder() >= 3) && (getOptions().isLog_findItemsExcept())) // Output Log
				{
					System.out.println("Finder Verbose: I'm removing " + removee.size() + " elements having the attribute "+attname
							+" from a set with with size: " + result.size());
				}
			
			result.removeAll(removee);
		}
		
			if ((getOptions().getVerbosity_finder() >= 2) && (getOptions().isLog_findItemsExcept())) // Output Log
			{
				System.out.println("Finder: Now the initial set has only : " + result.size() + " elements left with GID: " + gid);
			}
		
		return result;
	}


	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the options
	 */
	public EarmarkFinderPreferences getOptions() {
		return options;
	}
	/**
	 * @param options the options to set
	 */
	public void setOptions(EarmarkFinderPreferences options) {
		this.options = options;
	}


	/**
	 * @return the document
	 */
	public EARMARKDocument getDocument() {
		return document;
	}
	/**
	 * @param document the document to set
	 */
	public void setDocument(EARMARKDocument document) {
		this.document = document;
	}


	/**
	 * @return the currentitem
	 */
	public MarkupItem getCurrentitem() {
		return currentitem;
	}
	/**
	 * @param currentitem the currentitem to set
	 */
	public void setCurrentitem(MarkupItem currentitem) {
		this.currentitem = currentitem;
	}


	/**
	 * @return the currententity
	 */
	public EARMARKItem getCurrententity() {
		return currententity;
	}
	/**
	 * @param currententity the currententity to set
	 */
	public void setCurrententity(EARMARKItem currententity) {
		this.currententity = currententity;
	}


	/**
	 * @return the lastitemset
	 */
	public Set<MarkupItem> getLastitemset() {
		return lastitemset;
	}
	/**
	 * @param lastitemset the lastitemset to set
	 */
	public void setLastitemset(Set<MarkupItem> lastitemset) {
		this.lastitemset = lastitemset;
	}


	/**
	 * @return the laststatement
	 */
	public Statement getLaststatement() {
		return laststatement;
	}


	/**
	 * @param laststatement the laststatement to set
	 */
	public void setLaststatement(Statement laststatement) {
		this.laststatement = laststatement;
	}
	
}

